# Review notes

Quick map from standards criteria to evidence in this repository.

## Correctness
- `src/lib/aura/kernel-tests.ts` — 36 executable specifications; no mocking of the units under test.
- `GET /api/kernel?format=summary` — CI-shaped result `{ ok, total, passed, failed, failures[] }`.
- Graph invariant: composite vertices have one parent, leaves are shared references; `validateGraph` runs inside every mutation transaction and is covered by two specs.

## Rigour of the claims
- Discovery verdicts are labelled *holds*, *refuted* (with a counterexample) or *unverifiable*;
  recognised laws that sampling cannot decide are never reported as proved.
- README §8 states limitations and threats to validity (sampling ≠ proof, classifier ≠ HMER model,
  numeric not symbolic evaluation, heuristic layout, single-user snapshot history).

## Reproducibility
- Deterministic evaluation: fixed sampling table indexed by free-variable position.
- Seeded canvases cover verified, refuted, symbolic and type-level discovery outcomes.
- `npx drizzle-kit push` + `npm run dev` reproduces the environment from an empty database.

## Accessibility
- Skip link, landmarks, `aria-live` graph/status summaries, focusable canvas with arrow-key
  traversal, `aria-pressed` tool toggles, labelled icon buttons, `:focus-visible` rings,
  `prefers-reduced-motion` and `prefers-contrast` support.

## Performance
- Viewport culling with a 220 world-px margin, memoised inference/layout/diagnostics,
  throttled discovery recomputation, bounded discovery search with per-pair and per-template caps.

## Interoperability
- LaTeX, MathML (KaTeX) and typed-graph JSON export; LaTeX import with structural recovery;
  `/api/library` inventory endpoint; every response is JSON with explicit status codes.
