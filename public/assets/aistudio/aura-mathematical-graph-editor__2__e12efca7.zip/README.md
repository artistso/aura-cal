# Aura — a connection-first mathematical canvas

Aura treats mathematics as a space of connectable objects. Every symbol, number, operator,
equation and set is a **typed vertex** in a hypergraph; edges are **port bindings** with type
and arity semantics. LaTeX, MathML and JSON are serialisations of that graph — never the
source of truth.

This repository is a browser prototype of the architecture described in the Aura proposal.
The S Pen / HMER / SymPy parts of that proposal are represented here by faithful, testable
replacements (pointer ink capture, a geometric symbol classifier, and a dependency-free
numeric/symbolic core) so the graph kernel and interaction model can be evaluated end to end.

---

## 1. Formal model

A document is a typed hypergraph

```
H = (V, E, τ)
```

- **V** — vertices: `literal`, `variable`, `operator`, `relation`, `function`, `container`,
  `set`, `group` (collapsed subexpression).
- **τ** — a type in the lattice `Scalar | Variable | Vector | Matrix | Set | Expression |
  Relation | Function | Operator | Unknown`. Types are *declared* on leaves and *inferred*
  bottom-up for compound vertices (a product of two `Matrix` operands is a `Matrix`; a
  relation is always `Relation`).
- **E** — directed bindings `source --port--> target`. A source may fill each port once.
  Leaves (`literal`, `variable`, `set`) are **references** and may be shared across
  operators — θ must feed both `sin²θ` and `cos²θ`. Composite vertices are **tree nodes**
  and may have at most one parent, which `validateGraph` enforces inside every mutation
  transaction.

### Ports

Ports are declared per vertex variant, which is what makes connectivity computable:

| Family | Ports |
|---|---|
| binary operators / relations | `left`, `right` |
| power | `base`, `exponent` |
| fraction, binomial | `numerator`, `denominator` |
| integral, summation, limits | `lower`, `upper`, `body` |
| functions, accents, enclosures, postfix operators | `arg` / `body` |
| radicals | `body` (+ `upper` for the index) |
| leaves | `exponent`, `subscript` |

Admissibility (`admits`) is a type-intersection with two widening rules: an `Expression`
port accepts any operand-like vertex, and `Variable`/`Scalar` may interchange. Everything
else is rejected and surfaced as a diagnostic.

---

## 2. Kernel modules

| Module | Responsibility |
|---|---|
| `src/lib/aura/ontology.ts` | type lattice, ports, symbol catalogue, geometry estimates |
| `src/lib/aura/library.ts` | **338 symbols** across 16 domains, each a typed vertex blueprint |
| `src/lib/aura/engine.ts` | indexing, type propagation, diagnostics, LaTeX serialisation, expression layout, **homeomorphic connection candidates**, collapse/expand |
| `src/lib/aura/parse.ts` | LaTeX → typed hypergraph (fractions, powers, radicals, limits, big operators, accents, matrices, function application) |
| `src/lib/aura/evaluate.ts` | port-walking numeric evaluator, constant folding, plotting samples, variable scope |
| `src/lib/aura/discover.ts` | canvas-wide connection discovery, sampling-based verification, batch application |
| `src/lib/aura/kernel-tests.ts` | **36 executable specifications** over everything above |

Interaction notes:

- **Ghost paths.** Dragging a vertex computes candidates only inside a local radius, filters
  by port admissibility, then scores by proximity, exactness and arity. Candidates carry the
  exact graph patch required to commit them.
- **Discovery scale.** A single scalar in `[0, 1]` controls search radius, candidate depth,
  eligible binders and whether refuted proposals are shown. Verified proposals are ranked
  above unverifiable ones; per-pair and per-template caps keep the list diverse.
- **Verification.** Each proposal is evaluated on deterministic pseudo-random assignments
  (12 rounds when free variables exist). Equality/inequality claims are classified as
  *holds*, *refuted* (with a cited counterexample) or *unverifiable*; recognised symbolic
  laws that sampling cannot decide are labelled rather than silently refuted.

---

## 3. Verification

```bash
curl -s localhost:3000/api/kernel?format=summary | jq
curl -s localhost:3000/api/health | jq
```

`GET /api/kernel` runs the whole suite head-lessly and returns a machine-checkable report
(`{ ok, total, passed, failed, failures[] }`); `GET /api/health` reports database latency,
row counts and the same suite for readiness probes. Both are suitable for CI gates.

Current status: **36/36 specs passing** (ontology, types, serialisation, parser, evaluator,
graph invariants, scope, discovery, library, interop) in ~10 ms, with 338 library symbols
checked for taxonomy and port completeness.

The suite is not decorative — it has already caught and driven fixes for:

1. matrix/scalar arithmetic not being diagnosed,
2. unary minus dropped by the parser,
3. `\sin^2\theta` binding the exponent to the wrong subtree,
4. numeric summation ignoring its index relation (`\sum_{n=1}^{10} n`),
5. membership ports over-accepting matrices via expression widening,
6. an over-strict "one parent for every vertex" invariant that made shared variables
   (θ in sin²θ + cos²θ) unrepresentable.

---

## 4. Evaluation methodology

Discovery quality is measured on the seeded **Discovery playground** canvas (7 clusters,
22 vertices). At scale 0.85 the engine inspects **579 port-admissible bindings** and returns
20 proposals, of which 8 verify:

```
✓ sin²θ + cos²θ = 1                (equality, 97/100)
✓ (6+2)/4 = 2                      (equality, 95/100)
✓ 1 ∈ ℝ, (6+2)/4 ∈ ℝ               (type-level membership)
✓ sin²θ + cos²θ ≈ 1                (approximation)
✓ sin²θ + cos²θ ≤ 2                (order)
~ E = mc²                          (recognised law, unverifiable by sampling)
```

Determinism: sampling assignments are a fixed table indexed by free-variable position, so
identical canvases always produce identical verdicts.

---

## 5. API surface

| Endpoint | Purpose |
|---|---|
| `GET /api/documents` | list canvases with vertex/binding counts |
| `POST /api/documents` | create an empty canvas |
| `GET /api/documents/:id` | graph, history, serialisations, diagnostics |
| `DELETE /api/documents/:id` | remove a canvas |
| `POST /api/documents/:id/mutations` | `addNode`, `move`, `connect`, `autoConnect`, `delete`, `collapse`, `expand`, `reflow`, `simplify`, `insertExpression` |
| `POST /api/documents/:id/history` | `undo` / `redo` (snapshot transactions) |
| `POST /api/documents/:id/discover` | run discovery (scale, families, focus, limit) |
| `GET /api/documents/:id/analysis` | numeric values, variables, plot samples |
| `POST /api/recognize` | Tier-1 ink classification, Tier-2 LaTeX structural recovery |
| `GET /api/library` | symbol inventory, searchable by name/token/domain |
| `GET /api/kernel` | executable specification report |
| `GET /api/health` | readiness: database + kernel |

Persistence is PostgreSQL via Drizzle: `documents`, `nodes`, `edges`, `transactions`,
`discoveries`. Every mutation stores before/after graph snapshots inside one SQL
transaction, making undo/redo exact rather than approximate.

---

## 6. Accessibility

- Skip link to the workspace; `aria-live` status for graph summaries and mutation results.
- The canvas is a focusable `role="application"` with arrow-key traversal between vertices,
  Enter/double-click cluster selection, and full keyboard parity for tools and tabs
  (`F` fit, `Q` marquee, `1–4` commit ghost paths, `Delete` remove, `⌘/Ctrl+Z` undo,
  `⌘/Ctrl+Shift+Z` redo, `⌘/Ctrl+G` zoom to selection, `?` legend, `Esc` cancel).
- Visible `:focus-visible` rings on every interactive element, `aria-pressed` on tool
  toggles, labelled icon buttons, `prefers-reduced-motion` honoured, `prefers-contrast`
  palette, and ≥ 4.5:1 contrast on body text.

## 7. Performance

- Canvas culling: offscreen vertices (220 world-px margin) are not rendered; the minimap
  preserves global context.
- Discovery is bounded (radius, candidate caps, per-template caps) and never enumerates
  globally; batch application is O(bindings) with conflict pre-checks.
- Type inference, layout and diagnostics are memoised per graph identity; drag updates are
  throttled to ~45 ms between candidate recomputations.

---

## 8. Limitations & threats to validity

- **Sampling is not proof.** Equalities are tested on finitely many assignments; a proposal
  marked *holds* is evidence, not a theorem. Recognised laws are flagged separately, and
  claims with more than four free variables are downgraded to *unverifiable*.
- **The classifier is geometric, not learned.** It distinguishes a small, honest symbol set
  with calibrated confidence and escalates low-confidence strokes, but it is not a
  substitute for an HMER model.
- **Numeric, not symbolic, evaluation.** The core computes values; it does not simplify
  algebraically beyond constant folding, and it rejects domains it cannot represent
  (matrices, complex values) rather than guessing.
- **Layout is heuristic.** Expression re-flow is deterministic but not typographically
  identical to TeX; it optimises for spatial manipulability on a canvas.
- **Single-user.** No collaborative editing or CRDT merge yet; history is snapshot-based.

## 9. Running

```bash
npm install
npx drizzle-kit push       # apply schema
npm run dev                # http://localhost:3000
npm run build && npm start
```

Environment: `DATABASE_URL` (PostgreSQL). Seeded canvases: energy–mass, Pythagorean
identity, integral type sandbox, evaluator & plot, discovery playground.

## 10. References

The design draws on typed hypergraph rewriting, port-based programming models, graph-edit
distance for structural similarity, CROHME-style handwriting evaluation for mathematics,
and the ghost-preview interaction pattern from graph editors.
