"use client";

import { useMemo } from "react";

import { type AuraGraph, type Diagnostic } from "@/lib/aura/ontology";
import { LIBRARY_COUNT } from "@/lib/aura/library";
import { SymbolBrowser } from "./SymbolLibrary";
import { type DocumentSummary, indexGraph, openPorts } from "@/lib/aura/engine";
import { Icon } from "./icons";

interface SidebarProps {
  graph: AuraGraph;
  documents: DocumentSummary[];
  activeId: string;
  busy: boolean;
  diagnostics: Diagnostic[];
  onSwitchDocument: (id: string) => void;
  onCreateDocument: () => void;
  onAddElement: (itemId: string) => void;
  onOpenLibrary: () => void;
}

export function Sidebar({
  graph,
  documents,
  activeId,
  busy,
  diagnostics,
  onSwitchDocument,
  onCreateDocument,
  onAddElement,
  onOpenLibrary,
}: SidebarProps) {
  const index = useMemo(() => indexGraph(graph), [graph]);
  const openCount = useMemo(
    () => graph.nodes.reduce((sum, node) => sum + openPorts(index, node).length, 0),
    [graph, index],
  );
  const errorCount = diagnostics.filter((entry) => entry.severity === "error").length;

  return (
    <div className="flex h-full flex-col overflow-hidden">
      <div className="border-b border-white/8 px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="relative flex h-8 w-8 items-center justify-center rounded-[11px] bg-gradient-to-br from-amber-200 to-amber-500 text-[#1a1206]">
              <span className="display text-[17px] font-semibold leading-none">A</span>
              <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-teal-300 ring-2 ring-[#0b1119]" />
            </span>
            <div>
              <div className="display text-[20px] leading-none text-slate-50">Aura</div>
              <div className="mono mt-1 text-[9px] uppercase tracking-[0.18em] text-slate-500">
                hypergraph canvas
              </div>
            </div>
          </div>
          <span className="pill text-teal-200" title="Connected to the graph store">
            <span className="h-1.5 w-1.5 rounded-full bg-teal-300 pulse" />
            synced
          </span>
        </div>
        <div className="mt-3 grid grid-cols-3 gap-1.5">
          <div className="rounded-lg border border-white/8 bg-white/[0.02] px-2 py-1.5">
            <div className="mono text-[13px] text-slate-200">{graph.nodes.length}</div>
            <div className="text-[9px] uppercase tracking-[0.1em] text-slate-600">vertices</div>
          </div>
          <div className="rounded-lg border border-white/8 bg-white/[0.02] px-2 py-1.5">
            <div className="mono text-[13px] text-slate-200">{graph.edges.length}</div>
            <div className="text-[9px] uppercase tracking-[0.1em] text-slate-600">bindings</div>
          </div>
          <div className="rounded-lg border border-white/8 bg-white/[0.02] px-2 py-1.5">
            <div className={`mono text-[13px] ${errorCount ? "text-rose-300" : "text-teal-200"}`}>
              {errorCount ? errorCount : openCount}
            </div>
            <div className="text-[9px] uppercase tracking-[0.1em] text-slate-600">
              {errorCount ? "conflicts" : "open ports"}
            </div>
          </div>
        </div>
      </div>

      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto px-3 py-3">
        <section className="mb-4">
          <div className="mb-1.5 flex items-center justify-between px-1">
            <span className="eyebrow">Canvases</span>
            <button
              type="button"
              className="btn h-6 px-1.5 text-[10px]"
              onClick={onCreateDocument}
              disabled={busy}
            >
              <Icon name="plus" className="h-3 w-3" />
              new
            </button>
          </div>
          <div className="space-y-1">
            {documents.map((document) => {
              const active = document.id === activeId;
              return (
                <button
                  key={document.id}
                  type="button"
                  onClick={() => onSwitchDocument(document.id)}
                  disabled={busy}
                  className={`w-full rounded-xl border px-2.5 py-2 text-left transition ${
                    active
                      ? "border-amber-300/40 bg-amber-300/[0.07]"
                      : "border-transparent hover:border-white/10 hover:bg-white/[0.03]"
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    <Icon
                      name="docs"
                      className={`h-3 w-3 shrink-0 ${active ? "text-amber-200" : "text-slate-600"}`}
                    />
                    <span
                      className={`truncate text-[12px] ${active ? "text-slate-100" : "text-slate-400"}`}
                    >
                      {document.title}
                    </span>
                  </div>
                  <div className="mono mt-0.5 pl-[18px] text-[9px] text-slate-600">
                    {document.nodeCount} V · {document.transactionCount} tx
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        <div className="hairline mb-3" />

        <section className="flex min-h-0 flex-col">
          <div className="mb-1.5 flex items-center justify-between px-1">
            <span className="eyebrow">Symbols</span>
            <button
              type="button"
              className="btn h-6 px-1.5 text-[10px]"
              onClick={onOpenLibrary}
              title="Open the full symbol library"
            >
              <Icon name="expand" className="h-3 w-3" />
              all {LIBRARY_COUNT}
            </button>
          </div>
          <div className="min-h-0 flex-1">
            <SymbolBrowser compact busy={busy} onPick={(id) => onAddElement(id)} />
          </div>
        </section>
      </div>

      <div className="border-t border-white/8 px-3 py-2.5">
        <button
          type="button"
          className="btn w-full justify-start text-[11px]"
          onClick={onOpenLibrary}
        >
          <Icon name="docs" className="h-3.5 w-3.5 text-amber-300/80" />
          {LIBRARY_COUNT} symbols · every glyph is a typed vertex
          <Icon name="chevron" className="ml-auto h-3 w-3 -rotate-90 text-slate-600" />
        </button>
      </div>
    </div>
  );
}
