"use client";

import katex from "katex";
import { useMemo } from "react";

export function MathText({
  tex,
  display = false,
  className = "",
}: {
  tex: string;
  display?: boolean;
  className?: string;
}) {
  const html = useMemo(() => {
    try {
      return katex.renderToString(tex, {
        throwOnError: false,
        displayMode: display,
        strict: false,
        trust: false,
        output: "html",
      });
    } catch {
      return tex;
    }
  }, [tex, display]);

  return (
    <span
      className={`math-inline ${className}`}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}

export function MathBlock({ tex, className = "" }: { tex: string; className?: string }) {
  return (
    <div className={`overflow-x-auto scroll-thin ${className}`}>
      <MathText tex={tex} display />
    </div>
  );
}

export function mathml(tex: string): string {
  try {
    return katex.renderToString(tex, {
      throwOnError: false,
      displayMode: true,
      strict: false,
      output: "mathml",
    });
  } catch {
    return `<math><mtext>${tex}</mtext></math>`;
  }
}
