import type { SVGProps } from "react";

export type IconName =
  | "undo"
  | "redo"
  | "plus"
  | "pen"
  | "export"
  | "fit"
  | "trash"
  | "collapse"
  | "expand"
  | "layout"
  | "pointer"
  | "marquee"
  | "close"
  | "copy"
  | "check"
  | "chevron"
  | "spark"
  | "warning"
  | "error"
  | "docs"
  | "port"
  | "bind"
  | "graph"
  | "history"
  | "menu";

const PATHS: Record<IconName, React.ReactNode> = {
  undo: <path d="M9 14 4 9l5-5M4 9h9a7 7 0 0 1 0 14h-2" />,
  redo: <path d="m15 14 5-5-5-5M20 9h-9a7 7 0 0 0 0 14h2" />,
  plus: <path d="M12 5v14M5 12h14" />,
  pen: <path d="m15 4 5 5-9.5 9.5L4 20l1.5-6.5L15 4Z" />,
  export: <path d="M12 3v12m0-12 4 4m-4-4-4 4M4 15v3a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3v-3" />,
  fit: <path d="M4 9V5a1 1 0 0 1 1-1h4M20 9V5a1 1 0 0 0-1-1h-4M4 15v4a1 1 0 0 0 1 1h4m11-5v4a1 1 0 0 1-1 1h-4" />,
  trash: <path d="M4 7h16M9 7V5h6v2m-8 0 1 13h8l1-13M10 11v6m4-6v6" />,
  collapse: <path d="M9 4v5H4m11-5v5h5M9 20v-5H4m11 5v-5h5" />,
  expand: <path d="M4 9V4h5m11 5V4h-5M4 15v5h5m11-5v5h-5" />,
  layout: <path d="M4 6h7v5H4zm9 0h7v12h-7zM4 13h7v5H4z" />,
  pointer: <path d="m5 3 14 7-6 1.8L10 18 5 3Z" />,
  marquee: <path d="M4 8V5h3m10 0h3v3m0 8v3h-3M7 19H4v-3m0-5v2m16-2v2M11 4h2m-2 16h2" />,
  close: <path d="m6 6 12 12M18 6 6 18" />,
  copy: <path d="M9 9h10v11H9zM5 15V4h10" />,
  check: <path d="m4 12 5 5L20 6" />,
  chevron: <path d="m6 9 6 6 6-6" />,
  spark: <path d="m12 3 1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3Z" />,
  warning: <path d="M12 4 3 20h18L12 4Zm0 5v5m0 3v.5" />,
  error: <path d="M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm0 5v6m0 3v.5" />,
  docs: <path d="M6 3h8l4 4v14H6zM14 3v5h5M9 12h6m-6 4h6" />,
  port: <path d="M12 4v16M4 12h16" />,
  bind: <path d="M7 12a5 5 0 0 1 5-5h3M17 12a5 5 0 0 1-5 5H9M4 12h4m8 0h4" />,
  graph: <path d="M6 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm12 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM6 21a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm12 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM8 7h8M7 9v4a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9" />,
  history: <path d="M3 12a9 9 0 1 0 3-6.7M3 4v5h5M12 8v4l3 2" />,
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
};

export function Icon({
  name,
  className = "h-4 w-4",
  ...rest
}: { name: IconName; className?: string } & SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
      {...rest}
    >
      {PATHS[name]}
    </svg>
  );
}
