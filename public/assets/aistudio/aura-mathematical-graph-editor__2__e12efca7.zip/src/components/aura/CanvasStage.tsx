"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import {
  type AuraGraph,
  type AuraNode,
  type Diagnostic,
  type GhostPath,
  type MathType,
  type NodeKind,
  estimateWidth,
  findPort,
  portsFor,
  tileHeight,
} from "@/lib/aura/ontology";
import { scopeByNode } from "@/lib/aura/evaluate";
import { classifyInk, type InkPrediction } from "@/lib/aura/recognize";
import {
  componentIds,
  componentsOf,
  diagnose,
  findCandidates,
  graphBounds,
  effectiveType,
  indexGraph,
  openPorts,
  outAnchor,
  portAnchor,
  subtreeIds,
} from "@/lib/aura/engine";
import { MathText } from "./MathText";
import { Icon } from "./icons";

type Tool = "pointer" | "marquee" | "draw";

interface DragState {
  nodeId: string;
  ids: string[];
  origin: Record<string, { x: number; y: number }>;
  start: { x: number; y: number };
  moved: boolean;
}

type BackgroundInteraction =
  | { mode: "pan"; sx: number; sy: number; px: number; py: number }
  | { mode: "marquee"; start: { x: number; y: number }; current: { x: number; y: number } }
  | null;

interface CanvasStageProps {
  graph: AuraGraph;
  documentId: string;
  documentTitle: string;
  selected: string[];
  busy: boolean;
  onSelect: (ids: string[]) => void;
  onMove: (positions: { id: string; x: number; y: number }[]) => void;
  onCommitCandidate: (candidate: GhostPath) => void;
  onExpand: (id: string) => void;
  onViewportCenter: (point: { x: number; y: number }) => void;
  onPlaceRecognized: (
    node: { kind: NodeKind; token: string; label: string; type: MathType; variant: string | null },
    position: { x: number; y: number },
  ) => void;
  onSelectionAction: (action: "collapse" | "expand" | "delete" | "simplify", ids: string[]) => void;
  onOpenLibrary: () => void;
  onOpenInk: () => void;
}

const CULL_MARGIN = 220;

const SNAP_DISTANCE = 8;

const GRID = 32;
const MIN_ZOOM = 0.28;
const MAX_ZOOM = 2.4;

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

function applyPreview(
  graph: AuraGraph,
  preview: Record<string, { x: number; y: number }> | null,
): AuraGraph {
  if (!preview) return graph;
  return {
    ...graph,
    nodes: graph.nodes.map((node) => {
      const point = preview[node.id];
      return point ? { ...node, x: point.x, y: point.y } : node;
    }),
  };
}

function kindAccent(kind: AuraNode["kind"]): string {
  switch (kind) {
    case "relation":
      return "#5eead4";
    case "operator":
      return "#a78bfa";
    case "container":
      return "#f0b45a";
    case "function":
      return "#f472b6";
    case "set":
      return "#60a5fa";
    case "group":
      return "#5eead4";
    default:
      return "#94a3b8";
  }
}

export function CanvasStage({
  graph,
  documentId,
  documentTitle,
  selected,
  busy,
  onSelect,
  onMove,
  onCommitCandidate,
  onExpand,
  onViewportCenter,
  onPlaceRecognized,
  onSelectionAction,
  onOpenLibrary,
  onOpenInk,
}: CanvasStageProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const graphRef = useRef(graph);
  graphRef.current = graph;

  const [view, setView] = useState({ x: 0, y: 0, zoom: 1 });
  const [tool, setTool] = useState<Tool>("pointer");
  const [drag, setDrag] = useState<DragState | null>(null);
  const [preview, setPreview] = useState<Record<string, { x: number; y: number }> | null>(null);
  const [candidates, setCandidates] = useState<GhostPath[]>([]);
  const [interaction, setInteraction] = useState<BackgroundInteraction>(null);
  const [hovered, setHovered] = useState<string | null>(null);
  const [viewport, setViewport] = useState({ w: 0, h: 0 });
  const [guides, setGuides] = useState<{ x: number | null; y: number | null }>({ x: null, y: null });
  const [helpOpen, setHelpOpen] = useState(false);
  const [menu, setMenu] = useState<{ id: string; x: number; y: number } | null>(null);
  const [strokes, setStrokes] = useState<{ x: number; y: number }[][]>([]);
  const [inkPredictions, setInkPredictions] = useState<InkPrediction[]>([]);
  const drawingInk = useRef(false);
  const lastCandidateAt = useRef(0);

  const displayGraph = useMemo(() => applyPreview(graph, preview), [graph, preview]);
  const index = useMemo(() => indexGraph(displayGraph), [displayGraph]);
  const scopes = useMemo(() => scopeByNode(displayGraph), [displayGraph]);
  const diagnostics = useMemo(() => diagnose(displayGraph), [displayGraph]);
  const diagnosticsByNode = useMemo(() => {
    const map: Record<string, Diagnostic[]> = {};
    for (const entry of diagnostics) map[entry.nodeId] = [...(map[entry.nodeId] ?? []), entry];
    return map;
  }, [diagnostics]);
  const errorCount = diagnostics.filter((entry) => entry.severity === "error").length;
  const warningCount = diagnostics.filter((entry) => entry.severity === "warning").length;

  const clusters = useMemo(() => {
    return componentsOf(displayGraph).map((component, offset) => {
      const nodes = component.nodeIds
        .map((id) => index.byId.get(id))
        .filter((node): node is AuraNode => Boolean(node));
      if (nodes.length === 0) return null;
      let minX = Infinity;
      let minY = Infinity;
      let maxX = -Infinity;
      let maxY = -Infinity;
      for (const node of nodes) {
        const halfWidth = estimateWidth(node) / 2;
        minX = Math.min(minX, node.x - halfWidth);
        maxX = Math.max(maxX, node.x + halfWidth);
        minY = Math.min(minY, node.y - tileHeight() / 2);
        maxY = Math.max(maxY, node.y + tileHeight() / 2);
      }
      const pad = 22;
      const root = index.byId.get(component.rootId);
      return {
        id: component.rootId,
        index: offset + 1,
        x: minX - pad,
        y: minY - pad,
        width: Math.max(70, maxX - minX + pad * 2),
        height: Math.max(56, maxY - minY + pad * 2),
        nodeIds: component.nodeIds,
        type: root ? (root.kind === "group" ? "collapsed" : "expression") : "expression",
        selected: component.nodeIds.some((id) => selected.includes(id)),
      };
    }).filter((entry): entry is NonNullable<typeof entry> => Boolean(entry));
  }, [displayGraph, index, selected]);

  const worldRect = useMemo(
    () => ({
      left: -view.x / view.zoom,
      top: -view.y / view.zoom,
      right: (viewport.w - view.x) / view.zoom,
      bottom: (viewport.h - view.y) / view.zoom,
    }),
    [view, viewport],
  );

  const selectionBounds = useMemo(() => {
    const nodes = displayGraph.nodes.filter((node) => selected.includes(node.id));
    if (nodes.length === 0) return null;
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (const node of nodes) {
      const halfWidth = estimateWidth(node) / 2;
      minX = Math.min(minX, node.x - halfWidth);
      maxX = Math.max(maxX, node.x + halfWidth);
      minY = Math.min(minY, node.y - tileHeight() / 2);
      maxY = Math.max(maxY, node.y + tileHeight() / 2);
    }
    return { minX, minY, maxX, maxY };
  }, [displayGraph, selected]);

  const screenSelection = selectionBounds
    ? {
        left: selectionBounds.minX * view.zoom + view.x,
        top: selectionBounds.minY * view.zoom + view.y,
        width: (selectionBounds.maxX - selectionBounds.minX) * view.zoom,
        height: (selectionBounds.maxY - selectionBounds.minY) * view.zoom,
      }
    : null;

  const minimap = useMemo(() => {
    const bounds = graphBounds(displayGraph);
    const width = 148;
    const height = 96;
    const spanX = Math.max(320, bounds.maxX - bounds.minX);
    const spanY = Math.max(220, bounds.maxY - bounds.minY);
    const scale = Math.min((width - 14) / spanX, (height - 14) / spanY);
    const offsetX = (width - spanX * scale) / 2 - bounds.minX * scale;
    const offsetY = (height - spanY * scale) / 2 - bounds.minY * scale;
    return {
      width,
      height,
      scale,
      offsetX,
      offsetY,
      nodes: displayGraph.nodes.map((node) => ({
        id: node.id,
        x: node.x * scale + offsetX,
        y: node.y * scale + offsetY,
        w: Math.max(2, estimateWidth(node) * scale),
        h: Math.max(2, tileHeight() * scale),
        kind: node.kind,
        selected: selected.includes(node.id),
      })),
      viewport: {
        x: worldRect.left * scale + offsetX,
        y: worldRect.top * scale + offsetY,
        w: Math.max(4, (worldRect.right - worldRect.left) * scale),
        h: Math.max(4, (worldRect.bottom - worldRect.top) * scale),
      },
    };
  }, [displayGraph, selected, worldRect]);

  // Track the container size for the minimap, selection bar and guide extents.
  useEffect(() => {
    const element = containerRef.current;
    if (!element) return;
    const measure = () =>
      setViewport((current) =>
        current.w === element.clientWidth && current.h === element.clientHeight
          ? current
          : { w: element.clientWidth, h: element.clientHeight },
      );
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  const zoomToFit = useCallback((box: { minX: number; minY: number; maxX: number; maxY: number }) => {
    const element = containerRef.current;
    if (!element) return;
    const zoom = clamp(
      Math.min(
        (element.clientWidth - 160) / Math.max(180, box.maxX - box.minX),
        (element.clientHeight - 160) / Math.max(140, box.maxY - box.minY),
      ),
      MIN_ZOOM,
      1.6,
    );
    const cx = (box.minX + box.maxX) / 2;
    const cy = (box.minY + box.maxY) / 2;
    setView({ zoom, x: element.clientWidth / 2 - cx * zoom, y: element.clientHeight / 2 - cy * zoom });
  }, []);

  const centreOn = useCallback(
    (worldX: number, worldY: number) => {
      const element = containerRef.current;
      if (!element) return;
      setView((current) => ({
        ...current,
        x: element.clientWidth / 2 - worldX * current.zoom,
        y: element.clientHeight / 2 - worldY * current.zoom,
      }));
    },
    [],
  );

  const toCanvas = useCallback(
    (clientX: number, clientY: number) => {
      const rect = containerRef.current?.getBoundingClientRect();
      if (!rect) return { x: 0, y: 0 };
      return {
        x: (clientX - rect.left - view.x) / view.zoom,
        y: (clientY - rect.top - view.y) / view.zoom,
      };
    },
    [view],
  );

  const fit = useCallback(() => {
    const element = containerRef.current;
    const current = graphRef.current;
    if (!element) return;
    const bounds = graphBounds(current);
    const width = element.clientWidth;
    const height = element.clientHeight;
    const padding = Math.min(220, width * 0.16);
    const zoom = clamp(
      Math.min(
        (width - padding * 2) / Math.max(240, bounds.maxX - bounds.minX),
        (height - padding * 2) / Math.max(200, bounds.maxY - bounds.minY),
      ),
      MIN_ZOOM,
      1.35,
    );
    const cx = (bounds.minX + bounds.maxX) / 2;
    const cy = (bounds.minY + bounds.maxY) / 2;
    setView({ zoom, x: width / 2 - cx * zoom, y: height / 2 - cy * zoom });
  }, []);

  const zoomTo = useCallback((nextZoom: number, anchor?: { x: number; y: number }) => {
    const element = containerRef.current;
    if (!element) return;
    const rect = element.getBoundingClientRect();
    const ax = anchor ? anchor.x - rect.left : rect.width / 2;
    const ay = anchor ? anchor.y - rect.top : rect.height / 2;
    setView((current) => {
      const zoom = clamp(nextZoom, MIN_ZOOM, MAX_ZOOM);
      const canvasX = (ax - current.x) / current.zoom;
      const canvasY = (ay - current.y) / current.zoom;
      return { zoom, x: ax - canvasX * zoom, y: ay - canvasY * zoom };
    });
  }, []);

  // Wheel: pinch / ctrl + wheel zooms, plain wheel pans.
  useEffect(() => {
    const element = containerRef.current;
    if (!element) return;
    const handler = (event: WheelEvent) => {
      event.preventDefault();
      if (event.ctrlKey || event.metaKey) {
        const factor = Math.exp(-event.deltaY * 0.0025);
        zoomTo(view.zoom * factor, { x: event.clientX, y: event.clientY });
      } else {
        setView((current) => ({
          ...current,
          x: current.x - event.deltaX,
          y: current.y - event.deltaY,
        }));
      }
    };
    element.addEventListener("wheel", handler, { passive: false });
    return () => element.removeEventListener("wheel", handler);
  }, [view.zoom, zoomTo]);

  // Fit when the document changes.
  const lastDoc = useRef<string | null>(null);
  useEffect(() => {
    if (lastDoc.current === documentId) return;
    lastDoc.current = documentId;
    const frame = requestAnimationFrame(() => fit());
    return () => cancelAnimationFrame(frame);
  }, [documentId, fit]);

  // Report the viewport centre for palette placement / recognition insertion.
  useEffect(() => {
    const element = containerRef.current;
    if (!element) return;
    onViewportCenter({
      x: (element.clientWidth / 2 - view.x) / view.zoom,
      y: (element.clientHeight / 2 - view.y) / view.zoom,
    });
  }, [view, onViewportCenter]);

  const clearCandidates = useCallback(() => setCandidates([]), []);

  // A committed graph replaces drag-local positions with the engine's re-flow.
  useEffect(() => {
    setPreview(null);
  }, [graph]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)) return;
      if (!event.metaKey && !event.ctrlKey && candidates.length > 0) {
        const number = Number(event.key);
        if (number >= 1 && number <= candidates.length) {
          event.preventDefault();
          const candidate = candidates[number - 1];
          setCandidates([]);
          onCommitCandidate(candidate);
          return;
        }
      }
      if (event.key === "Escape") {
        setCandidates([]);
        setMenu(null);
        setHelpOpen(false);
        onSelect([]);
      }
      if (event.key === "Enter" && tool === "draw" && strokes.length > 0) {
        event.preventDefault();
        setInkPredictions(classifyInk(strokes.map((points) => ({ points }))).slice(0, 3));
      }
      if (event.key === "f" || event.key === "F") {
        if (!event.metaKey && !event.ctrlKey) fit();
      }
      if (event.key === "q" || event.key === "Q") {
        if (!event.metaKey && !event.ctrlKey) setTool("marquee");
      }
      if (event.key === "?") setHelpOpen((current) => !current);
      if ((event.key === "Delete" || event.key === "Backspace") && selected.length > 0) {
        event.preventDefault();
        onSelectionAction("delete", selected);
      }
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "g") {
        event.preventDefault();
        if (selectionBounds) zoomToFit(selectionBounds);
        else fit();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [
    candidates,
    fit,
    onCommitCandidate,
    onSelect,
    onSelectionAction,
    selected,
    selectionBounds,
    strokes,
    tool,
    zoomToFit,
  ]);

  const handleBackgroundPointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    if (event.button !== 0) return;
    if (tool === "draw") {
      (event.currentTarget as HTMLElement).setPointerCapture(event.pointerId);
      drawingInk.current = true;
      setInkPredictions([]);
      setStrokes((current) => [...current, [toCanvas(event.clientX, event.clientY)]]);
      setInteraction(null);
      return;
    }
    setCandidates([]);
    setMenu(null);
    setHelpOpen(false);
    if (!event.shiftKey) onSelect([]);
    (event.currentTarget as HTMLElement).setPointerCapture(event.pointerId);
    if (tool === "marquee" && !event.shiftKey) {
      const point = { x: event.clientX, y: event.clientY };
      setInteraction({ mode: "marquee", start: point, current: point });
    } else {
      setInteraction({
        mode: "pan",
        sx: event.clientX,
        sy: event.clientY,
        px: view.x,
        py: view.y,
      });
    }
  };

  const handleBackgroundPointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    if (drawingInk.current) {
      const point = toCanvas(event.clientX, event.clientY);
      setStrokes((current) => {
        if (current.length === 0) return current;
        const last = current[current.length - 1];
        const tail = last[last.length - 1];
        if (tail && Math.hypot(tail.x - point.x, tail.y - point.y) < 1.25) return current;
        return [...current.slice(0, -1), [...last, point]];
      });
      return;
    }
    if (!interaction) return;
    if (interaction.mode === "pan") {
      setView((current) => ({
        ...current,
        x: interaction.px + (event.clientX - interaction.sx),
        y: interaction.py + (event.clientY - interaction.sy),
      }));
    } else {
      setInteraction({
        ...interaction,
        current: { x: event.clientX, y: event.clientY },
      });
    }
  };

  const handleBackgroundPointerUp = () => {
    if (drawingInk.current) {
      drawingInk.current = false;
      return;
    }
    if (interaction?.mode === "marquee") {
      const rect = containerRef.current?.getBoundingClientRect();
      if (rect) {
        const x0 = Math.min(interaction.start.x, interaction.current.x) - rect.left;
        const x1 = Math.max(interaction.start.x, interaction.current.x) - rect.left;
        const y0 = Math.min(interaction.start.y, interaction.current.y) - rect.top;
        const y1 = Math.max(interaction.start.y, interaction.current.y) - rect.top;
        if (x1 - x0 > 6 && y1 - y0 > 6) {
          const hits = displayGraph.nodes
            .filter((node) => {
              const cx = node.x * view.zoom + view.x;
              const cy = node.y * view.zoom + view.y;
              const halfWidth = (estimateWidth(node) * view.zoom) / 2;
              const halfHeight = (tileHeight() * view.zoom) / 2;
              return cx + halfWidth >= x0 && cx - halfWidth <= x1 && cy + halfHeight >= y0 && cy - halfHeight <= y1;
            })
            .map((node) => node.id);
          onSelect(hits);
        }
      }
    }
    setInteraction(null);
  };

  const startNodeDrag = (event: React.PointerEvent<HTMLDivElement>, node: AuraNode) => {
    if (event.button !== 0) return;
    event.stopPropagation();
    const additive = event.shiftKey || event.metaKey;
    let nextSelected = selected;
    if (additive) {
      nextSelected = selected.includes(node.id)
        ? selected.filter((id) => id !== node.id)
        : [...selected, node.id];
    } else if (!selected.includes(node.id)) {
      nextSelected = [node.id];
    }
    onSelect(nextSelected);

    const currentIndex = indexGraph(graph);
    const movable = new Set<string>();
    const roots = nextSelected.length > 0 ? nextSelected : [node.id];
    for (const id of roots) {
      for (const sub of subtreeIds(currentIndex, id)) movable.add(sub);
    }
    const origin: Record<string, { x: number; y: number }> = {};
    for (const entry of graph.nodes) {
      if (movable.has(entry.id)) origin[entry.id] = { x: entry.x, y: entry.y };
    }
    setCandidates([]);
    setPreview(null);
    setGuides({ x: null, y: null });
    setDrag({
      nodeId: node.id,
      ids: Array.from(movable),
      origin,
      start: toCanvas(event.clientX, event.clientY),
      moved: false,
    });
    (event.currentTarget as HTMLElement).setPointerCapture(event.pointerId);
  };

  const handleNodePointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!drag) return;
    event.stopPropagation();
    const point = toCanvas(event.clientX, event.clientY);
    let dx = point.x - drag.start.x;
    let dy = point.y - drag.start.y;
    const moved = Math.abs(dx) + Math.abs(dy) > 3;

    // Snap the dragged cluster to the centres of stationary vertices.
    const anchor = drag.origin[drag.nodeId];
    let guideX: number | null = null;
    let guideY: number | null = null;
    if (anchor && moved) {
      const threshold = SNAP_DISTANCE / view.zoom;
      const moving = new Set(drag.ids);
      let bestX = threshold;
      let bestY = threshold;
      for (const node of graph.nodes) {
        if (moving.has(node.id)) continue;
        const deltaX = Math.abs(anchor.x + dx - node.x);
        if (deltaX < bestX) {
          bestX = deltaX;
          guideX = node.x;
        }
        const deltaY = Math.abs(anchor.y + dy - node.y);
        if (deltaY < bestY) {
          bestY = deltaY;
          guideY = node.y;
        }
      }
      if (guideX !== null) dx = guideX - anchor.x;
      if (guideY !== null) dy = guideY - anchor.y;
    }
    setGuides({ x: guideX, y: guideY });

    const next: Record<string, { x: number; y: number }> = {};
    for (const id of drag.ids) {
      const origin = drag.origin[id];
      if (origin) next[id] = { x: Math.round(origin.x + dx), y: Math.round(origin.y + dy) };
    }
    setPreview(next);
    if (moved !== drag.moved) setDrag({ ...drag, moved });

    const draggedNow = next[drag.nodeId];
    const now = performance.now();
    if (!draggedNow || now - lastCandidateAt.current < 45) return;
    lastCandidateAt.current = now;
    const previewGraph = applyPreview(graph, next);
    const ghosts = findCandidates(previewGraph, drag.nodeId, draggedNow, { radius: 380 });
    setCandidates(ghosts);
  };

  const handleNodePointerUp = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!drag) return;
    event.stopPropagation();
    const point = toCanvas(event.clientX, event.clientY);
    const dx = point.x - drag.start.x;
    const dy = point.y - drag.start.y;
    const moved = Math.abs(dx) + Math.abs(dy) > 3;
    if (moved) {
      const positions = drag.ids
        .map((id) => {
          const origin = drag.origin[id];
          return origin ? { id, x: Math.round(origin.x + dx), y: Math.round(origin.y + dy) } : null;
        })
        .filter((entry): entry is { id: string; x: number; y: number } => Boolean(entry));
      setGuides({ x: null, y: null });
      onMove(positions);
      setPreview(positions.reduce<Record<string, { x: number; y: number }>>((acc, entry) => {
        acc[entry.id] = { x: entry.x, y: entry.y };
        return acc;
      }, {}));
    }
    setDrag(null);
  };

  const draggedNode = drag ? displayGraph.nodes.find((node) => node.id === drag.nodeId) : undefined;
  const ghostSourceId = drag?.nodeId ?? candidates[0]?.draggedId;
  const ghostSourceNode = ghostSourceId
    ? displayGraph.nodes.find((node) => node.id === ghostSourceId)
    : undefined;
  const ghostStart = ghostSourceNode ? outAnchor(ghostSourceNode) : null;
  const nodeById = index.byId;
  const hoveredNode = hovered ? displayGraph.nodes.find((node) => node.id === hovered) : undefined;
  const hoveredToken = hoveredNode?.kind === "variable" ? hoveredNode.token : null;

  const recogniseInk = useCallback(() => {
    if (strokes.length === 0) return;
    const predictions = classifyInk(strokes.map((points) => ({ points })));
    setInkPredictions(predictions.slice(0, 3));
  }, [strokes]);

  const placeInk = (prediction: InkPrediction) => {
    const all = strokes.flat();
    if (all.length === 0) return;
    const x = all.reduce((sum, point) => sum + point.x, 0) / all.length;
    const y = all.reduce((sum, point) => sum + point.y, 0) / all.length;
    onPlaceRecognized(
      {
        kind: prediction.kind,
        token: prediction.latex,
        label: prediction.label,
        type: prediction.type,
        variant: prediction.variant ?? null,
      },
      { x, y },
    );
    setStrokes([]);
    setInkPredictions([]);
  };

  return (
    <div
      ref={containerRef}
      className="aura-canvas relative h-full w-full overflow-hidden"
      role="application"
      aria-label="Mathematical canvas. Drag vertices to bind them, press 1 to 4 to commit a ghost path, arrow keys to move the focus between vertices."
      tabIndex={0}
      style={
        {
          "--grid-size": `${GRID * view.zoom}px`,
          "--grid-x": `${view.x % (GRID * view.zoom)}px`,
          "--grid-y": `${view.y % (GRID * view.zoom)}px`,
        } as React.CSSProperties
      }
      onPointerDown={handleBackgroundPointerDown}
      onPointerMove={handleBackgroundPointerMove}
      onPointerUp={handleBackgroundPointerUp}
      onPointerCancel={handleBackgroundPointerUp}
      onKeyDown={(event) => {
        const directions: Record<string, { x: number; y: number }> = {
          ArrowLeft: { x: -1, y: 0 },
          ArrowRight: { x: 1, y: 0 },
          ArrowUp: { x: 0, y: -1 },
          ArrowDown: { x: 0, y: 1 },
        };
        const direction = directions[event.key];
        if (!direction) return;
        event.preventDefault();
        const origin =
          selected.length === 1
            ? displayGraph.nodes.find((node) => node.id === selected[0])
            : undefined;
        const pool = displayGraph.nodes.filter((node) => node.id !== origin?.id);
        if (pool.length === 0) return;
        const anchor = origin ?? { x: worldRect.left + 40, y: worldRect.top + 40 };
        let best: AuraNode | null = null;
        let bestScore = Infinity;
        for (const node of pool) {
          const dx = node.x - anchor.x;
          const dy = node.y - anchor.y;
          const forward = dx * direction.x + dy * direction.y;
          if (forward <= 0) continue;
          const lateral = Math.abs(dx * direction.y - dy * direction.x);
          const score = forward + lateral * 1.6;
          if (score < bestScore) {
            bestScore = score;
            best = node;
          }
        }
        if (best) {
          onSelect([best.id]);
          centreOn(best.x, best.y);
        } else if (!origin) {
          const first = pool[0];
          onSelect([first.id]);
          centreOn(first.x, first.y);
        }
      }}
    >
      {/* Scene graph layer */}
      <div
        className="pointer-events-none absolute left-0 top-0 origin-top-left"
        style={{ transform: `translate3d(${view.x}px, ${view.y}px, 0) scale(${view.zoom})` }}
      >
        {/* Cluster envelopes */}
        {clusters.map((cluster) => (
          <div
            key={`cluster-${cluster.id}`}
            className={`cluster-envelope ${cluster.selected ? "is-active" : ""} ${
              selected.length > 0 && !cluster.selected ? "is-dimmed" : ""
            }`}
            style={{ left: cluster.x, top: cluster.y, width: cluster.width, height: cluster.height }}
          >
            <button
              type="button"
              className="cluster-label"
              style={{ pointerEvents: "auto", cursor: "pointer" }}
              onPointerDown={(event) => event.stopPropagation()}
              onClick={(event) => {
                event.stopPropagation();
                onSelect(cluster.nodeIds);
              }}
              title="Select this cluster"
            >
              <span
                className="inline-block h-1 w-1 rounded-full"
                style={{ backgroundColor: cluster.selected ? "#f0b45a" : "#64748b" }}
              />
              cluster {cluster.index} · {cluster.nodeIds.length} V · {cluster.type}
            </button>
          </div>
        ))}

        {/* Alignment guides */}
        {guides.x !== null && (
          <div
            className="guide-line vertical"
            style={{ left: guides.x, top: worldRect.top, height: worldRect.bottom - worldRect.top }}
          />
        )}
        {guides.y !== null && (
          <div
            className="guide-line"
            style={{ top: guides.y, left: worldRect.left, width: worldRect.right - worldRect.left }}
          />
        )}

        <svg
          className="absolute left-0 top-0 overflow-visible"
          width={1}
          height={1}
          style={{ pointerEvents: "none" }}
        >
          {displayGraph.edges.map((edge) => {
            const parent = nodeById.get(edge.source);
            const child = nodeById.get(edge.target);
            if (!parent || !child) return null;
            const portDef = findPort(parent, edge.port);
            if (!portDef) return null;
            const from = portAnchor(parent, portDef);
            const to = { x: child.x, y: child.y };
            const midX = (from.x + to.x) / 2;
            const midY = (from.y + to.y) / 2;
            const dy = (to.y - from.y) * 0.18;
            const isSelected = selected.includes(parent.id) || selected.includes(child.id);
            const invalid = diagnostics.some(
              (entry) => entry.edgeId === edge.id && entry.severity === "error",
            );
            const path = `M ${from.x} ${from.y} Q ${midX} ${midY + dy} ${to.x} ${to.y}`;
            const focusEdge = isSelected || hovered === parent.id || hovered === child.id;
            return (
              <g key={edge.id} opacity={view.zoom < 0.42 ? 0.25 : 1}>
                <path
                  d={path}
                  fill="none"
                  stroke={invalid ? "#fb7185" : isSelected ? "#f0b45a" : "#48607f"}
                  strokeWidth={invalid || isSelected ? 2.2 : 1.5}
                  strokeLinecap="round"
                  opacity={invalid || isSelected ? 0.95 : 0.55}
                  strokeDasharray={invalid ? "2 5" : undefined}
                />
                <circle
                  cx={to.x}
                  cy={to.y}
                  r={view.zoom > 0.7 ? 3 : 2}
                  fill={invalid ? "#fb7185" : "#8aa0bd"}
                  opacity={0.8}
                />
                <circle
                  cx={from.x}
                  cy={from.y}
                  r={focusEdge ? 3 : 2}
                  fill={invalid ? "#fb7185" : "#f0b45a"}
                  opacity={focusEdge ? 0.95 : 0.35}
                />
                {focusEdge && view.zoom > 0.62 && (
                  <text
                    x={from.x + (to.x > from.x ? 6 : -6)}
                    y={from.y - 7}
                    textAnchor={to.x > from.x ? "start" : "end"}
                    fontSize={8.5}
                    fill="#f0b45a"
                    opacity={0.8}
                    fontFamily="ui-monospace, monospace"
                  >
                    {edge.port}
                  </text>
                )}
              </g>
            );
          })}

          {/* Ghost paths */}
          {ghostStart &&
            candidates.map((candidate, offset) => {
              const bend = 46 + offset * 22;
              const controlX = (ghostStart.x + candidate.anchor.x) / 2;
              const controlY = Math.min(ghostStart.y, candidate.anchor.y) - bend;
              const path = `M ${ghostStart.x} ${ghostStart.y} Q ${controlX} ${controlY} ${candidate.anchor.x} ${candidate.anchor.y}`;
              return (
                <g key={`${candidate.kind}-${candidate.targetId}-${candidate.targetPort}-${offset}`}>
                  <path
                    d={path}
                    fill="none"
                    stroke={candidate.color}
                    strokeWidth={2.4}
                    strokeLinecap="round"
                    opacity={0.9}
                    className="ghost-path"
                  />
                  <path
                    d={path}
                    fill="none"
                    stroke="transparent"
                    strokeWidth={26}
                    style={{ pointerEvents: "stroke", cursor: "pointer" }}
                    onPointerDown={(event) => {
                      event.stopPropagation();
                      onCommitCandidate(candidate);
                      clearCandidates();
                    }}
                  />
                  <circle cx={candidate.anchor.x} cy={candidate.anchor.y} r={6} fill={candidate.color} opacity={0.22} />
                  <circle cx={candidate.anchor.x} cy={candidate.anchor.y} r={3.4} fill={candidate.color} />
                </g>
              );
            })}
        </svg>

        {strokes.map((points, offset) => (
          <polyline
            key={`ink-${offset}`}
            points={points.map((point) => `${point.x},${point.y}`).join(" ")}
            fill="none"
            stroke="#f6d7a8"
            strokeWidth={3.2}
            strokeLinecap="round"
            strokeLinejoin="round"
            opacity={0.92}
          />
        ))}

        {/* Ghost expression previews */}
        {candidates.map((candidate, offset) => (
          <div
            key={`ghost-card-${candidate.targetId}-${offset}`}
            className="pointer-events-none absolute -translate-x-1/2 -translate-y-full rounded-2xl border px-3 py-2 rise"
            style={{
              left: candidate.anchor.x,
              top: candidate.anchor.y - 22 - offset * 4,
              borderColor: `${candidate.color}66`,
              background: "rgba(8, 13, 21, 0.93)",
              boxShadow: `0 16px 40px rgba(2,6,23,.5), 0 0 0 1px ${candidate.color}22`,
              maxWidth: 340,
            }}
          >
            <div className="flex items-center gap-2">
              <span
                className="h-2 w-2 shrink-0 rounded-full"
                style={{ backgroundColor: candidate.color }}
              />
              <span className="text-[10px] uppercase tracking-[0.16em]" style={{ color: candidate.color }}>
                {candidate.kind.replace("-", " ")}
              </span>
              <span className="mono text-[10px] text-slate-500">{Math.round(candidate.score * 100)}%</span>
            </div>
            <div className="mt-1 text-slate-100" style={{ fontSize: 19 }}>
              <MathText tex={candidate.previewLatex} />
            </div>
          </div>
        ))}

        {/* Vertex tiles */}
        {displayGraph.nodes
          .filter((node) => {
            if (selected.includes(node.id) || hovered === node.id || drag?.ids.includes(node.id)) return true;
            const halfWidth = estimateWidth(node) / 2;
            return (
              node.x + halfWidth > worldRect.left - CULL_MARGIN &&
              node.x - halfWidth < worldRect.right + CULL_MARGIN &&
              node.y + tileHeight() > worldRect.top - CULL_MARGIN &&
              node.y - tileHeight() < worldRect.bottom + CULL_MARGIN
            );
          })
          .map((node) => {
          const width = estimateWidth(node);
          const isSelected = selected.includes(node.id);
          const issues = diagnosticsByNode[node.id] ?? [];
          const hasError = issues.some((entry) => entry.severity === "error");
          const hasWarning = issues.some((entry) => entry.severity === "warning");
          const isDragged = drag?.ids.includes(node.id) ?? false;
          const showPorts = (isSelected || hovered === node.id || view.zoom > 1.1) && view.zoom > 0.5;
          return (
            <div key={node.id}>
              <div
                className={`node-tile ${isSelected ? "is-selected" : ""} ${hasError ? "is-invalid" : ""} ${
                  !hasError && hasWarning ? "is-warning" : ""
                } ${isDragged ? "is-dragging" : ""} ${node.kind === "group" ? "is-group" : ""} kind-${node.kind}`}
                style={{
                  left: node.x - width / 2,
                  top: node.y - tileHeight() / 2,
                  width,
                  pointerEvents: "auto",
                }}
                onPointerDown={(event) => startNodeDrag(event, node)}
                onPointerMove={handleNodePointerMove}
                onPointerUp={handleNodePointerUp}
                onPointerCancel={handleNodePointerUp}
                onPointerEnter={() => setHovered(node.id)}
                onPointerLeave={() => setHovered((current) => (current === node.id ? null : current))}
                onContextMenu={(event) => {
                  event.preventDefault();
                  event.stopPropagation();
                  const rect = containerRef.current?.getBoundingClientRect();
                  if (!rect) return;
                  onSelect([node.id]);
                  setMenu({
                    id: node.id,
                    x: Math.min(event.clientX - rect.left, Math.max(10, rect.width - 190)),
                    y: Math.min(event.clientY - rect.top, Math.max(10, rect.height - 230)),
                  });
                }}
                onDoubleClick={(event) => {
                  event.stopPropagation();
                  if (node.collapsed) onExpand(node.id);
                  else onSelect(Array.from(componentIds(graph, node.id)));
                }}
                title={`${node.label} · ${node.type}`}
              >
                <span
                  className="absolute -left-[3px] top-1/2 h-2 w-[3px] -translate-y-1/2 rounded-full"
                  style={{ backgroundColor: kindAccent(node.kind) }}
                />
                {scopes.get(node.id) && (
                  <span
                    className="pointer-events-none absolute -inset-[3px] rounded-[17px] transition-opacity"
                    style={{
                      border: `1.5px solid ${scopes.get(node.id)!.color}`,
                      opacity: hoveredToken === node.token ? 0.95 : 0.35,
                      boxShadow:
                        hoveredToken === node.token ? `0 0 20px ${scopes.get(node.id)!.color}66` : undefined,
                    }}
                  />
                )}
                {node.kind === "group" ? (
                  <span className="flex max-w-full items-center gap-1 px-2 text-[13px]">
                    <MathText
                      tex={typeof node.meta?.latex === "string" ? node.meta.latex : node.token}
                      className="truncate"
                    />
                  </span>
                ) : node.kind === "operator" && node.variant === "frac" ? (
                  <span className="flex w-full flex-col items-center gap-[3px] px-2">
                    <span className="h-[2px] w-full rounded bg-slate-300/80" />
                    <span className="text-[8px] uppercase tracking-[0.2em] text-slate-500">frac</span>
                  </span>
                ) : node.kind === "operator" && node.variant === "juxta" ? (
                  <span className="text-slate-400">·</span>
                ) : node.kind === "operator" && node.variant === "power" ? (
                  <span className="mono text-[15px] text-amber-200/80">^</span>
                ) : (
                  <MathText tex={node.token || node.label} />
                )}
                {issues.length > 0 && (
                  <span
                    className="absolute -right-1.5 -top-1.5 flex h-4 w-4 items-center justify-center rounded-full text-[9px] font-bold"
                    style={{
                      backgroundColor: hasError ? "#fb7185" : "#f0b45a",
                      color: "#160d0d",
                    }}
                  >
                    {issues.length}
                  </span>
                )}
                {isSelected && (
                  <span className="absolute -bottom-5 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full border border-amber-300/30 bg-[#0b111b]/90 px-1.5 py-[1px] text-[9px] uppercase tracking-[0.12em] text-amber-200/90">
                    {node.type}
                  </span>
                )}
              </div>

              {showPorts &&
                portsFor(node).map((portDef) => {
                  const occupied = index.children.get(node.id)?.has(portDef.id);
                  const highlighted = isSelected || hovered === node.id;
                  if (!highlighted && (occupied || !portDef.required)) return null;
                  const anchor = portAnchor(node, portDef);
                  return (
                    <span
                      key={portDef.id}
                      className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 rounded-full"
                      style={{
                        left: anchor.x,
                        top: anchor.y,
                        width: occupied ? 6 : 9,
                        height: occupied ? 6 : 9,
                        border: `1.5px solid ${occupied ? "#5eead499" : "#f0b45a"}`,
                        backgroundColor: occupied ? "#5eead455" : "rgba(240,180,90,.2)",
                        boxShadow: occupied ? "none" : "0 0 10px rgba(240,180,90,.5)",
                      }}
                      title={`${portDef.label} · accepts ${portDef.accepts.join(" | ")}`}
                    />
                  );
                })}

              {isSelected &&
                view.zoom > 0.95 &&
                portsFor(node)
                  .filter((portDef) => portDef.required && !index.children.get(node.id)?.has(portDef.id))
                  .map((portDef) => {
                    const anchor = portAnchor(node, portDef);
                    return (
                      <span
                        key={`label-${portDef.id}`}
                        className="port-label"
                        style={{
                          left: anchor.x + (portDef.side === "left" ? -10 : 10),
                          top: anchor.y - 16,
                          transform: portDef.side === "left" ? "translateX(-100%)" : undefined,
                        }}
                      >
                        {portDef.label}
                      </span>
                    );
                  })}
            </div>
          );
        })}

        {hoveredNode && !drag && view.zoom > 0.55 && (
          <div
            className="pointer-events-none absolute -translate-x-1/2 -translate-y-full rounded-xl border border-white/12 px-2 py-1.5 rise"
            style={{
              left: hoveredNode.x,
              top: hoveredNode.y - tileHeight() / 2 - 10,
              background: "rgba(8,13,21,0.96)",
              boxShadow: "0 14px 34px rgba(2,6,23,.55)",
              minWidth: 96,
            }}
          >
            <div className="flex items-center gap-1.5">
              <span
                className="h-1.5 w-1.5 rounded-full"
                style={{ backgroundColor: kindAccent(hoveredNode.kind) }}
              />
              <span className="text-[11px] font-medium text-slate-100">{hoveredNode.label}</span>
            </div>
            <div className="mono mt-0.5 flex items-center gap-1.5 text-[9px] text-slate-500">
              <span className="text-amber-200/80">{effectiveType(index, hoveredNode.id)}</span>
              <span>·</span>
              <span>{portsFor(hoveredNode).length} ports</span>
              <span>·</span>
              <span>{openPorts(index, hoveredNode).length} open</span>
            </div>
          </div>
        )}
      </div>

      <p className="sr-only" aria-live="polite">
        {graph.nodes.length} vertices, {graph.edges.length} bindings, {clusters.length} clusters.
        {selected.length > 0 ? ` ${selected.length} selected.` : ""}
        {errorCount > 0 ? ` ${errorCount} type conflicts.` : " All ports type-coherent."}
      </p>

      {/* HUD: graph summary */}
      <div className="pointer-events-none absolute left-4 top-4 max-w-[min(320px,calc(100%-7.5rem))]">
        <div className="panel flex items-center gap-3 px-3 py-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-amber-300/10 text-amber-200">
            <Icon name="graph" className="h-4 w-4" />
          </span>
          <div className="min-w-0">
            <div className="truncate text-[12px] font-medium text-slate-200">{documentTitle}</div>
            <div className="mono flex items-center gap-2 text-[10px] text-slate-500">
              <span>{graph.nodes.length} V</span>
              <span className="text-slate-700">/</span>
              <span>{graph.edges.length} E</span>
              <span className="text-slate-700">/</span>
              <span className={errorCount > 0 ? "text-rose-300" : warningCount > 0 ? "text-amber-300" : "text-teal-300"}>
                {errorCount > 0
                  ? `${errorCount} conflict${errorCount === 1 ? "" : "s"}`
                  : warningCount > 0
                    ? `${warningCount} open`
                    : "coherent"}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Floating selection actions */}
      {screenSelection && selected.length > 0 && (
        <div
          className="selection-bar"
          style={{
            left: Math.max(10, Math.min(viewport.w - 330, screenSelection.left)),
            top: Math.max(10, screenSelection.top - 46),
          }}
          onPointerDown={(event) => event.stopPropagation()}
        >
          <span className="mono px-1 text-[9.5px] uppercase tracking-[0.1em] text-amber-200/90">
            {selected.length} v
          </span>
          <span className="h-4 w-px bg-white/10" />
          {selected.length === 1 && (
            <button
              type="button"
              className="btn h-7 px-1.5 text-[10px]"
              title="Collapse into one expression vertex"
              disabled={busy}
              onClick={() => onSelectionAction("collapse", selected)}
            >
              <Icon name="collapse" className="h-3 w-3" />
              collapse
            </button>
          )}
          {selected.length > 1 && (
            <button
              type="button"
              className="btn h-7 px-1.5 text-[10px]"
              title="Collapse the selection"
              disabled={busy}
              onClick={() => onSelectionAction("collapse", selected)}
            >
              <Icon name="collapse" className="h-3 w-3" />
              collapse
            </button>
          )}
          <button
            type="button"
            className="btn h-7 px-1.5 text-[10px]"
            title="Fold constant subexpressions"
            disabled={busy}
            onClick={() => onSelectionAction("simplify", selected)}
          >
            <Icon name="spark" className="h-3 w-3" />
            fold
          </button>
          <button
            type="button"
            className="btn h-7 w-7 px-0"
            title="Zoom to this cluster"
            onClick={() => {
              if (selectionBounds) zoomToFit(selectionBounds);
            }}
          >
            <Icon name="fit" className="h-3 w-3" />
          </button>
          <button
            type="button"
            className="btn btn-danger h-7 w-7 px-0"
            title="Delete the selection"
            disabled={busy}
            onClick={() => onSelectionAction("delete", selected)}
          >
            <Icon name="trash" className="h-3 w-3" />
          </button>
          <button
            type="button"
            className="btn h-7 w-7 px-0"
            title="Clear selection (Esc)"
            onClick={() => onSelect([])}
          >
            <Icon name="close" className="h-3 w-3" />
          </button>
        </div>
      )}

      {/* Vertex context menu */}
      {menu && (
        <div
          className="help-popover !w-[184px] !p-1.5"
          style={{ left: menu.x, top: menu.y }}
          onPointerDown={(event) => event.stopPropagation()}
        >
          {(() => {
            const node = nodeById.get(menu.id);
            if (!node) return null;
            return (
              <>
                <div className="flex items-center justify-between px-1.5 py-1">
                  <span className="truncate text-[11px] text-slate-200">{node.label}</span>
                  <span className="mono text-[9px] text-amber-200/80">{effectiveType(index, node.id)}</span>
                </div>
                <div className="hairline my-1" />
                {[
                  {
                    label: "select cluster",
                    icon: "marquee" as const,
                    run: () => onSelect(Array.from(componentIds(graph, node.id))),
                  },
                  {
                    label: node.collapsed ? "expand expression" : "collapse to one vertex",
                    icon: node.collapsed ? ("expand" as const) : ("collapse" as const),
                    run: () =>
                      node.collapsed
                        ? onSelectionAction("expand", [node.id])
                        : onSelectionAction("collapse", selected.length > 1 ? selected : [node.id]),
                  },
                  {
                    label: "fold constants",
                    icon: "spark" as const,
                    run: () => onSelectionAction("simplify", [node.id]),
                  },
                  {
                    label: "zoom to cluster",
                    icon: "fit" as const,
                    run: () => {
                      const bounds = graphBounds(graph);
                      const ids = componentIds(graph, node.id);
                      const nodes = graph.nodes.filter((entry) => ids.has(entry.id));
                      const minX = Math.min(...nodes.map((entry) => entry.x - estimateWidth(entry) / 2));
                      const maxX = Math.max(...nodes.map((entry) => entry.x + estimateWidth(entry) / 2));
                      const minY = Math.min(...nodes.map((entry) => entry.y - tileHeight() / 2));
                      const maxY = Math.max(...nodes.map((entry) => entry.y + tileHeight() / 2));
                      void bounds;
                      zoomToFit({ minX, minY, maxX, maxY });
                    },
                  },
                  {
                    label: "delete vertex",
                    icon: "trash" as const,
                    run: () => onSelectionAction("delete", selected.length > 1 ? selected : [node.id]),
                  },
                ].map((item) => (
                  <button
                    key={item.label}
                    type="button"
                    className={`flex w-full items-center gap-2 rounded-lg px-1.5 py-1.5 text-left text-[11px] transition hover:bg-white/[0.06] ${
                      item.icon === "trash" ? "text-rose-200/90" : "text-slate-300"
                    }`}
                    onClick={() => {
                      item.run();
                      setMenu(null);
                    }}
                  >
                    <Icon name={item.icon} className="h-3 w-3 shrink-0 opacity-70" />
                    {item.label}
                  </button>
                ))}
                <div className="mono px-1.5 pt-1 text-[8.5px] text-slate-600">right-click menu</div>
              </>
            );
          })()}
        </div>
      )}

      {/* Empty canvas guidance */}
      {displayGraph.nodes.length === 0 && (
        <div className="empty-canvas-card" onPointerDown={(event) => event.stopPropagation()}>
          <div className="eyebrow">Empty canvas</div>
          <h2 className="display mt-1 text-[21px] leading-tight text-slate-50">
            Start a hypergraph
          </h2>
          <p className="mt-1.5 text-[12px] leading-relaxed text-slate-400">
            Every symbol you place becomes a typed vertex with open ports. Bind vertices by
            dragging, or let the discovery engine propose the bindings for you.
          </p>
          <div className="mt-3 grid gap-1.5">
            <button type="button" className="btn btn-primary w-full" onClick={onOpenLibrary}>
              <Icon name="docs" className="h-3.5 w-3.5" />
              Browse 338 symbols
            </button>
            <div className="grid grid-cols-2 gap-1.5">
              <button type="button" className="btn" onClick={onOpenInk}>
                <Icon name="pen" className="h-3.5 w-3.5" />
                Write ink
              </button>
              <button type="button" className="btn" onClick={onOpenInk}>
                <Icon name="graph" className="h-3.5 w-3.5" />
                Parse LaTeX
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Minimap */}
      {displayGraph.nodes.length > 0 && (
        <div
          className="minimap"
          style={{ left: 16, bottom: 16 }}
          onPointerDown={(event) => event.stopPropagation()}
          onClick={(event) => {
            const rect = event.currentTarget.getBoundingClientRect();
            const x = (event.clientX - rect.left - minimap.offsetX) / minimap.scale;
            const y = (event.clientY - rect.top - minimap.offsetY) / minimap.scale;
            centreOn(x, y);
          }}
          title="Minimap — click to navigate"
        >
          <svg width={minimap.width} height={minimap.height} className="block">
            <rect
              x={0}
              y={0}
              width={minimap.width}
              height={minimap.height}
              fill="rgba(2,6,23,0.5)"
            />
            {minimap.nodes.map((node) => (
              <rect
                key={`mini-${node.id}`}
                x={node.x - node.w / 2}
                y={node.y - node.h / 2}
                width={node.w}
                height={node.h}
                rx={1.5}
                fill={node.selected ? "#f0b45a" : kindAccent(node.kind)}
                opacity={node.selected ? 0.95 : 0.5}
              />
            ))}
            <rect
              x={minimap.viewport.x}
              y={minimap.viewport.y}
              width={minimap.viewport.w}
              height={minimap.viewport.h}
              fill="rgba(94,234,212,0.08)"
              stroke="rgba(94,234,212,0.7)"
              strokeWidth={1}
              rx={3}
            />
          </svg>
        </div>
      )}

      {/* Help & legend */}
      {helpOpen && (
        <div
          className="help-popover"
          style={{ right: 16, top: 56 }}
          onPointerDown={(event) => event.stopPropagation()}
        >
          <div className="flex items-center justify-between">
            <span className="eyebrow">Canvas legend</span>
            <button type="button" className="btn h-6 w-6 px-0" onClick={() => setHelpOpen(false)}>
              <Icon name="close" className="h-3 w-3" />
            </button>
          </div>
          <div className="mt-2 grid grid-cols-2 gap-1">
            {[
              ["Literal", "#94a3b8"],
              ["Variable", "#94a3b8"],
              ["Operator", "#a78bfa"],
              ["Relation", "#5eead4"],
              ["Container", "#f0b45a"],
              ["Function", "#f472b6"],
              ["Set", "#60a5fa"],
              ["Collapsed", "#5eead4"],
            ].map(([label, color]) => (
              <span key={label} className="flex items-center gap-1.5 text-[10.5px] text-slate-400">
                <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: color }} />
                {label}
              </span>
            ))}
          </div>
          <div className="hairline my-2.5" />
          <div className="space-y-1">
            {[
              ["drag vertex", "reveal ghost bindings"],
              ["1 – 4", "commit a ghost path"],
              ["double-click", "select cluster / expand"],
              ["shift + drag", "add to selection"],
              ["Q / marquee", "box select"],
              ["F", "fit canvas"],
              ["⌘Z / ⇧⌘Z", "undo / redo"],
              ["Esc", "cancel"],
            ].map(([keys, action]) => (
              <div key={keys} className="flex items-center justify-between gap-2">
                <span className="mono text-[9.5px] text-slate-500">{action}</span>
                <span className="kbd">{keys}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* HUD: tools */}
      <div
        className="absolute right-4 top-4 flex items-center gap-1.5 rounded-2xl border border-white/10 bg-[#0a1019]/90 p-1 backdrop-blur-xl"
        onPointerDown={(event) => event.stopPropagation()}
      >
        <button
          type="button"
          className={`btn h-8 w-8 border-transparent px-0 ${tool === "pointer" ? "btn-active" : ""}`}
          onClick={() => setTool("pointer")}
          title="Pan tool (drag nodes to bind)"
          aria-pressed={tool === "pointer"}
          aria-label="Pan tool"
        >
          <Icon name="pointer" />
        </button>
        <button
          type="button"
          className={`btn h-8 w-8 border-transparent px-0 ${tool === "marquee" ? "btn-active" : ""}`}
          onClick={() => setTool("marquee")}
          title="Marquee select"
          aria-pressed={tool === "marquee"}
          aria-label="Marquee select"
        >
          <Icon name="marquee" />
        </button>
        <button
          type="button"
          className={`btn h-8 w-8 border-transparent px-0 ${tool === "draw" ? "btn-active" : ""}`}
          aria-pressed={tool === "draw"}
          aria-label="Pen input"
          onClick={() => {
            setTool("draw");
            setCandidates([]);
          }}
          title="Write directly on the canvas"
        >
          <Icon name="pen" />
        </button>
        <span className="mx-0.5 h-5 w-px bg-white/10" />
        <button
          type="button"
          className="btn h-8 w-8 border-transparent px-0"
          onClick={() => (selectionBounds ? zoomToFit(selectionBounds) : fit())}
          title={selectionBounds ? "Zoom to selection" : "Fit to content (F)"}
        >
          <Icon name="fit" />
        </button>
        <button
          type="button"
          className={`btn h-8 w-8 border-transparent px-0 ${helpOpen ? "btn-active" : ""}`}
          onClick={() => setHelpOpen((current) => !current)}
          title="Legend & shortcuts"
        >
          <Icon name="docs" />
        </button>
      </div>

      {/* HUD: hint */}
      <div className="pointer-events-none absolute bottom-[128px] left-4 hidden max-w-[330px] flex-col gap-1.5 text-[11px] leading-relaxed text-slate-500 sm:flex">
        <div className="flex items-center gap-2">
          <span className="inline-block h-1.5 w-1.5 rounded-full bg-amber-300" />
          Drag a vertex near a cluster to reveal homeomorphic bindings.
        </div>
        <div className="flex items-center gap-2">
          <span className="inline-block h-1.5 w-1.5 rounded-full bg-teal-300" />
          Tap a ghost path (or press 1–4) to commit. Esc cancels.
        </div>
        <div className="flex items-center gap-2">
          <span className="inline-block h-1.5 w-1.5 rounded-full bg-violet-300" />
          Pen tool writes straight onto the canvas; halo colors mark variable scope.
        </div>
        <div className="mono text-[10px] text-slate-600">
          semantic zoom {Math.round(view.zoom * 100)}% · ports {view.zoom > 0.5 ? "visible" : "hidden"}
        </div>
      </div>

      {/* Ink-on-canvas panel */}
      {tool === "draw" && strokes.length > 0 && (
        <div
          className="absolute left-1/2 top-16 z-40 w-[min(460px,calc(100%-2rem))] -translate-x-1/2"
          onPointerDown={(event) => event.stopPropagation()}
        >
          <div className="panel rise p-2.5">
            <div className="flex items-center justify-between gap-2 px-1">
              <div className="flex items-center gap-1.5">
                <Icon name="pen" className="h-3.5 w-3.5 text-amber-200" />
                <span className="eyebrow">Tier 1 · on-device ink</span>
              </div>
              <span className="mono text-[10px] text-slate-500">
                {strokes.length} stroke{strokes.length === 1 ? "" : "s"}
              </span>
            </div>
            <div className="mt-2 flex flex-wrap items-center gap-1.5">
              {inkPredictions.length === 0 ? (
                <button type="button" className="btn btn-primary flex-1" onClick={recogniseInk}>
                  <Icon name="spark" className="h-3.5 w-3.5" />
                  recognise ink
                </button>
              ) : (
                inkPredictions.map((prediction, offset) => (
                  <button
                    key={`${prediction.symbol}-${offset}`}
                    type="button"
                    className="ghost-chip flex-1"
                    onClick={() => placeInk(prediction)}
                  >
                    <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-300/15 text-amber-200">
                      <MathText tex={prediction.latex} />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[10px] uppercase tracking-[0.12em] text-slate-500">
                        {prediction.kind} · {Math.round(prediction.confidence * 100)}%
                      </span>
                      <span className="block truncate text-[11px] text-slate-300">
                        {prediction.type}
                      </span>
                    </span>
                  </button>
                ))
              )}
            </div>
            <div className="mt-2 flex items-center gap-1.5">
              <button
                type="button"
                className="btn h-6 px-1.5 text-[10px]"
                onClick={() => {
                  setStrokes([]);
                  setInkPredictions([]);
                }}
              >
                clear ink
              </button>
              <button type="button" className="btn h-6 px-1.5 text-[10px]" onClick={() => setTool("pointer")}>
                done
              </button>
              <span className="mono ml-auto text-[9.5px] text-slate-600">
                enter to recognise · tap a token to place
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Ghost candidate chips */}
      {candidates.length > 0 && (
        <div className="absolute inset-x-0 bottom-4 z-40 flex justify-center px-3 pr-16 sm:pr-3">
          <div
            className="panel w-full max-w-[720px] p-2.5 rise"
            onPointerDown={(event) => event.stopPropagation()}
          >
            <div className="mb-2 flex items-center justify-between gap-2 px-1">
              <div className="flex items-center gap-2">
                <Icon name="bind" className="h-3.5 w-3.5 text-amber-200" />
                <span className="eyebrow">Homeomorphic candidates</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="mono hidden text-[10px] text-slate-500 sm:inline">
                  tap a path or press 1–{candidates.length}
                </span>
                <button type="button" className="btn h-6 px-1.5 text-[10px]" onClick={clearCandidates}>
                  cancel
                </button>
              </div>
            </div>
            <div className="scroll-thin flex gap-2 overflow-x-auto pb-1">
              {candidates.map((candidate, offset) => (
                <button
                  key={`${candidate.targetId}-${candidate.targetPort}-${offset}`}
                  type="button"
                  className="ghost-chip min-w-[220px] flex-1 text-left"
                  onClick={() => {
                    onCommitCandidate(candidate);
                    clearCandidates();
                  }}
                  disabled={busy}
                  style={{ borderColor: `${candidate.color}44` }}
                >
                  <span
                    className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-[10px] font-semibold"
                    style={{ backgroundColor: `${candidate.color}1f`, color: candidate.color }}
                  >
                    {offset + 1}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[10px] uppercase tracking-[0.12em]" style={{ color: candidate.color }}>
                      {candidate.kind.replace("-", " ")} · {Math.round(candidate.score * 100)}%
                    </span>
                    <span className="block truncate text-[15px] text-slate-100">
                      <MathText tex={candidate.previewLatex} />
                    </span>
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* HUD: zoom */}
      <div
        className="absolute bottom-4 right-4 flex items-center gap-1 rounded-xl border border-white/10 bg-[#0a1019]/90 p-1 backdrop-blur-xl"
        onPointerDown={(event) => event.stopPropagation()}
      >
        <button type="button" className="btn h-8 w-8 border-transparent px-0" onClick={() => zoomTo(view.zoom - 0.15)} title="Zoom out">
          <span className="text-base leading-none">−</span>
        </button>
        <span className="mono w-11 text-center text-[11px] text-slate-400">{Math.round(view.zoom * 100)}%</span>
        <button type="button" className="btn h-8 w-8 border-transparent px-0" onClick={() => zoomTo(view.zoom + 0.15)} title="Zoom in">
          <span className="text-base leading-none">+</span>
        </button>
      </div>

      {/* Marquee */}
      {interaction?.mode === "marquee" && containerRef.current && (() => {
        const rect = containerRef.current.getBoundingClientRect();
        const left = Math.min(interaction.start.x, interaction.current.x) - rect.left;
        const top = Math.min(interaction.start.y, interaction.current.y) - rect.top;
        const width = Math.abs(interaction.current.x - interaction.start.x);
        const height = Math.abs(interaction.current.y - interaction.start.y);
        return (
          <div
            className="pointer-events-none absolute rounded-lg border border-amber-300/70 bg-amber-300/10"
            style={{ left, top, width, height }}
          />
        );
      })()}
    </div>
  );
}
