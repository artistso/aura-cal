"use client";

import { useMemo, useState } from "react";

import type { AuraGraph } from "@/lib/aura/ontology";
import type { DocumentPayload } from "@/lib/aura/engine";
import { Icon } from "./icons";
import { MathText, mathml } from "./MathText";

interface ExportDialogProps {
  open: boolean;
  payload: DocumentPayload;
  expressions: { rootId: string; latex: string; nodeIds: string[] }[];
  onClose: () => void;
  onCopy: (text: string, message: string) => void;
}

type Format = "latex" | "mathml" | "json";

export function ExportDialog({
  open,
  payload,
  expressions,
  onClose,
  onCopy,
}: ExportDialogProps) {
  const [format, setFormat] = useState<Format>("latex");

  const content = useMemo(() => {
    const graph: AuraGraph = payload.graph;
    if (format === "latex") {
      const body = expressions.map((entry) => `\\[\n  ${entry.latex}\n\\]`).join("\n\n");
      return `% Aura · ${payload.document.title}\n% typed hypergraph export (${graph.nodes.length} vertices, ${graph.edges.length} bindings)\n\n${body}\n`;
    }
    if (format === "mathml") {
      return expressions.map((entry) => mathml(entry.latex)).join("\n\n");
    }
    return JSON.stringify(
      {
        format: "aura-typed-hypergraph",
        version: 1,
        document: payload.document,
        ontology: {
          vertex: ["literal", "variable", "operator", "relation", "function", "container", "set", "group"],
          edge: "source --port--> target",
        },
        vertices: graph.nodes.map((node) => ({
          id: node.id,
          kind: node.kind,
          type: node.type,
          token: node.token,
          label: node.label,
          variant: node.variant,
          position: { x: node.x, y: node.y },
          collapsed: node.collapsed,
        })),
        hyperedges: graph.edges.map((edge) => ({
          id: edge.id,
          source: edge.source,
          port: edge.port,
          target: edge.target,
        })),
        serializations: { latex: expressions.map((entry) => entry.latex) },
        transactions: payload.history.map((entry) => ({
          seq: entry.seq,
          action: entry.action,
          summary: entry.summary,
          undone: entry.undone,
        })),
      },
      null,
      2,
    );
  }, [format, expressions, payload]);

  if (!open) return null;

  const extension = format === "latex" ? "tex" : format === "mathml" ? "mathml" : "json";

  const download = () => {
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `aura-${payload.document.title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}.${extension}`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-3 backdrop-blur-sm">
      <div className="panel flex max-h-[88vh] w-full max-w-3xl flex-col overflow-hidden rise">
        <div className="flex items-center justify-between gap-2 border-b border-white/8 px-4 py-3">
          <div>
            <div className="eyebrow">Interop</div>
            <div className="display mt-0.5 text-[20px] text-slate-50">Export the graph</div>
          </div>
          <button type="button" className="btn h-8 w-8 px-0" onClick={onClose} title="Close">
            <Icon name="close" />
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2 border-b border-white/8 px-4 py-2">
          <div className="flex rounded-xl border border-white/10 bg-black/30 p-0.5">
            {(["latex", "mathml", "json"] as Format[]).map((entry) => (
              <button
                key={entry}
                type="button"
                className={`btn h-7 border-transparent px-2.5 text-[11px] uppercase tracking-[0.08em] ${
                  format === entry ? "btn-active" : ""
                }`}
                onClick={() => setFormat(entry)}
              >
                {entry}
              </button>
            ))}
          </div>
          <span className="mono text-[10px] text-slate-600">
            {payload.graph.nodes.length} V · {payload.graph.edges.length} E · {expressions.length} clusters
          </span>
          <div className="ml-auto flex items-center gap-1.5">
            <button type="button" className="btn" onClick={() => onCopy(content, `${format.toUpperCase()} copied`)}>
              <Icon name="copy" className="h-3.5 w-3.5" />
              copy
            </button>
            <button type="button" className="btn btn-primary" onClick={download}>
              <Icon name="export" className="h-3.5 w-3.5" />
              download .{extension}
            </button>
          </div>
        </div>

        <div className="scroll-thin min-h-0 flex-1 overflow-auto p-4">
          {format === "json" ? (
            <pre className="mono whitespace-pre-wrap break-words rounded-xl border border-white/8 bg-black/30 p-3 text-[11px] leading-relaxed text-slate-400">
              {content}
            </pre>
          ) : (
            <div className="space-y-3">
              <div className="space-y-2">
                {expressions.map((entry) => (
                  <div
                    key={entry.rootId}
                    className="rounded-xl border border-white/8 bg-black/25 px-4 py-3 text-[16px] text-slate-100"
                  >
                    <MathText tex={entry.latex} />
                  </div>
                ))}
              </div>
              <pre className="mono whitespace-pre-wrap break-words rounded-xl border border-white/8 bg-black/30 p-3 text-[11px] leading-relaxed text-slate-400">
                {content}
              </pre>
            </div>
          )}
        </div>

        <div className="border-t border-white/8 px-4 py-2.5">
          <p className="text-[10.5px] leading-relaxed text-slate-600">
            LaTeX and MathML are serialisations. The typed hypergraph is the document of record, so it
            travels with port and type information.
          </p>
        </div>
      </div>
    </div>
  );
}
