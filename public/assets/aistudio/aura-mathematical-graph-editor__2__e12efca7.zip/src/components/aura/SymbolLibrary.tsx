"use client";

import { useEffect, useMemo, useState } from "react";

import {
  LIBRARY_COUNT,
  LIBRARY_DOMAINS,
  SYMBOL_LIBRARY,
  type SymbolEntry,
  filterLibrary,
} from "@/lib/aura/library";
import { nodeDisplayKind } from "@/lib/aura/ontology";
import { Icon } from "./icons";
import { MathText } from "./MathText";

interface BrowserProps {
  busy: boolean;
  onPick: (itemId: string, label: string) => void;
  compact?: boolean;
}

function entrySubtitle(entry: SymbolEntry): string {
  return `${entry.label} · ${nodeDisplayKind({
    id: entry.id,
    kind: entry.kind,
    type: entry.type,
    token: entry.token,
    label: entry.label,
    variant: entry.variant,
    x: 0,
    y: 0,
    collapsed: false,
    meta: null,
  })} · ${entry.domain} / ${entry.subdomain}`;
}

export function SymbolBrowser({ busy, onPick, compact = false }: BrowserProps) {
  const [query, setQuery] = useState("");
  const [domain, setDomain] = useState("All");
  const [limit, setLimit] = useState(compact ? 40 : 96);

  useEffect(() => {
    setLimit(compact ? 40 : 96);
  }, [query, domain, compact]);

  const results = useMemo(() => filterLibrary({ query, domain }), [query, domain]);
  const visible = results.slice(0, limit);

  const grouped = useMemo(() => {
    const map = new Map<string, SymbolEntry[]>();
    for (const entry of visible) {
      const key = `${entry.domain} · ${entry.subdomain}`;
      map.set(key, [...(map.get(key) ?? []), entry]);
    }
    return Array.from(map.entries());
  }, [visible]);

  const columns = compact ? 4 : 8;

  return (
    <div className="flex min-h-0 flex-col">
      <div className="relative">
        <span className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500">
          <Icon name="marquee" className="h-3.5 w-3.5" />
        </span>
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder={compact ? "search symbols…" : "search by name, token, domain or variant…"}
          className="field h-9 pl-8 pr-8 text-[12px]"
          spellCheck={false}
        />
        {query && (
          <button
            type="button"
            onClick={() => setQuery("")}
            className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded-md p-1 text-slate-500 hover:text-slate-200"
            title="Clear search"
          >
            <Icon name="close" className="h-3 w-3" />
          </button>
        )}
      </div>

      <div className="scroll-thin mt-2 flex gap-1 overflow-x-auto pb-1">
        <button
          type="button"
          onClick={() => setDomain("All")}
          className={`pill shrink-0 ${domain === "All" ? "border-amber-300/50 bg-amber-300/10 text-amber-200" : "hover:border-white/30"}`}
        >
          all
          <span className="mono text-[9px] text-slate-500">{LIBRARY_COUNT}</span>
        </button>
        {LIBRARY_DOMAINS.map((entry) => (
          <button
            key={entry.domain}
            type="button"
            onClick={() => setDomain(entry.domain === domain ? "All" : entry.domain)}
            className={`pill shrink-0 ${
              domain === entry.domain
                ? "border-amber-300/50 bg-amber-300/10 text-amber-200"
                : "hover:border-white/30"
            }`}
          >
            {entry.domain.toLowerCase()}
            <span className="mono text-[9px] text-slate-500">{entry.count}</span>
          </button>
        ))}
      </div>

      <div className="mt-2 flex items-center justify-between px-0.5">
        <span className="mono text-[9.5px] text-slate-600">
          {results.length === 0 ? "no matches" : `${visible.length} / ${results.length} symbols`}
        </span>
        <span className="mono text-[9.5px] text-slate-600">
          {results.length > 0 ? `${new Set(results.map((entry) => entry.domain)).size} domains` : ""}
        </span>
      </div>

      <div className="scroll-thin mt-1.5 min-h-0 flex-1 overflow-y-auto pr-0.5">
        {results.length === 0 && (
          <p className="rounded-xl border border-white/8 bg-white/[0.02] px-3 py-3 text-[11.5px] leading-relaxed text-slate-500">
            Nothing matches “{query}”. Try a token like <span className="mono text-amber-200/80">\det</span>,
            a name like <span className="mono text-amber-200/80">curl</span>, or a domain like{" "}
            <span className="mono text-amber-200/80">topology</span>.
          </p>
        )}
        {grouped.map(([group, entries]) => (
          <div key={group} className="mb-2.5">
            <div className="mb-1 flex items-center gap-1.5 px-0.5">
              <span className="h-1 w-1 rounded-full bg-slate-600" />
              <span className="truncate text-[9.5px] font-medium uppercase tracking-[0.1em] text-slate-500">
                {group}
              </span>
              <span className="mono text-[9px] text-slate-700">{entries.length}</span>
            </div>
            <div
              className="grid gap-1"
              style={{ gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))` }}
            >
              {entries.map((entry) => (
                <button
                  key={entry.id}
                  type="button"
                  className="tile-button min-h-[40px] px-1 text-[13px]"
                  onClick={() => onPick(entry.id, entry.label)}
                  disabled={busy}
                  title={`${entrySubtitle(entry)} — click to place`}
                >
                  <MathText tex={entry.token} />
                </button>
              ))}
            </div>
          </div>
        ))}
        {results.length > visible.length && (
          <button
            type="button"
            className="btn mb-2 w-full"
            onClick={() => setLimit((current) => current + (compact ? 40 : 96))}
          >
            show {Math.min(compact ? 40 : 96, results.length - visible.length)} more
          </button>
        )}
      </div>
    </div>
  );
}

interface DialogProps {
  open: boolean;
  busy: boolean;
  onClose: () => void;
  onPick: (itemId: string, label: string) => void;
}

export function SymbolLibraryDialog({ open, busy, onClose, onPick }: DialogProps) {
  useEffect(() => {
    if (!open) return;
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-3 backdrop-blur-sm">
      <div className="panel flex max-h-[90vh] w-full max-w-4xl flex-col overflow-hidden rise">
        <div className="flex items-center justify-between gap-2 border-b border-white/8 px-4 py-3">
          <div>
            <div className="eyebrow">Symbol library · {LIBRARY_COUNT} typed vertices</div>
            <div className="display mt-0.5 text-[20px] text-slate-50">Every domain, one canvas</div>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="pill hidden text-teal-200 sm:inline-flex">
              <Icon name="spark" className="h-3 w-3" />
              ports derived per variant
            </span>
            <button type="button" className="btn h-8 w-8 px-0" onClick={onClose} title="Close">
              <Icon name="close" />
            </button>
          </div>
        </div>
        <div className="flex min-h-0 flex-1 flex-col overflow-hidden px-4 py-3">
          <SymbolBrowser
            busy={busy}
            onPick={(id, label) => {
              onPick(id, label);
              onClose();
            }}
          />
        </div>
        <div className="border-t border-white/8 px-4 py-2.5">
          <p className="text-[10.5px] leading-relaxed text-slate-600">
            Algebra, trigonometry (circular, inverse, hyperbolic), calculus (limits, differential,
            integral, series, vector), linear algebra (vectors, matrices, operators), set theory,
            logic, number theory, probability &amp; statistics, geometry &amp; topology, complex
            analysis, abstract algebra, optimization, numerics, special functions, Greek and notation
            — plus closed under composition with every existing port.
          </p>
        </div>
      </div>
    </div>
  );
}

/** Total entries per family, used for the sidebar header count. */
export const LIBRARY_STATS = SYMBOL_LIBRARY.reduce<Record<string, number>>((acc, entry) => {
  acc[entry.domain] = (acc[entry.domain] ?? 0) + 1;
  return acc;
}, {});
