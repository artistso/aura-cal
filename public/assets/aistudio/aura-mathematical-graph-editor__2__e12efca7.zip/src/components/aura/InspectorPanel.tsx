"use client";

import { useMemo } from "react";

import {
  type AuraGraph,
  type Diagnostic,
  arityOf,
  nodeDisplayKind,
  portsFor,
} from "@/lib/aura/ontology";
import {
  childOf,
  componentRoot,
  documentLatex,
  effectiveType,
  indexGraph,
  openPorts,
} from "@/lib/aura/engine";
import type { HistoryEntry } from "@/lib/aura/engine";
import { analyzeCluster, scopeIndex } from "@/lib/aura/evaluate";
import { Icon } from "./icons";
import { MathBlock, MathText } from "./MathText";

interface InspectorPanelProps {
  graph: AuraGraph;
  selected: string[];
  diagnostics: Diagnostic[];
  history: HistoryEntry[];
  busy: boolean;
  onDelete: () => void;
  onCollapse: () => void;
  onExpand: (id: string) => void;
  onReflow: () => void;
  onSimplify: () => void;
  onCopy: (text: string, message: string) => void;
  onSelect: (ids: string[]) => void;
}

const ACTION_COLOR: Record<string, string> = {
  connect: "#5eead4",
  addNode: "#f0b45a",
  move: "#64748b",
  delete: "#fb7185",
  collapse: "#a78bfa",
  expand: "#a78bfa",
  reflow: "#60a5fa",
  insertExpression: "#f0b45a",
};

export function InspectorPanel({
  graph,
  selected,
  diagnostics,
  history,
  busy,
  onDelete,
  onCollapse,
  onExpand,
  onReflow,
  onSimplify,
  onCopy,
  onSelect,
}: InspectorPanelProps) {
  const index = useMemo(() => indexGraph(graph), [graph]);
  const expressions = useMemo(() => documentLatex(graph), [graph]);
  const selectedNodes = graph.nodes.filter((node) => selected.includes(node.id));
  const primary = selectedNodes.length === 1 ? selectedNodes[0] : null;
  const primaryDiagnostics = diagnostics.filter((entry) => selected.includes(entry.nodeId));
  const allErrors = diagnostics.filter((entry) => entry.severity === "error");
  const allWarnings = diagnostics.filter((entry) => entry.severity === "warning");

  const ports = primary
    ? portsFor(primary).map((portDef) => ({
        ...portDef,
        child: childOf(index, primary.id, portDef.id),
      }))
    : [];
  const primaryRoot = primary ? componentRoot(index, primary.id) : undefined;
  const analysis = primary ? analyzeCluster(graph, primary.id, index) : null;
  const scopes = scopeIndex(graph);
  const primaryExpression = primaryRoot
    ? expressions.find((entry) => entry.rootId === primaryRoot.id)
    : undefined;
  const openCount = useMemo(
    () => graph.nodes.reduce((sum, node) => sum + openPorts(index, node).length, 0),
    [graph, index],
  );

  return (
    <div className="flex h-full flex-col overflow-hidden">
      <div className="flex items-center justify-between gap-2 border-b border-white/8 px-4 py-3">
        <div>
          <div className="eyebrow">Type inspector</div>
          <div className="display mt-0.5 text-[17px] text-slate-100">
            {primary
              ? primary.label
              : selectedNodes.length > 1
                ? `${selectedNodes.length} vertices selected`
                : "Graph overview"}
          </div>
        </div>
        <span className="pill" title="Open ports across the whole graph">
          <Icon name="port" className="h-3 w-3" />
          {openCount} open
        </span>
      </div>

      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto px-4 py-4">
        {primary && (
          <div className="space-y-4">
            <div className="panel overflow-hidden">
              <div className="flex items-center justify-center border-b border-white/8 bg-black/20 px-4 py-5 text-[26px] text-slate-100">
                <MathText tex={primary.token || primary.label} />
              </div>
              <div className="grid grid-cols-2 divide-x divide-white/8 border-b border-white/8">
                <div className="px-3 py-2.5">
                  <div className="eyebrow">Inferred type τ</div>
                  <div className="mt-0.5 text-[13px] text-amber-200">
                    {effectiveType(index, primary.id)}
                  </div>
                </div>
                <div className="px-3 py-2.5">
                  <div className="eyebrow">Declared kind</div>
                  <div className="mt-0.5 text-[13px] text-slate-200">{nodeDisplayKind(primary)}</div>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-1.5 px-3 py-2.5">
                <span className="pill">arity {arityOf(primary)}</span>
                <span className="pill">id {primary.id.slice(0, 8)}</span>
                {primary.collapsed && <span className="pill text-teal-200">collapsed</span>}
                {primary.variant && <span className="pill mono">variant:{primary.variant}</span>}
                {analysis?.value !== null && analysis?.value !== undefined && (
                  <span className="pill border-teal-300/40 bg-teal-300/10 text-teal-200">
                    = {Number(analysis.value.toPrecision(6))}
                  </span>
                )}
                {analysis && analysis.variables.length > 0 && (
                  <span className="pill text-violet-200">
                    {analysis.variables.length} free var{analysis.variables.length === 1 ? "" : "s"}
                  </span>
                )}
              </div>
            </div>

            <section>
              <div className="mb-2 flex items-center justify-between">
                <span className="eyebrow">Ports &amp; admissibility</span>
                <span className="mono text-[10px] text-slate-600">{ports.length}</span>
              </div>
              <div className="space-y-1.5">
                {ports.length === 0 && (
                  <p className="rounded-xl border border-white/8 bg-white/[0.02] px-3 py-2 text-[12px] text-slate-500">
                    This vertex exposes no ports; it can still be bound into another vertex.
                  </p>
                )}
                {ports.map((portDef) => (
                  <div
                    key={portDef.id}
                    className={`rounded-xl border px-3 py-2 ${
                      portDef.child
                        ? "border-white/8 bg-white/[0.02]"
                        : "border-amber-300/25 bg-amber-300/[0.05]"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[12px] font-medium text-slate-200">
                        {portDef.label}
                        {portDef.required && <span className="ml-1 text-rose-300/80">*</span>}
                      </span>
                      <span className="mono text-[9.5px] text-slate-500">
                        {portDef.child ? "bound" : "open"}
                      </span>
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-1">
                      <span className="text-[10px] text-slate-500">accepts</span>
                      {portDef.accepts.map((type) => (
                        <span
                          key={type}
                          className="rounded border border-white/10 bg-black/20 px-1 py-[1px] text-[9px] text-slate-400"
                        >
                          {type}
                        </span>
                      ))}
                    </div>
                    {portDef.child ? (
                      <button
                        type="button"
                        onClick={() => onSelect([portDef.child!.id])}
                        className="mt-1.5 flex items-center gap-1.5 text-left text-[11.5px] text-teal-200/90 hover:text-teal-100"
                      >
                        <Icon name="bind" className="h-3 w-3" />
                        <MathText tex={portDef.child.token || portDef.child.label} />
                      </button>
                    ) : (
                      <div className="mt-1 text-[10.5px] text-amber-200/60">{portDef.hint}</div>
                    )}
                  </div>
                ))}
              </div>
            </section>

            <section>
              <div className="mb-2 flex items-center justify-between">
                <span className="eyebrow">Variable scope</span>
                <span className="mono text-[10px] text-slate-600">{scopes.length} symbols</span>
              </div>
              <div className="space-y-1">
                {scopes.map((entry) => {
                  const active = primary.kind === "variable" && primary.token === entry.token;
                  return (
                    <button
                      key={entry.token}
                      type="button"
                      onClick={() => onSelect(entry.nodeIds)}
                      className={`flex w-full items-center gap-2 rounded-xl border px-2.5 py-1.5 text-left transition hover:border-white/25 ${
                        active ? "border-white/25 bg-white/[0.05]" : "border-white/8 bg-white/[0.02]"
                      }`}
                    >
                      <span
                        className="h-2.5 w-2.5 shrink-0 rounded-full"
                        style={{ backgroundColor: entry.color, boxShadow: `0 0 10px ${entry.color}66` }}
                      />
                      <span className="text-[13px] text-slate-100">
                        <MathText tex={entry.token} />
                      </span>
                      <span className="mono ml-auto text-[9.5px] text-slate-500">
                        {entry.nodeIds.length}× · {entry.clusterIds.length} cluster
                        {entry.clusterIds.length === 1 ? "" : "s"}
                      </span>
                    </button>
                  );
                })}
                {scopes.length === 0 && (
                  <p className="text-[11.5px] text-slate-600">
                    No variables yet — place one to give the expression scope.
                  </p>
                )}
              </div>
              <p className="mt-1.5 text-[10px] leading-relaxed text-slate-600">
                Tap a symbol to highlight every occurrence. Shared halos mark symbols that unify
                across clusters.
              </p>
            </section>

            {primaryDiagnostics.length > 0 && (
              <section>
                <div className="eyebrow mb-2">Diagnostics</div>
                <div className="space-y-1.5">
                  {primaryDiagnostics.map((entry, offset) => (
                    <div
                      key={`${entry.message}-${offset}`}
                      className={`flex gap-2 rounded-xl border px-2.5 py-2 text-[11.5px] leading-snug ${
                        entry.severity === "error"
                          ? "border-rose-400/30 bg-rose-400/[0.06] text-rose-200"
                          : "border-amber-300/25 bg-amber-300/[0.05] text-amber-200/90"
                      }`}
                    >
                      <Icon
                        name={entry.severity === "error" ? "error" : "warning"}
                        className="mt-[1px] h-3.5 w-3.5 shrink-0"
                      />
                      <span>{entry.message}</span>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {primaryExpression && (
              <section>
                <div className="mb-2 flex items-center justify-between">
                  <span className="eyebrow">Serialised expression</span>
                  <button
                    type="button"
                    className="btn h-6 px-1.5 text-[10px]"
                    onClick={() => onCopy(primaryExpression.latex, "LaTeX copied")}
                  >
                    <Icon name="copy" className="h-3 w-3" />
                    copy
                  </button>
                </div>
                <div className="panel px-3 py-3 text-[15px] text-slate-100">
                  <MathBlock tex={primaryExpression.latex} />
                  <div className="mono mt-2 truncate border-t border-white/8 pt-2 text-[9.5px] text-slate-600">
                    {primaryExpression.latex}
                  </div>
                </div>
              </section>
            )}

            <div className="grid grid-cols-2 gap-1.5">
              {primary.collapsed ? (
                <button type="button" className="btn" disabled={busy} onClick={() => onExpand(primary.id)}>
                  <Icon name="expand" className="h-3.5 w-3.5" />
                  expand
                </button>
              ) : (
                <button type="button" className="btn" disabled={busy} onClick={onCollapse}>
                  <Icon name="collapse" className="h-3.5 w-3.5" />
                  collapse
                </button>
              )}
              <button type="button" className="btn" disabled={busy} onClick={onReflow}>
                <Icon name="layout" className="h-3.5 w-3.5" />
                auto-layout
              </button>
              <button
                type="button"
                className="btn col-span-2"
                disabled={busy}
                onClick={onSimplify}
                title="Fold every constant subexpression into a literal"
              >
                <Icon name="spark" className="h-3.5 w-3.5" />
                fold constants
              </button>
              <button
                type="button"
                className="btn btn-danger col-span-2"
                disabled={busy}
                onClick={onDelete}
              >
                <Icon name="trash" className="h-3.5 w-3.5" />
                delete vertex
              </button>
            </div>
          </div>
        )}

        {selectedNodes.length > 1 && (
          <div className="space-y-3">
            <div className="panel px-3 py-3">
              <div className="eyebrow mb-2">Selection</div>
              <div className="flex flex-wrap gap-1.5">
                {selectedNodes.map((node) => (
                  <button
                    key={node.id}
                    type="button"
                    onClick={() => onSelect([node.id])}
                    className="tile-button h-9 min-h-0 px-2 py-0 text-[13px]"
                  >
                    <MathText tex={node.token || node.label} />
                  </button>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              <button type="button" className="btn" disabled={busy} onClick={onCollapse}>
                <Icon name="collapse" className="h-3.5 w-3.5" />
                collapse all
              </button>
              <button type="button" className="btn" disabled={busy} onClick={onReflow}>
                <Icon name="layout" className="h-3.5 w-3.5" />
                auto-layout
              </button>
              <button
                type="button"
                className="btn col-span-2"
                disabled={busy}
                onClick={onSimplify}
                title="Fold every constant subexpression into a literal"
              >
                <Icon name="spark" className="h-3.5 w-3.5" />
                fold constants
              </button>
              <button type="button" className="btn btn-danger col-span-2" disabled={busy} onClick={onDelete}>
                <Icon name="trash" className="h-3.5 w-3.5" />
                delete {selectedNodes.length} vertices
              </button>
            </div>
          </div>
        )}

        {!primary && selectedNodes.length === 0 && (
          <div className="space-y-4">
            <section>
              <div className="mb-2 flex items-center justify-between">
                <span className="eyebrow">Derived expressions</span>
                <span className="mono text-[10px] text-slate-600">{expressions.length}</span>
              </div>
              <div className="space-y-1.5">
                {expressions.map((expression, offset) => (
                  <div key={expression.rootId} className="panel px-3 py-2.5">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1 text-[14px] text-slate-100">
                        <MathBlock tex={expression.latex} />
                      </div>
                      <button
                        type="button"
                        className="btn h-6 shrink-0 px-1.5 text-[10px]"
                        onClick={() => onCopy(expression.latex, "LaTeX copied")}
                        title="Copy LaTeX"
                      >
                        <Icon name="copy" className="h-3 w-3" />
                      </button>
                    </div>
                    <div className="mono mt-1 flex items-center gap-2 text-[9.5px] text-slate-600">
                      <span>cluster {offset + 1}</span>
                      <span>·</span>
                      <span>{expression.nodeIds.length} vertices</span>
                    </div>
                  </div>
                ))}
                {expressions.length === 0 && (
                  <p className="rounded-xl border border-white/8 bg-white/[0.02] px-3 py-3 text-[12px] text-slate-500">
                    The canvas is empty. Place an element or write an expression with the pen.
                  </p>
                )}
              </div>
            </section>

            <section>
              <div className="mb-2 flex items-center justify-between">
                <span className="eyebrow">Coherence</span>
                <div className="flex gap-1">
                  <span className={`pill ${allErrors.length ? "text-rose-300" : "text-teal-200"}`}>
                    {allErrors.length} errors
                  </span>
                  <span className="pill text-amber-200">{allWarnings.length} open</span>
                </div>
              </div>
              <div className="space-y-1.5">
                {diagnostics.slice(0, 6).map((entry, offset) => (
                  <button
                    key={`${entry.nodeId}-${offset}`}
                    type="button"
                    onClick={() => onSelect([entry.nodeId])}
                    className={`flex w-full gap-2 rounded-xl border px-2.5 py-2 text-left text-[11.5px] leading-snug ${
                      entry.severity === "error"
                        ? "border-rose-400/25 bg-rose-400/[0.05] text-rose-200"
                        : "border-white/8 bg-white/[0.02] text-slate-400"
                    }`}
                  >
                    <Icon
                      name={entry.severity === "error" ? "error" : "warning"}
                      className="mt-[1px] h-3.5 w-3.5 shrink-0"
                    />
                    <span>{entry.message}</span>
                  </button>
                ))}
                {diagnostics.length === 0 && (
                  <p className="rounded-xl border border-teal-300/20 bg-teal-300/[0.05] px-3 py-2.5 text-[12px] text-teal-200/80">
                    Every bound port is type-coherent. Drag a vertex to explore new bindings.
                  </p>
                )}
              </div>
            </section>

            <section>
              <div className="mb-2 flex items-center justify-between">
                <span className="eyebrow">Graph transactions</span>
                <Icon name="history" className="h-3.5 w-3.5 text-slate-600" />
              </div>
              <div className="space-y-1">
                {history.slice(0, 10).map((entry) => (
                  <div
                    key={entry.id}
                    className={`flex items-start gap-2 rounded-lg px-2 py-1.5 text-[11px] ${
                      entry.undone ? "opacity-40" : ""
                    }`}
                  >
                    <span
                      className="mt-[5px] h-1.5 w-1.5 shrink-0 rounded-full"
                      style={{ backgroundColor: ACTION_COLOR[entry.action] ?? "#64748b" }}
                    />
                    <div className="min-w-0 flex-1">
                      <div className={`truncate text-slate-300 ${entry.undone ? "line-through" : ""}`}>
                        {entry.summary}
                      </div>
                      <div className="mono text-[9px] text-slate-600">
                        #{entry.seq} · {entry.action}
                        {entry.undone ? " · undone" : ""}
                      </div>
                    </div>
                  </div>
                ))}
                {history.length === 0 && (
                  <p className="text-[11.5px] text-slate-600">No mutations recorded yet.</p>
                )}
              </div>
            </section>
          </div>
        )}
      </div>

      <div className="border-t border-white/8 px-4 py-2.5">
        <p className="text-[10.5px] leading-relaxed text-slate-600">
          Typed hypergraph H = (V, E, τ). Edges carry port semantics, so every mutation is a
          reversible graph transaction.
        </p>
      </div>
    </div>
  );
}
