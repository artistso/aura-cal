"use client";

import { useMemo, useState } from "react";

import type { AuraGraph } from "@/lib/aura/ontology";
import { analyzeGraph, plotSamples, sampleRange } from "@/lib/aura/evaluate";
import { Icon } from "./icons";
import { MathText } from "./MathText";

const VIEW_W = 340;
const VIEW_H = 214;
const PAD = { left: 34, right: 12, top: 12, bottom: 26 };

function niceTicks(min: number, max: number, count: number): number[] {
  if (!Number.isFinite(min) || !Number.isFinite(max) || min === max) return [min];
  const span = max - min;
  const rough = span / count;
  const magnitude = Math.pow(10, Math.floor(Math.log10(rough)));
  const candidates = [1, 2, 2.5, 5, 10].map((step) => step * magnitude);
  const step = candidates.find((candidate) => candidate >= rough) ?? candidates[candidates.length - 1];
  const start = Math.ceil(min / step) * step;
  const ticks: number[] = [];
  for (let value = start; value <= max + step * 0.001; value += step) {
    ticks.push(Math.abs(value) < step * 0.001 ? 0 : Number(value.toFixed(6)));
  }
  return ticks;
}

function formatTick(value: number): string {
  if (Math.abs(value) >= 1000) return value.toExponential(1);
  if (Number.isInteger(value)) return String(value);
  return String(Number(value.toPrecision(3)));
}

interface PlotPanelProps {
  graph: AuraGraph;
  onSelect: (ids: string[]) => void;
}

export function PlotPanel({ graph, onSelect }: PlotPanelProps) {
  const analyses = useMemo(() => analyzeGraph(graph), [graph]);
  const plottable = useMemo(() => analyses.filter((entry) => entry.plottable), [analyses]);
  const constants = useMemo(() => analyses.filter((entry) => entry.value !== null), [analyses]);
  const [pickedRoot, setPickedRoot] = useState<string | null>(null);
  const [domain, setDomain] = useState<{ min: number; max: number }>({ min: -6, max: 6 });
  const [hover, setHover] = useState<{ x: number; y: number } | null>(null);

  const active = plottable.find((entry) => entry.rootId === pickedRoot) ?? plottable[0] ?? null;
  const target = active?.plottable ?? null;

  const samples = useMemo(
    () =>
      target
        ? plotSamples(graph, target.yRootId, domain.min, domain.max, 300, target.variable)
        : [],
    [graph, target, domain],
  );
  const range = useMemo(() => sampleRange(samples), [samples]);
  const xTicks = niceTicks(domain.min, domain.max, 6);
  const yTicks = niceTicks(range.min, range.max, 5);

  const plotW = VIEW_W - PAD.left - PAD.right;
  const plotH = VIEW_H - PAD.top - PAD.bottom;
  const px = (x: number) => PAD.left + ((x - domain.min) / (domain.max - domain.min)) * plotW;
  const py = (y: number) =>
    PAD.top + plotH - ((y - range.min) / (range.max - range.min)) * plotH;

  const path = useMemo(() => {
    if (samples.length === 0) return "";
    let d = "";
    let previousInside = false;
    samples.forEach((point) => {
      const inside = point.y >= range.min - (range.max - range.min) * 0.6 && point.y <= range.max + (range.max - range.min) * 0.6;
      if (!inside) {
        previousInside = false;
        return;
      }
      const command = previousInside ? "L" : "M";
      d += `${command} ${px(point.x).toFixed(2)} ${py(point.y).toFixed(2)} `;
      previousInside = true;
    });
    return d;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [samples, range.min, range.max, domain.min, domain.max]);

  const zoom = (factor: number) => {
    const center = (domain.min + domain.max) / 2;
    const half = ((domain.max - domain.min) / 2) * factor;
    setDomain({ min: Number((center - half).toFixed(3)), max: Number((center + half).toFixed(3)) });
  };

  const handleMove = (event: React.PointerEvent<SVGSVGElement>) => {
    if (samples.length === 0) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const relative = ((event.clientX - rect.left) / rect.width) * VIEW_W;
    const x = domain.min + ((relative - PAD.left) / plotW) * (domain.max - domain.min);
    let nearest = samples[0];
    for (const point of samples) {
      if (Math.abs(point.x - x) < Math.abs(nearest.x - x)) nearest = point;
    }
    setHover({ x: nearest.x, y: nearest.y });
  };

  return (
    <div className="flex h-full flex-col overflow-hidden">
      <div className="border-b border-white/8 px-4 py-3">
        <div className="eyebrow">Plot view</div>
        <div className="display mt-0.5 text-[17px] text-slate-100">
          {target ? "Numeric trace" : "No plottable object"}
        </div>
      </div>

      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto px-4 py-4">
        {plottable.length > 0 && (
          <div className="mb-2 flex flex-wrap gap-1.5">
            {plottable.map((entry) => (
              <button
                key={entry.rootId}
                type="button"
                onClick={() => setPickedRoot(entry.rootId)}
                className={`pill max-w-full truncate ${
                  active?.rootId === entry.rootId
                    ? "border-amber-300/50 bg-amber-300/10 text-amber-200"
                    : "hover:border-white/30"
                }`}
              >
                <MathText tex={entry.latex} />
              </button>
            ))}
          </div>
        )}

        {target ? (
          <div className="panel overflow-hidden">
            <div className="flex items-center justify-between gap-2 border-b border-white/8 bg-black/20 px-3 py-2">
              <div className="min-w-0 text-[14px] text-slate-100">
                <MathText tex={target.yLatex} />
              </div>
              <span className="mono shrink-0 text-[9.5px] text-slate-500">
                f({target.variable}) · {samples.length} pts
              </span>
            </div>
            <svg
              viewBox={`0 0 ${VIEW_W} ${VIEW_H}`}
              className="w-full touch-none"
              onPointerMove={handleMove}
              onPointerLeave={() => setHover(null)}
            >
              <rect
                x={PAD.left}
                y={PAD.top}
                width={plotW}
                height={plotH}
                fill="rgba(2,6,23,0.5)"
                stroke="rgba(148,163,184,0.16)"
                rx={6}
              />
              {xTicks.map((tick) => (
                <g key={`x-${tick}`}>
                  <line
                    x1={px(tick)}
                    y1={PAD.top}
                    x2={px(tick)}
                    y2={PAD.top + plotH}
                    stroke="rgba(148,163,184,0.1)"
                  />
                  <text
                    x={px(tick)}
                    y={VIEW_H - 8}
                    textAnchor="middle"
                    fontSize="8.5"
                    fill="#64748b"
                    fontFamily="ui-monospace, monospace"
                  >
                    {formatTick(tick)}
                  </text>
                </g>
              ))}
              {yTicks.map((tick) => (
                <g key={`y-${tick}`}>
                  <line
                    x1={PAD.left}
                    y1={py(tick)}
                    x2={PAD.left + plotW}
                    y2={py(tick)}
                    stroke="rgba(148,163,184,0.1)"
                  />
                  <text
                    x={PAD.left - 5}
                    y={py(tick) + 3}
                    textAnchor="end"
                    fontSize="8.5"
                    fill="#64748b"
                    fontFamily="ui-monospace, monospace"
                  >
                    {formatTick(tick)}
                  </text>
                </g>
              ))}
              {range.min <= 0 && range.max >= 0 && (
                <line
                  x1={PAD.left}
                  y1={py(0)}
                  x2={PAD.left + plotW}
                  y2={py(0)}
                  stroke="rgba(148,163,184,0.35)"
                />
              )}
              {domain.min <= 0 && domain.max >= 0 && (
                <line
                  x1={px(0)}
                  y1={PAD.top}
                  x2={px(0)}
                  y2={PAD.top + plotH}
                  stroke="rgba(148,163,184,0.35)"
                />
              )}
              <path d={path} fill="none" stroke="#f0b45a" strokeWidth={2} strokeLinecap="round" />
              {hover && (
                <g>
                  <line
                    x1={px(hover.x)}
                    y1={PAD.top}
                    x2={px(hover.x)}
                    y2={PAD.top + plotH}
                    stroke="rgba(94,234,212,0.5)"
                    strokeDasharray="3 3"
                  />
                  <circle cx={px(hover.x)} cy={py(hover.y)} r={3.4} fill="#5eead4" />
                </g>
              )}
            </svg>
            <div className="flex items-center justify-between gap-2 border-t border-white/8 px-3 py-2">
              <div className="mono text-[10px] text-teal-200/90">
                {hover
                  ? `f(${Number(hover.x.toPrecision(4))}) = ${Number(hover.y.toPrecision(5))}`
                  : `domain [${domain.min}, ${domain.max}]`}
              </div>
              <div className="flex items-center gap-1">
                <button type="button" className="btn h-6 px-1.5 text-[10px]" onClick={() => zoom(0.6)}>
                  in
                </button>
                <button type="button" className="btn h-6 px-1.5 text-[10px]" onClick={() => zoom(1.6)}>
                  out
                </button>
                <button
                  type="button"
                  className="btn h-6 px-1.5 text-[10px]"
                  onClick={() => setDomain({ min: -6, max: 6 })}
                >
                  reset
                </button>
                <button
                  type="button"
                  className="btn h-6 px-1.5 text-[10px]"
                  onClick={() => onSelect(active ? [active.rootId] : [])}
                >
                  locate
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="rounded-xl border border-white/8 bg-white/[0.02] px-3 py-3 text-[12px] leading-relaxed text-slate-500">
            A cluster becomes plottable when it is a function of a single variable — bind a variable
            into a function vertex, or build <span className="mono text-amber-200/80">y = f(x)</span> with
            a relation. Values are sampled by walking the graph&apos;s ports, not by re-parsing text.
          </div>
        )}

        <section className="mt-4">
          <div className="mb-2 flex items-center justify-between">
            <span className="eyebrow">Evaluated clusters</span>
            <span className="mono text-[10px] text-slate-600">{constants.length}</span>
          </div>
          <div className="space-y-1.5">
            {constants.map((entry) => (
              <button
                key={entry.rootId}
                type="button"
                onClick={() => onSelect([entry.rootId])}
                className="flex w-full items-center justify-between gap-2 rounded-xl border border-white/8 bg-white/[0.02] px-2.5 py-2 text-left hover:border-white/20"
              >
                <span className="min-w-0 text-[13px] text-slate-200">
                  <MathText tex={entry.latex} />
                </span>
                <span className="mono shrink-0 text-[10px] text-teal-200">
                  = {Number((entry.value ?? 0).toPrecision(6))}
                </span>
              </button>
            ))}
            {constants.length === 0 && (
              <p className="text-[11.5px] text-slate-600">
                No fully numeric cluster yet. Fold constants from the inspector to evaluate one.
              </p>
            )}
          </div>
        </section>

        <section className="mt-4">
          <div className="mb-2 flex items-center gap-1.5">
            <Icon name="spark" className="h-3 w-3 text-amber-300/70" />
            <span className="eyebrow">Plot pane architecture</span>
          </div>
          <p className="rounded-xl border border-white/8 bg-white/[0.02] px-3 py-2 text-[11px] leading-relaxed text-slate-500">
            The plot is kept out of the canvas scene graph: the canvas stays gesture-rich, while
            plottable vertices are sampled on demand into this pane — the same separation as the
            Matplotlib pane in the tablet build.
          </p>
        </section>
      </div>
    </div>
  );
}
