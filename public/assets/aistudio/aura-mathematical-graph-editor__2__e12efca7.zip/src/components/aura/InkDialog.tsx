"use client";

import { useEffect, useRef, useState } from "react";

import type { InkPrediction, Stroke } from "@/lib/aura/recognize";
import type { MathType, NodeKind } from "@/lib/aura/ontology";
import { Icon } from "./icons";
import { MathText } from "./MathText";

interface InkDialogProps {
  open: boolean;
  onClose: () => void;
  busy: boolean;
  onInsertNode: (node: {
    kind: NodeKind;
    token: string;
    label: string;
    type: MathType;
    variant: string | null;
  }) => void;
  onInsertLatex: (latex: string) => void;
  onNotify: (message: string, tone?: "ok" | "error") => void;
}

interface LatexPreview {
  latex: string;
  nodeCount: number;
  edgeCount: number;
}

const VIEW_W = 640;
const VIEW_H = 280;

export function InkDialog({
  open,
  onClose,
  busy,
  onInsertNode,
  onInsertLatex,
  onNotify,
}: InkDialogProps) {
  const [tab, setTab] = useState<"ink" | "latex">("ink");
  const [strokes, setStrokes] = useState<Stroke[]>([]);
  const drawing = useRef(false);
  const [recognizing, setRecognizing] = useState(false);
  const [predictions, setPredictions] = useState<InkPrediction[]>([]);
  const [needsFallback, setNeedsFallback] = useState(false);
  const [tierLabel, setTierLabel] = useState("Tier 1 · on-device classifier");
  const [chosen, setChosen] = useState(0);
  const [latex, setLatex] = useState("E = mc^2");
  const [preview, setPreview] = useState<LatexPreview | null>(null);
  const [parseError, setParseError] = useState<string | null>(null);
  const [parsing, setParsing] = useState(false);

  useEffect(() => {
    if (!open) return;
    setStrokes([]);
    setPredictions([]);
    setNeedsFallback(false);
    setChosen(0);
    setPreview(null);
    setParseError(null);
  }, [open]);

  if (!open) return null;

  const pointFromEvent = (event: React.PointerEvent<SVGSVGElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    return {
      x: ((event.clientX - rect.left) / rect.width) * VIEW_W,
      y: ((event.clientY - rect.top) / rect.height) * VIEW_H,
    };
  };

  const handlePointerDown = (event: React.PointerEvent<SVGSVGElement>) => {
    event.currentTarget.setPointerCapture(event.pointerId);
    drawing.current = true;
    setStrokes((current) => [...current, { points: [pointFromEvent(event)] }]);
    setPredictions([]);
  };

  const handlePointerMove = (event: React.PointerEvent<SVGSVGElement>) => {
    if (!drawing.current) return;
    const point = pointFromEvent(event);
    setStrokes((current) => {
      if (current.length === 0) return current;
      const last = current[current.length - 1];
      return [...current.slice(0, -1), { points: [...last.points, point] }];
    });
  };

  const handlePointerUp = () => {
    drawing.current = false;
  };

  const recognize = async () => {
    if (strokes.length === 0) {
      onNotify("Draw a symbol first", "error");
      return;
    }
    setRecognizing(true);
    try {
      const response = await fetch("/api/recognize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode: "ink", strokes }),
      });
      const data = (await response.json()) as {
        predictions?: InkPrediction[];
        needsFallback?: boolean;
        tierLabel?: string;
        error?: string;
      };
      if (!response.ok) throw new Error(data.error ?? "Recognition failed");
      setPredictions(data.predictions ?? []);
      setNeedsFallback(Boolean(data.needsFallback));
      setTierLabel(data.tierLabel ?? "Tier 1 · on-device classifier");
      setChosen(0);
    } catch (error) {
      onNotify(error instanceof Error ? error.message : "Recognition failed", "error");
    } finally {
      setRecognizing(false);
    }
  };

  const parseStructure = async () => {
    setParsing(true);
    setParseError(null);
    try {
      const response = await fetch("/api/recognize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode: "latex", latex }),
      });
      const data = (await response.json()) as {
        latex?: string;
        nodeCount?: number;
        edgeCount?: number;
        error?: string;
      };
      if (!response.ok) throw new Error(data.error ?? "Could not parse that expression");
      setPreview({
        latex: data.latex ?? latex,
        nodeCount: data.nodeCount ?? 0,
        edgeCount: data.edgeCount ?? 0,
      });
    } catch (error) {
      setPreview(null);
      setParseError(error instanceof Error ? error.message : "Could not parse that expression");
    } finally {
      setParsing(false);
    }
  };

  const selectedPrediction = predictions[chosen];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-3 backdrop-blur-sm">
      <div className="panel w-full max-w-3xl overflow-hidden rise">
        <div className="flex items-center justify-between gap-2 border-b border-white/8 px-4 py-3">
          <div>
            <div className="eyebrow">Recognition pipeline</div>
            <div className="display mt-0.5 text-[20px] text-slate-50">Write it, don&apos;t type it</div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex rounded-xl border border-white/10 bg-black/30 p-0.5">
              <button
                type="button"
                className={`btn h-7 border-transparent px-2.5 text-[11px] ${tab === "ink" ? "btn-active" : ""}`}
                onClick={() => setTab("ink")}
              >
                <Icon name="pen" className="h-3 w-3" />
                pen
              </button>
              <button
                type="button"
                className={`btn h-7 border-transparent px-2.5 text-[11px] ${tab === "latex" ? "btn-active" : ""}`}
                onClick={() => setTab("latex")}
              >
                <Icon name="graph" className="h-3 w-3" />
                structure
              </button>
            </div>
            <button type="button" className="btn h-8 w-8 px-0" onClick={onClose} title="Close">
              <Icon name="close" />
            </button>
          </div>
        </div>

        <div className="grid gap-4 p-4 md:grid-cols-[1.25fr_1fr]">
          {tab === "ink" ? (
            <div>
              <div className="mb-2 flex items-center justify-between">
                <span className="eyebrow">Ink surface</span>
                <span className="mono text-[10px] text-slate-600">{strokes.length} strokes</span>
              </div>
              <svg
                viewBox={`0 0 ${VIEW_W} ${VIEW_H}`}
                className="ink-surface h-[240px] w-full"
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onPointerCancel={handlePointerUp}
              >
                {strokes.map((stroke, offset) => (
                  <polyline
                    key={offset}
                    points={stroke.points.map((point) => `${point.x},${point.y}`).join(" ")}
                    fill="none"
                    stroke="#f4d4a0"
                    strokeWidth={5}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    opacity={0.92}
                  />
                ))}
                {strokes.length === 0 && (
                  <text
                    x={VIEW_W / 2}
                    y={VIEW_H / 2}
                    textAnchor="middle"
                    fill="#475569"
                    fontSize="13"
                    fontFamily="ui-monospace, monospace"
                  >
                    draw = + x 1 2 ∫ …
                  </text>
                )}
              </svg>
              <div className="mt-2 flex items-center gap-1.5">
                <button
                  type="button"
                  className="btn btn-primary flex-1"
                  onClick={recognize}
                  disabled={recognizing || strokes.length === 0}
                >
                  <Icon name="spark" className="h-3.5 w-3.5" />
                  {recognizing ? "recognising…" : "recognise strokes"}
                </button>
                <button
                  type="button"
                  className="btn"
                  onClick={() => {
                    setStrokes([]);
                    setPredictions([]);
                  }}
                  disabled={strokes.length === 0}
                >
                  clear
                </button>
              </div>
              <p className="mt-2 text-[10.5px] leading-relaxed text-slate-600">
                Tier 1 runs continuously and returns typed tokens with confidence. Low confidence
                escalates to Tier 2 structural recovery — the canvas never blocks.
              </p>
            </div>
          ) : (
            <div>
              <div className="mb-2 flex items-center justify-between">
                <span className="eyebrow">Tier 2 · structural recovery</span>
                <span className="pill text-teal-200">builds typed vertices</span>
              </div>
              <textarea
                className="field mono h-[108px] resize-none"
                value={latex}
                onChange={(event) => setLatex(event.target.value)}
                placeholder="E = mc^2   ·   \frac{a}{b}   ·   \int_{0}^{1} x^2"
                spellCheck={false}
              />
              <div className="mt-2 flex items-center gap-1.5">
                <button type="button" className="btn btn-primary flex-1" onClick={parseStructure} disabled={parsing}>
                  <Icon name="graph" className="h-3.5 w-3.5" />
                  {parsing ? "parsing…" : "parse into graph"}
                </button>
                <button
                  type="button"
                  className="btn"
                  disabled={!preview || busy}
                  onClick={() => {
                    onInsertLatex(latex);
                    onClose();
                  }}
                >
                  place
                </button>
              </div>
              {parseError && (
                <p className="mt-2 rounded-lg border border-rose-400/30 bg-rose-400/[0.06] px-2 py-1.5 text-[11px] text-rose-200">
                  {parseError}
                </p>
              )}
              {preview && (
                <div className="mt-2 rounded-xl border border-white/10 bg-black/25 px-3 py-2.5">
                  <div className="text-[16px] text-slate-100">
                    <MathText tex={preview.latex} display />
                  </div>
                  <div className="mono mt-1 flex items-center gap-2 text-[9.5px] text-slate-500">
                    <span>{preview.nodeCount} vertices</span>
                    <span>·</span>
                    <span>{preview.edgeCount} bindings</span>
                    <span>·</span>
                    <span>lossless round-trip</span>
                  </div>
                </div>
              )}
              <div className="mt-3 flex flex-wrap gap-1.5">
                {["E = mc^2", "a^2 + b^2 = c^2", "\\frac{a}{b}", "\\int_{0}^{1} x^2", "\\sin x"].map(
                  (sample) => (
                    <button
                      key={sample}
                      type="button"
                      className="pill mono hover:border-amber-300/40 hover:text-amber-200"
                      onClick={() => setLatex(sample)}
                    >
                      {sample}
                    </button>
                  ),
                )}
              </div>
            </div>
          )}

          <div className="rounded-2xl border border-white/8 bg-black/25 p-3">
            <div className="eyebrow mb-2">Recognizer output</div>
            {tab === "ink" ? (
              predictions.length === 0 ? (
                <div className="space-y-2">
                  <p className="text-[11.5px] leading-relaxed text-slate-500">
                    Draw a symbol on the surface, then recognise. The classifier reports typed
                    tokens, not just a string.
                  </p>
                  <div className="rounded-xl border border-white/8 bg-white/[0.02] px-2.5 py-2">
                    <div className="flex items-center gap-1.5 text-[10px] text-amber-200/80">
                      <Icon name="warning" className="h-3 w-3" />
                      {tierLabel}
                    </div>
                    <div className="mono mt-1 text-[9.5px] leading-relaxed text-slate-600">
                      tier 1 → symbol · kind · type
                      <br />
                      tier 2 → LaTeX span · 2D structure
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  {needsFallback && (
                    <div className="rounded-lg border border-amber-300/30 bg-amber-300/[0.06] px-2 py-1.5 text-[10.5px] text-amber-200">
                      Confidence below floor — escalate to Tier 2 for structural recovery.
                    </div>
                  )}
                  {predictions.map((prediction, offset) => (
                    <button
                      key={`${prediction.symbol}-${offset}`}
                      type="button"
                      onClick={() => setChosen(offset)}
                      className={`w-full rounded-xl border px-2.5 py-2 text-left transition ${
                        chosen === offset
                          ? "border-amber-300/50 bg-amber-300/[0.08]"
                          : "border-white/8 bg-white/[0.02] hover:border-white/20"
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[18px] text-slate-100">
                          <MathText tex={prediction.latex} />
                        </span>
                        <span className="mono text-[10px] text-slate-500">
                          {Math.round(prediction.confidence * 100)}%
                        </span>
                      </div>
                      <div className="mono mt-0.5 flex flex-wrap items-center gap-1 text-[9px] text-slate-500">
                        <span>{prediction.kind}</span>
                        <span>·</span>
                        <span>{prediction.type}</span>
                      </div>
                      <div className="mt-1 h-1 w-full overflow-hidden rounded-full bg-white/5">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-amber-300 to-teal-300"
                          style={{ width: `${prediction.confidence * 100}%` }}
                        />
                      </div>
                      <p className="mt-1 text-[10px] leading-snug text-slate-600">{prediction.rationale}</p>
                    </button>
                  ))}
                  <button
                    type="button"
                    className="btn btn-primary w-full"
                    disabled={!selectedPrediction || busy}
                    onClick={() => {
                      if (!selectedPrediction) return;
                      onInsertNode({
                        kind: selectedPrediction.kind,
                        token: selectedPrediction.latex,
                        label: selectedPrediction.label,
                        type: selectedPrediction.type,
                        variant: selectedPrediction.variant ?? null,
                      });
                      onClose();
                    }}
                  >
                    <Icon name="plus" className="h-3.5 w-3.5" />
                    place {selectedPrediction?.symbol ?? "token"} as vertex
                  </button>
                </div>
              )
            ) : preview ? (
              <div className="space-y-2 text-[11.5px] leading-relaxed text-slate-400">
                <div className="flex items-center gap-1.5 text-teal-200">
                  <Icon name="check" className="h-3.5 w-3.5" />
                  structure recovered
                </div>
                <p>
                  The span was lexed into <strong className="text-slate-200">{preview.nodeCount}</strong>{" "}
                  typed vertices and <strong className="text-slate-200">{preview.edgeCount}</strong> port
                  bindings. Positions are derived from the tree, not from the string.
                </p>
                <div className="mono rounded-lg border border-white/8 bg-white/[0.02] px-2 py-1.5 text-[9.5px] text-slate-500 break-all">
                  {preview.latex}
                </div>
                <p className="text-[10.5px] text-slate-600">
                  Placing it creates one reversible graph transaction, so it can be undone as a unit.
                </p>
              </div>
            ) : (
              <p className="text-[11.5px] leading-relaxed text-slate-500">
                Enter a LaTeX span to run structural recovery. Nested fractions, exponents and
                integrals are decomposed into typed vertices with open ports.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
