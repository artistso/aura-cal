"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import type { GhostPath, MathType, NodeKind } from "@/lib/aura/ontology";
import {
  type DocumentPayload,
  type DocumentSummary,
  diagnose,
  documentLatex,
} from "@/lib/aura/engine";
import { CanvasStage } from "./CanvasStage";
import { ExportDialog } from "./ExportDialog";
import { InkDialog } from "./InkDialog";
import { InspectorPanel } from "./InspectorPanel";
import { PlotPanel } from "./PlotPanel";
import { SymbolLibraryDialog } from "./SymbolLibrary";
import { DiscoveryPanel, type DiscoveryStats } from "./DiscoveryPanel";
import { VerificationPanel } from "./VerificationPanel";
import type { DiscoveryRecord } from "@/lib/aura/data";
import type { Family, Proposal } from "@/lib/aura/discover";
import { Sidebar } from "./Sidebar";
import { Icon } from "./icons";

type ApiPayload = DocumentPayload & { message?: string; focusId?: string | null; error?: string };

interface AuraWorkspaceProps {
  documents: DocumentSummary[];
  initial: DocumentPayload;
}

type Tone = "ok" | "error" | "info";

export function AuraWorkspace({ documents: initialDocuments, initial }: AuraWorkspaceProps) {
  const [payload, setPayload] = useState<DocumentPayload>(initial);
  const [documents, setDocuments] = useState<DocumentSummary[]>(initialDocuments);
  const [selected, setSelected] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<{ message: string; tone: Tone } | null>(null);
  const [inkOpen, setInkOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [inspectorOpen, setInspectorOpen] = useState(false);
  const [center, setCenter] = useState({ x: 620, y: 320 });
  const [rightTab, setRightTab] = useState<"inspector" | "plot" | "connect" | "verify">("inspector");
  const [libraryOpen, setLibraryOpen] = useState(false);
  const [scale, setScale] = useState(0.5);
  const [families, setFamilies] = useState<Family[]>([
    "relation",
    "arithmetic",
    "comparison",
    "set",
    "speculative",
    "transform",
  ]);
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [dismissed, setDismissed] = useState<string[]>([]);
  const [discoveryStats, setDiscoveryStats] = useState<DiscoveryStats | null>(null);
  const [discoveryLog, setDiscoveryLog] = useState<DiscoveryRecord[]>([]);
  const [appliedCount, setAppliedCount] = useState(0);
  const [discovering, setDiscovering] = useState(false);
  const [focusOnly, setFocusOnly] = useState(false);
  const toastTimer = useRef<number | null>(null);

  const graph = payload.graph;
  const diagnostics = useMemo(() => diagnose(graph), [graph]);
  const expressions = useMemo(() => documentLatex(graph), [graph]);

  const notify = useCallback((message: string, tone: Tone = "ok") => {
    setToast({ message, tone });
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 3400);
  }, []);

  const adopt = useCallback((next: DocumentPayload) => {
    setPayload(next);
    setDocuments((current) =>
      current.map((document) =>
        document.id === next.document.id
          ? {
              ...document,
              title: next.document.title,
              subtitle: next.document.subtitle,
              updatedAt: next.document.updatedAt,
              nodeCount: next.graph.nodes.length,
              transactionCount: next.history.length,
            }
          : document,
      ),
    );
  }, []);

  const send = useCallback(
    async (url: string, init?: RequestInit): Promise<ApiPayload | null> => {
      setBusy(true);
      try {
        const response = await fetch(url, {
          headers: { "Content-Type": "application/json" },
          ...init,
        });
        const data = (await response.json().catch(() => ({}))) as ApiPayload;
        if (!response.ok) {
          notify(data.error ?? "The graph kernel rejected that request", "error");
          return null;
        }
        return data;
      } catch (error) {
        notify(error instanceof Error ? error.message : "Network error", "error");
        return null;
      } finally {
        setBusy(false);
      }
    },
    [notify],
  );

  const mutate = useCallback(
    async (
      body: Record<string, unknown>,
      options: { select?: boolean; quiet?: boolean; clear?: boolean } = {},
    ) => {
      const result = await send(`/api/documents/${payload.document.id}/mutations`, {
        method: "POST",
        body: JSON.stringify(body),
      });
      if (!result) return;
      adopt(result);
      if (!options.quiet && result.message) notify(result.message);
      if (options.clear) setSelected([]);
      else if (options.select && result.focusId) setSelected([result.focusId]);
    },
    [adopt, notify, payload.document.id, send],
  );

  const undo = useCallback(async () => {
    const result = await send(`/api/documents/${payload.document.id}/history`, {
      method: "POST",
      body: JSON.stringify({ direction: "undo" }),
    });
    if (result) {
      adopt(result);
      setSelected([]);
      notify(result.message ?? "Undid the last transaction", "info");
    }
  }, [adopt, notify, payload.document.id, send]);

  const redo = useCallback(async () => {
    const result = await send(`/api/documents/${payload.document.id}/history`, {
      method: "POST",
      body: JSON.stringify({ direction: "redo" }),
    });
    if (result) {
      adopt(result);
      setSelected([]);
      notify(result.message ?? "Redid the transaction", "info");
    }
  }, [adopt, notify, payload.document.id, send]);

  const switchDocument = useCallback(
    async (id: string) => {
      if (id === payload.document.id) {
        setSidebarOpen(false);
        return;
      }
      const result = await send(`/api/documents/${id}`);
      if (result) {
        adopt(result);
        setSelected([]);
        setSidebarOpen(false);
      }
    },
    [adopt, payload.document.id, send],
  );

  const createDocument = useCallback(async () => {
    setBusy(true);
    try {
      const response = await fetch("/api/documents", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: `Canvas ${documents.length + 1}` }),
      });
      const data = (await response.json()) as ApiPayload;
      if (!response.ok) {
        notify(data.error ?? "Could not create the canvas", "error");
        return;
      }
      adopt(data);
      setDocuments((current) => [
        ...current,
        {
          id: data.document.id,
          title: data.document.title,
          subtitle: data.document.subtitle,
          updatedAt: data.document.updatedAt,
          nodeCount: data.graph.nodes.length,
          transactionCount: 0,
        },
      ]);
      setSelected([]);
      setSidebarOpen(false);
      notify("New canvas created");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Could not create the canvas", "error");
    } finally {
      setBusy(false);
    }
  }, [adopt, documents.length, notify]);

  const handleViewportCenter = useCallback((point: { x: number; y: number }) => {
    setCenter((current) =>
      Math.abs(current.x - point.x) < 0.5 && Math.abs(current.y - point.y) < 0.5 ? current : point,
    );
  }, []);

  const handleSelect = useCallback((ids: string[]) => setSelected(ids), []);

  const handleMove = useCallback(
    (positions: { id: string; x: number; y: number }[]) => {
      void mutate({ type: "move", positions }, { quiet: true });
    },
    [mutate],
  );

  const handleCommitCandidate = useCallback(
    (candidate: GhostPath) => {
      void mutate(
        {
          type: "connect",
          candidate: {
            kind: candidate.kind,
            addedNodes: candidate.addedNodes,
            addedEdges: candidate.addedEdges,
            removedEdgeIds: candidate.removedEdgeIds,
            draggedId: candidate.draggedId,
            focusId: candidate.focusId,
          },
        },
        { select: true },
      );
    },
    [mutate],
  );

  const handleExpand = useCallback(
    (id: string) => {
      void mutate({ type: "expand", id }, { select: true });
    },
    [mutate],
  );

  const runDiscovery = useCallback(async () => {
    setDiscovering(true);
    try {
      const response = await fetch(`/api/documents/${payload.document.id}/discover`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          scale,
          families,
          focusIds: focusOnly && selected.length > 0 ? selected : undefined,
        }),
      });
      const data = (await response.json()) as {
        proposals?: Proposal[];
        clusters?: number;
        considered?: number;
        holds?: number;
        refuted?: number;
        log?: DiscoveryRecord[];
        error?: string;
      };
      if (!response.ok) {
        notify(data.error ?? "Discovery failed", "error");
        return;
      }
      setProposals(data.proposals ?? []);
      setDismissed([]);
      setDiscoveryStats({
        clusters: data.clusters ?? 0,
        considered: data.considered ?? 0,
        holds: data.holds ?? 0,
        refuted: data.refuted ?? 0,
      });
      setDiscoveryLog(data.log ?? []);
      const holds = data.holds ?? 0;
      notify(
        holds > 0
          ? `${holds} connection${holds === 1 ? "" : "s"} hold true at scale ${scale.toFixed(2)}`
          : `${data.proposals?.length ?? 0} candidates explored — none verified at this scale`,
        holds > 0 ? "ok" : "info",
      );
    } catch (error) {
      notify(error instanceof Error ? error.message : "Discovery failed", "error");
    } finally {
      setDiscovering(false);
    }
  }, [families, focusOnly, notify, payload.document.id, scale, selected]);

  const applyProposal = useCallback(
    (proposal: Proposal) => {
      void mutate({ type: "connect", candidate: proposal.patch }, { quiet: true }).then(() => {
        setAppliedCount((current) => current + 1);
        setProposals((current) => current.filter((entry) => entry.id !== proposal.id));
        notify(`Plugged in: ${proposal.previewLatex.replace(/\\/g, "")}`);
      });
    },
    [mutate, notify],
  );

  const applyAll = useCallback(
    (list: Proposal[]) => {
      if (list.length === 0) return;
      // One binding per cluster pair: keep the highest-scoring proposal.
      const best = new Map<string, Proposal>();
      for (const proposal of list) {
        const key = [...proposal.clusterIds].sort().join("|");
        const existing = best.get(key);
        if (!existing || proposal.score > existing.score) best.set(key, proposal);
      }
      const batch = Array.from(best.values());
      void mutate(
        { type: "autoConnect", candidates: batch.map((proposal) => proposal.patch) },
        { quiet: false },
      ).then(() => {
        const ids = new Set(batch.map((proposal) => proposal.id));
        setProposals((current) => current.filter((proposal) => !ids.has(proposal.id)));
        setAppliedCount((current) => current + batch.length);
      });
    },
    [mutate],
  );

  const handleSimplify = useCallback(() => {
    void mutate({ type: "simplify" }, { quiet: false });
  }, [mutate]);

  const handlePlaceRecognized = useCallback(
    (
      node: { kind: NodeKind; token: string; label: string; type: MathType; variant: string | null },
      position: { x: number; y: number },
    ) => {
      void mutate({ type: "addNode", node, position }, { select: true });
    },
    [mutate],
  );

  const handleAddElement = useCallback(
    (itemId: string, label?: string) => {
      void mutate({ type: "addNode", itemId, position: center }, { select: true, quiet: Boolean(label) });
      if (label) notify(`Placed ${label} as a typed vertex`);
      setSidebarOpen(false);
    },
    [center, mutate, notify],
  );

  const handleCopy = useCallback(
    (text: string, message: string) => {
      if (typeof navigator !== "undefined" && navigator.clipboard) {
        navigator.clipboard
          .writeText(text)
          .then(() => notify(message))
          .catch(() => notify("Clipboard is unavailable in this browser", "error"));
      } else {
        notify("Clipboard is unavailable in this browser", "error");
      }
    },
    [notify],
  );

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if (!(event.metaKey || event.ctrlKey)) return;
      if (event.key.toLowerCase() !== "z") return;
      event.preventDefault();
      if (event.shiftKey) void redo();
      else void undo();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [redo, undo]);

  const selectedPrimary = selected.length === 1 ? selected[0] : null;

  const discovery = (
    <DiscoveryPanel
      busy={busy}
      discovering={discovering}
      scale={scale}
      families={families}
      stats={discoveryStats}
      proposals={proposals}
      dismissed={dismissed}
      applied={appliedCount}
      log={discoveryLog}
      focusOnly={focusOnly}
      selectionSize={selected.length}
      onToggleFocus={() => setFocusOnly((current) => !current)}
      onScale={setScale}
      onToggleFamily={(family) =>
        setFamilies((current) =>
          current.includes(family) ? current.filter((entry) => entry !== family) : [...current, family],
        )
      }
      onRun={() => void runDiscovery()}
      onApply={applyProposal}
      onApplyAll={applyAll}
      onDismiss={(id) => setDismissed((current) => [...current, id])}
      onLocate={(proposal) => {
        setSelected(proposal.clusterIds);
        setInspectorOpen(false);
      }}
    />
  );

  const inspector = (
    <InspectorPanel
      graph={graph}
      selected={selected}
      diagnostics={diagnostics}
      history={payload.history}
      busy={busy}
      onDelete={() => void mutate({ type: "delete", ids: selected }, { clear: true })}
      onCollapse={() => void mutate({ type: "collapse", ids: selected }, { select: true })}
      onExpand={handleExpand}
      onReflow={() => void mutate({ type: "reflow" }, { quiet: true })}
      onSimplify={handleSimplify}
      onCopy={handleCopy}
      onSelect={handleSelect}
    />
  );

  return (
    <div className="flex h-[100dvh] flex-col overflow-hidden" id="workspace">
      <header className="z-30 flex h-14 shrink-0 items-center gap-2 border-b border-white/8 bg-[#070b12]/92 px-2.5 backdrop-blur-xl sm:px-3">
        <button
          type="button"
          className="btn h-9 w-9 px-0 lg:hidden"
          onClick={() => setSidebarOpen(true)}
          title="Open canvases and elements"
        >
          <Icon name="menu" />
        </button>
        <div className="flex items-center gap-2">
          <span className="relative flex h-8 w-8 items-center justify-center rounded-[11px] bg-gradient-to-br from-amber-200 to-amber-500 text-[#1a1206] shadow-[0_8px_22px_rgba(226,161,68,.3)]">
            <span className="display text-[17px] font-semibold leading-none">A</span>
            <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-teal-300 ring-2 ring-[#070b12]" />
          </span>
          <div className="hidden sm:block">
            <div className="display text-[19px] leading-none text-slate-50">Aura</div>
            <div className="mono text-[8.5px] uppercase tracking-[0.2em] text-slate-500">
              typed hypergraph
            </div>
          </div>
        </div>
        <div className="mx-1 hidden h-6 w-px bg-white/10 sm:block" />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <span className="hidden text-[10px] text-slate-600 sm:inline">canvas /</span>
            <span className="truncate text-[12.5px] text-slate-100">{payload.document.title}</span>
            <span
              className={`pill shrink-0 ${
                diagnostics.some((entry) => entry.severity === "error")
                  ? "border-rose-400/40 text-rose-200"
                  : "border-teal-300/30 text-teal-200"
              }`}
              title="Type coherence of the committed hypergraph"
            >
              <span
                className={`h-1.5 w-1.5 rounded-full ${
                  diagnostics.some((entry) => entry.severity === "error") ? "bg-rose-400" : "bg-teal-300"
                }`}
              />
              {diagnostics.some((entry) => entry.severity === "error") ? "ill-typed" : "coherent"}
            </span>
          </div>
          <div className="mono mt-0.5 flex items-center gap-1.5 truncate text-[9px] text-slate-500">
            <span>{graph.nodes.length} V</span>
            <span className="text-slate-700">·</span>
            <span>{graph.edges.length} E</span>
            <span className="text-slate-700">·</span>
            <span>{expressions.length} clusters</span>
            <span className="text-slate-700">·</span>
            <span>{payload.history.length} tx</span>
            {selected.length > 0 && (
              <>
                <span className="text-slate-700">·</span>
                <span className="text-amber-200/80">{selected.length} selected</span>
              </>
            )}
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          {busy && (
            <span className="pill hidden text-amber-200 sm:inline-flex">
              <span className="h-1.5 w-1.5 rounded-full bg-amber-300 pulse" />
              syncing
            </span>
          )}
          <button
            type="button"
            className="btn h-9 w-9 px-0"
            onClick={() => void undo()}
            disabled={!payload.canUndo || busy}
            title="Undo (⌘Z)"
          >
            <Icon name="undo" />
          </button>
          <button
            type="button"
            className="btn h-9 w-9 px-0"
            onClick={() => void redo()}
            disabled={!payload.canRedo || busy}
            title="Redo (⇧⌘Z)"
          >
            <Icon name="redo" />
          </button>
          <button
            type="button"
            className="btn btn-primary h-9"
            onClick={() => {
              setRightTab("connect");
              setInspectorOpen(true);
              void runDiscovery();
            }}
            disabled={busy || discovering || families.length === 0}
            title="Auto-connect: discover and verify connections across the canvas"
          >
            <Icon name="bind" className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">{discovering ? "probing…" : "Auto-connect"}</span>
            <Icon name="spark" className="h-3 w-3 opacity-70" />
          </button>
          <button
            type="button"
            className="btn h-9"
            onClick={() => setInkOpen(true)}
            disabled={busy}
            title="Write with the pen or recover a LaTeX structure"
          >
            <Icon name="pen" className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Write</span>
          </button>
          <button
            type="button"
            className="btn h-9"
            onClick={() => setLibraryOpen(true)}
            title="Browse every mathematical symbol"
          >
            <Icon name="docs" className="h-3.5 w-3.5" />
            <span className="hidden md:inline">Symbols</span>
          </button>
          <button
            type="button"
            className="btn h-9 w-9 px-0"
            onClick={() => setExportOpen(true)}
            title="Export LaTeX, MathML or graph JSON"
          >
            <Icon name="export" />
          </button>
          <button
            type="button"
            className="btn h-9 w-9 px-0 xl:hidden"
            onClick={() => setInspectorOpen(true)}
            title="Open the type inspector"
          >
            <Icon name="graph" />
          </button>
        </div>
      </header>

      <div className="relative flex min-h-0 flex-1">
        <aside className="hidden w-[282px] shrink-0 border-r border-white/8 bg-[#080d15]/85 lg:block">
          <Sidebar
            graph={graph}
            documents={documents}
            activeId={payload.document.id}
            busy={busy}
            diagnostics={diagnostics}
            onSwitchDocument={(id) => void switchDocument(id)}
            onCreateDocument={() => void createDocument()}
            onAddElement={handleAddElement}
            onOpenLibrary={() => setLibraryOpen(true)}
          />
        </aside>

        <main className="relative min-w-0 flex-1" id="canvas-region" aria-label="Mathematical canvas">
          <CanvasStage
            graph={graph}
            documentId={payload.document.id}
            documentTitle={payload.document.title}
            selected={selected}
            busy={busy}
            onSelect={handleSelect}
            onMove={handleMove}
            onCommitCandidate={handleCommitCandidate}
            onExpand={handleExpand}
            onViewportCenter={handleViewportCenter}
            onPlaceRecognized={handlePlaceRecognized}
            onSelectionAction={(action, ids) => {
              if (action === "collapse") void mutate({ type: "collapse", ids }, { select: true });
              if (action === "expand") void mutate({ type: "expand", id: ids[0] }, { select: true });
              if (action === "delete") void mutate({ type: "delete", ids }, { clear: true });
              if (action === "simplify") void mutate({ type: "simplify" }, { quiet: false });
            }}
            onOpenLibrary={() => setLibraryOpen(true)}
            onOpenInk={() => setInkOpen(true)}
          />
        </main>

        <aside className="hidden w-[338px] shrink-0 flex-col border-l border-white/8 bg-[#080d15]/85 xl:flex">
          <div className="flex shrink-0 gap-1 border-b border-white/8 px-2 py-2">
            <button
              type="button"
              className={`btn h-7 flex-1 border-transparent text-[11px] ${rightTab === "inspector" ? "btn-active" : ""}`}
              onClick={() => setRightTab("inspector")}
            >
              <Icon name="graph" className="h-3 w-3" />
              inspect
            </button>
            <button
              type="button"
              className={`btn h-7 flex-1 border-transparent text-[11px] ${rightTab === "plot" ? "btn-active" : ""}`}
              onClick={() => setRightTab("plot")}
            >
              <Icon name="spark" className="h-3 w-3" />
              plot
            </button>
            <button
              type="button"
              className={`btn h-7 flex-1 border-transparent text-[11px] ${rightTab === "connect" ? "btn-active" : ""}`}
              onClick={() => setRightTab("connect")}
              aria-pressed={rightTab === "connect"}
            >
              <Icon name="bind" className="h-3 w-3" />
              connect
            </button>
            <button
              type="button"
              className={`btn h-7 w-7 border-transparent px-0 ${rightTab === "verify" ? "btn-active" : ""}`}
              onClick={() => setRightTab("verify")}
              title="Kernel verification suite"
              aria-pressed={rightTab === "verify"}
            >
              <Icon name="check" className="h-3 w-3" />
            </button>
          </div>
          <div className="min-h-0 flex-1">
            {rightTab === "inspector" ? (
              inspector
            ) : rightTab === "plot" ? (
              <PlotPanel graph={graph} onSelect={handleSelect} />
            ) : rightTab === "verify" ? (
              <VerificationPanel />
            ) : (
              discovery
            )}
          </div>
        </aside>
      </div>

      {sidebarOpen && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div
            className="absolute inset-0 bg-black/65 backdrop-blur-sm"
            onClick={() => setSidebarOpen(false)}
          />
          <div className="relative z-10 flex h-full w-[290px] flex-col border-r border-white/10 bg-[#080d15]">
            <div className="flex justify-end px-2 pt-2">
              <button type="button" className="btn h-8 w-8 px-0" onClick={() => setSidebarOpen(false)}>
                <Icon name="close" />
              </button>
            </div>
            <div className="min-h-0 flex-1">
              <Sidebar
                graph={graph}
                documents={documents}
                activeId={payload.document.id}
                busy={busy}
                diagnostics={diagnostics}
                onSwitchDocument={(id) => void switchDocument(id)}
                onCreateDocument={() => void createDocument()}
                onAddElement={handleAddElement}
                onOpenLibrary={() => setLibraryOpen(true)}
              />
            </div>
          </div>
        </div>
      )}

      {inspectorOpen && (
        <div className="fixed inset-0 z-50 flex justify-end xl:hidden">
          <div
            className="absolute inset-0 bg-black/65 backdrop-blur-sm"
            onClick={() => setInspectorOpen(false)}
          />
          <div className="relative z-10 flex h-full w-[min(94vw,340px)] flex-col border-l border-white/10 bg-[#080d15]">
            <div className="flex justify-end px-2 pt-2">
              <button type="button" className="btn h-8 w-8 px-0" onClick={() => setInspectorOpen(false)}>
                <Icon name="close" />
              </button>
            </div>
            <div className="flex shrink-0 gap-1 border-b border-white/8 px-2 py-2">
              <button
                type="button"
                className={`btn h-7 flex-1 border-transparent text-[11px] ${rightTab === "inspector" ? "btn-active" : ""}`}
                onClick={() => setRightTab("inspector")}
              >
                inspect
              </button>
              <button
                type="button"
                className={`btn h-7 flex-1 border-transparent text-[11px] ${rightTab === "plot" ? "btn-active" : ""}`}
                onClick={() => setRightTab("plot")}
              >
                plot
              </button>
              <button
                type="button"
                className={`btn h-7 flex-1 border-transparent text-[11px] ${rightTab === "connect" ? "btn-active" : ""}`}
                onClick={() => setRightTab("connect")}
              >
                connect
              </button>
              <button
                type="button"
                className={`btn h-7 border-transparent px-2 text-[11px] ${rightTab === "verify" ? "btn-active" : ""}`}
                onClick={() => setRightTab("verify")}
              >
                verify
              </button>
            </div>
            <div className="min-h-0 flex-1">
              {rightTab === "inspector" ? (
                inspector
              ) : rightTab === "plot" ? (
                <PlotPanel graph={graph} onSelect={handleSelect} />
              ) : rightTab === "verify" ? (
                <VerificationPanel />
              ) : (
                discovery
              )}
            </div>
          </div>
        </div>
      )}

      <InkDialog
        open={inkOpen}
        onClose={() => setInkOpen(false)}
        busy={busy}
        onInsertNode={(node: {
          kind: NodeKind;
          token: string;
          label: string;
          type: MathType;
          variant: string | null;
        }) => {
          void mutate({ type: "addNode", node, position: center }, { select: true });
        }}
        onInsertLatex={(latex) => {
          void mutate({ type: "insertExpression", latex, position: center }, { select: true });
        }}
        onNotify={notify}
      />

      <SymbolLibraryDialog
        open={libraryOpen}
        busy={busy}
        onClose={() => setLibraryOpen(false)}
        onPick={(itemId, label) => handleAddElement(itemId, label)}
      />

      <ExportDialog
        open={exportOpen}
        payload={payload}
        expressions={expressions}
        onClose={() => setExportOpen(false)}
        onCopy={handleCopy}
      />

      {toast && (
        <div
          className="pointer-events-none fixed inset-x-0 bottom-5 z-[60] flex justify-center px-4"
          role="status"
          aria-live="polite"
        >
          <div
            className={`rise panel flex items-center gap-2 px-3.5 py-2 text-[12px] ${
              toast.tone === "error" ? "text-rose-200" : toast.tone === "info" ? "text-slate-200" : "text-teal-100"
            }`}
            style={{ borderColor: toast.tone === "error" ? "rgba(251,113,133,.4)" : undefined }}
          >
            <Icon
              name={toast.tone === "error" ? "error" : toast.tone === "info" ? "history" : "check"}
              className="h-3.5 w-3.5"
            />
            {toast.message}
          </div>
        </div>
      )}
    </div>
  );
}
