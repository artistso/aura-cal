"use client";

import { useCallback, useEffect, useState } from "react";

import type { SuiteReport } from "@/lib/aura/kernel-tests";
import { Icon } from "./icons";

export function VerificationPanel() {
  const [report, setReport] = useState<SuiteReport | null>(null);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = useCallback(async () => {
    setRunning(true);
    setError(null);
    try {
      const response = await fetch("/api/kernel");
      const data = (await response.json()) as { report?: SuiteReport; error?: string };
      if (!data.report) throw new Error(data.error ?? "The suite did not return a report");
      setReport(data.report);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not run the suite");
    } finally {
      setRunning(false);
    }
  }, []);

  useEffect(() => {
    void run();
  }, [run]);

  const ok = report ? report.failed === 0 : false;

  return (
    <div className="flex h-full flex-col overflow-hidden">
      <div className="flex items-center justify-between gap-2 border-b border-white/8 px-4 py-3">
        <div>
          <div className="eyebrow">Executable specification</div>
          <div className="display mt-0.5 text-[17px] text-slate-100">Kernel verification</div>
        </div>
        <span
          className={`pill ${ok ? "border-teal-300/40 text-teal-200" : "border-rose-400/40 text-rose-200"}`}
          aria-live="polite"
        >
          <span className={`h-1.5 w-1.5 rounded-full ${ok ? "bg-teal-300" : "bg-rose-400"}`} />
          {report ? `${report.passed}/${report.total}` : "—"}
        </span>
      </div>

      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto px-4 py-3">
        <p className="text-[11.5px] leading-relaxed text-slate-500">
          Every claim made about the typed hypergraph — type admissibility, precedence-preserving
          serialisation, numeric evaluation, discovery verification, reversibility of collapse —
          is asserted head-lessly. The same suite runs in CI via{" "}
          <span className="mono text-amber-200/80">GET /api/kernel?format=summary</span>.
        </p>

        <button type="button" className="btn mt-3 w-full" onClick={() => void run()} disabled={running}>
          <Icon name="spark" className="h-3.5 w-3.5" />
          {running ? "running specs…" : "re-run suite"}
        </button>

        {error && (
          <p className="mt-2 rounded-lg border border-rose-400/30 bg-rose-400/[0.06] px-2 py-1.5 text-[11px] text-rose-200">
            {error}
          </p>
        )}

        {report && (
          <>
            <div className="mt-3 grid grid-cols-3 gap-1">
              {[
                { label: "specs", value: report.total, tone: "text-slate-200" },
                { label: "passed", value: report.passed, tone: "text-teal-200" },
                { label: "failed", value: report.failed, tone: report.failed ? "text-rose-300" : "text-slate-500" },
              ].map((entry) => (
                <div
                  key={entry.label}
                  className="rounded-lg border border-white/8 bg-white/[0.02] px-1.5 py-1 text-center"
                >
                  <div className={`mono text-[12px] ${entry.tone}`}>{entry.value}</div>
                  <div className="text-[8.5px] uppercase tracking-[0.08em] text-slate-600">{entry.label}</div>
                </div>
              ))}
            </div>
            <div className="mono mt-1.5 flex items-center justify-between text-[9.5px] text-slate-600">
              <span>{report.durationMs} ms</span>
              <span>{report.librarySymbols} symbols</span>
              <span>{report.suites.length} suites</span>
            </div>

            <div className="mt-3 space-y-2">
              {report.suites.map((suite) => (
                <div key={suite.suite}>
                  <div className="mb-1 flex items-center gap-1.5">
                    <span className="text-[10px] font-medium uppercase tracking-[0.1em] text-slate-500">
                      {suite.suite}
                    </span>
                    <span className="mono text-[9px] text-teal-200/70">{suite.passed}✓</span>
                    {suite.failed > 0 && (
                      <span className="mono text-[9px] text-rose-300">{suite.failed}✕</span>
                    )}
                  </div>
                  <div className="space-y-1">
                    {report.outcomes
                      .filter((outcome) => outcome.suite === suite.suite)
                      .map((outcome) => (
                        <div
                          key={`${outcome.suite}-${outcome.name}`}
                          className="flex items-start gap-1.5 rounded-lg border border-white/8 bg-white/[0.02] px-2 py-[5px]"
                        >
                          <span className={outcome.ok ? "text-teal-300" : "text-rose-300"}>
                            <Icon name={outcome.ok ? "check" : "error"} className="mt-[2px] h-3 w-3" />
                          </span>
                          <div className="min-w-0">
                            <div className="text-[11px] leading-snug text-slate-300">{outcome.name}</div>
                            {outcome.error && (
                              <div className="mono mt-0.5 text-[9.5px] leading-snug text-rose-200/90">
                                {outcome.error}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              ))}
            </div>

            <p className="mono mt-3 text-[9px] text-slate-700">
              generated {new Date(report.generatedAt).toLocaleString()}
            </p>
          </>
        )}
      </div>
    </div>
  );
}
