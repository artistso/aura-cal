"use client";

import { useMemo } from "react";

import { type Family, type Proposal, type Verdict, scaleBand } from "@/lib/aura/discover";
import type { DiscoveryRecord } from "@/lib/aura/data";
import { Icon } from "./icons";
import { MathText } from "./MathText";

const BAND_COPY: Record<string, string> = {
  literal: "Nearby clusters only · equality and addition · strictest typing",
  cautious: "Adjacent clusters · arithmetic and comparisons · refutations suppressed",
  balanced: "Whole canvas · ratios, powers, sets and arrows · counterexamples surfaced",
  wild: "Everything · speculative arrows and containment · novelty outranks proximity",
};

const VERDICT_STYLE: Record<Verdict, { label: string; color: string; icon: "check" | "error" | "spark" }> = {
  holds: { label: "holds true", color: "#5eead4", icon: "check" },
  refuted: { label: "refuted", color: "#fb7185", icon: "error" },
  unknown: { label: "unverifiable", color: "#a3b3c9", icon: "spark" },
};

const FAMILIES: { id: Family; label: string; hint: string }[] = [
  { id: "relation", label: "relations", hint: "= and →" },
  { id: "arithmetic", label: "arithmetic", hint: "+ × ^ ÷" },
  { id: "comparison", label: "comparison", hint: "≤ ≈" },
  { id: "set", label: "sets", hint: "∈" },
  { id: "speculative", label: "speculative", hint: "arrows" },
  { id: "transform", label: "transforms", hint: "sin ln √" },
];

export interface DiscoveryStats {
  clusters: number;
  considered: number;
  holds: number;
  refuted: number;
}

interface DiscoveryPanelProps {
  busy: boolean;
  discovering: boolean;
  scale: number;
  families: Family[];
  stats: DiscoveryStats | null;
  proposals: Proposal[];
  dismissed: string[];
  applied: number;
  log: DiscoveryRecord[];
  focusOnly: boolean;
  selectionSize: number;
  onToggleFocus: () => void;
  onScale: (scale: number) => void;
  onToggleFamily: (family: Family) => void;
  onRun: () => void;
  onApply: (proposal: Proposal) => void;
  onApplyAll: (proposals: Proposal[]) => void;
  onDismiss: (id: string) => void;
  onLocate: (proposal: Proposal) => void;
}

export function DiscoveryPanel({
  busy,
  discovering,
  scale,
  families,
  stats,
  proposals,
  dismissed,
  applied,
  log,
  focusOnly,
  selectionSize,
  onToggleFocus,
  onScale,
  onToggleFamily,
  onRun,
  onApply,
  onApplyAll,
  onDismiss,
  onLocate,
}: DiscoveryPanelProps) {
  const visible = useMemo(
    () => proposals.filter((proposal) => !dismissed.includes(proposal.id)),
    [proposals, dismissed],
  );
  const holding = visible.filter((proposal) => proposal.verdict === "holds");
  const band = scaleBand(scale);

  return (
    <div className="flex h-full flex-col overflow-hidden">
      <div className="border-b border-white/8 px-4 py-3">
        <div className="flex items-center justify-between gap-2">
          <div>
            <div className="eyebrow">Discovery engine</div>
            <div className="display mt-0.5 text-[17px] text-slate-100">Auto-connect</div>
          </div>
          <span
            className="pill"
            style={{
              color: holding.length > 0 ? "#5eead4" : "#a3b3c9",
              borderColor: holding.length > 0 ? "rgba(94,234,212,.4)" : undefined,
            }}
          >
            <Icon name="bind" className="h-3 w-3" />
            {holding.length} hold
          </span>
        </div>
      </div>

      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto px-4 py-3">
        {/* Scalar scale */}
        <section className="panel px-3 py-3">
          <div className="flex items-center justify-between">
            <span className="eyebrow">Connection scale</span>
            <span className="mono text-[10px] uppercase tracking-[0.14em] text-amber-200">{band}</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            step={1}
            value={Math.round(scale * 100)}
            onChange={(event) => onScale(Number(event.target.value) / 100)}
            className="mt-2 w-full accent-amber-300"
            aria-label="Discovery scale"
          />
          <div className="mono mt-1 flex justify-between text-[9px] text-slate-600">
            <span>literal</span>
            <span>cautious</span>
            <span>balanced</span>
            <span>wild</span>
          </div>
          <p className="mt-1.5 text-[11px] leading-relaxed text-slate-500">{BAND_COPY[band]}</p>
          <div className="mono mt-2 flex items-center justify-between rounded-lg border border-white/8 bg-black/25 px-2 py-1 text-[9.5px] text-slate-500">
            <span>radius ×{(0.18 + 0.82 * scale).toFixed(2)}</span>
            <span>depth {Math.round(8 + scale * 20)} candidates</span>
          </div>
        </section>

        {/* Families */}
        <section className="mt-3">
          <div className="mb-1.5 flex items-center justify-between">
            <span className="eyebrow">What to try</span>
            <span className="mono text-[9.5px] text-slate-600">{families.length}/6</span>
          </div>
          <div className="flex flex-wrap gap-1">
            {FAMILIES.map((family) => {
              const active = families.includes(family.id);
              return (
                <button
                  key={family.id}
                  type="button"
                  onClick={() => onToggleFamily(family.id)}
                  className={`pill ${active ? "border-amber-300/50 bg-amber-300/10 text-amber-200" : "opacity-70"}`}
                  title={`${family.label} — ${family.hint}`}
                >
                  {family.label}
                </button>
              );
            })}
          </div>
        </section>

        <button
          type="button"
          onClick={onToggleFocus}
          disabled={selectionSize === 0}
          className={`btn mt-3 w-full justify-start text-[11px] ${
            focusOnly && selectionSize > 0 ? "btn-active" : ""
          }`}
          title="Restrict discovery to the clusters you have selected"
        >
          <Icon name="marquee" className="h-3 w-3" />
          {selectionSize === 0
            ? "selection only (nothing selected)"
            : `selection only (${selectionSize} selected)`}
          {focusOnly && selectionSize > 0 && <Icon name="check" className="ml-auto h-3 w-3" />}
        </button>

        <button
          type="button"
          className="btn btn-primary mt-1.5 w-full"
          onClick={onRun}
          disabled={busy || discovering || families.length === 0}
        >
          <Icon name="bind" className="h-3.5 w-3.5" />
          {discovering ? "probing connections…" : "Discover connections"}
        </button>

        {stats && (
          <div className="mt-2 grid grid-cols-4 gap-1">
            {[
              { label: "clusters", value: stats.clusters, tone: "text-slate-200" },
              { label: "probes", value: stats.considered, tone: "text-slate-200" },
              { label: "holds", value: stats.holds, tone: "text-teal-200" },
              { label: "refuted", value: stats.refuted, tone: "text-rose-300" },
            ].map((entry) => (
              <div
                key={entry.label}
                className="rounded-lg border border-white/8 bg-white/[0.02] px-1.5 py-1 text-center"
              >
                <div className={`mono text-[12px] ${entry.tone}`}>{entry.value}</div>
                <div className="text-[8.5px] uppercase tracking-[0.08em] text-slate-600">
                  {entry.label}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Proposals */}
        {visible.length > 0 && (
          <section className="mt-4">
            <div className="mb-1.5 flex items-center justify-between">
              <span className="eyebrow">Proposals</span>
              <span className="mono text-[9.5px] text-slate-600">{visible.length}</span>
            </div>
            <div className="space-y-2">
              {visible.map((proposal) => {
                const verdict = VERDICT_STYLE[proposal.verdict];
                return (
                  <div
                    key={proposal.id}
                    className="rounded-xl border bg-white/[0.02] px-2.5 py-2"
                    style={{ borderColor: `${verdict.color}33` }}
                  >
                    <div className="flex items-center gap-1.5">
                      <span
                        className="flex items-center gap-1 rounded-full px-1.5 py-[1px] text-[9px] font-semibold uppercase tracking-[0.08em]"
                        style={{ backgroundColor: `${verdict.color}1f`, color: verdict.color }}
                      >
                        <Icon name={verdict.icon} className="h-2.5 w-2.5" />
                        {verdict.label}
                      </span>
                      <span className="pill mono text-[9px]">{proposal.kind}</span>
                      <span className="mono ml-auto text-[9.5px] text-slate-500">
                        {Math.round(proposal.score * 100)}
                      </span>
                    </div>

                    <div className="mt-1.5 text-[15px] text-slate-100">
                      <MathText tex={proposal.previewLatex} />
                    </div>

                    {proposal.hint && (
                      <div className="mt-1 rounded-md border border-amber-300/25 bg-amber-300/[0.06] px-1.5 py-1 text-[10px] text-amber-200/90">
                        recognised: {proposal.hint}
                      </div>
                    )}

                    <p className="mt-1 text-[10.5px] leading-snug text-slate-500">{proposal.rationale}</p>
                    <p className="mono mt-1 text-[9.5px] leading-snug text-slate-500">
                      {proposal.evidence}
                    </p>
                    {proposal.counterexample && (
                      <p className="mono mt-1 rounded-md border border-rose-400/25 bg-rose-400/[0.06] px-1.5 py-1 text-[9.5px] text-rose-200">
                        counterexample · {proposal.counterexample}
                      </p>
                    )}

                    <div className="mt-1.5 flex items-center gap-1">
                      <button
                        type="button"
                        className="btn btn-primary h-6 flex-1 px-1.5 text-[10px]"
                        disabled={busy}
                        onClick={() => onApply(proposal)}
                      >
                        <Icon name="check" className="h-3 w-3" />
                        plug in
                      </button>
                      <button
                        type="button"
                        className="btn h-6 px-1.5 text-[10px]"
                        onClick={() => onLocate(proposal)}
                        title="Select the clusters involved"
                      >
                        <Icon name="fit" className="h-3 w-3" />
                      </button>
                      <button
                        type="button"
                        className="btn h-6 px-1.5 text-[10px]"
                        onClick={() => onDismiss(proposal.id)}
                        title="Dismiss this proposal"
                      >
                        <Icon name="close" className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {holding.length > 0 && (
              <button
                type="button"
                className="btn mt-2 w-full"
                disabled={busy}
                onClick={() => onApplyAll(holding)}
              >
                <Icon name="spark" className="h-3.5 w-3.5" />
                plug in all {holding.length} that hold true
              </button>
            )}
            {visible.length > holding.length && (
              <button
                type="button"
                className="btn mt-1 w-full"
                disabled={busy}
                onClick={() => onApplyAll(visible)}
              >
                plug in all {visible.length} proposals
              </button>
            )}
          </section>
        )}

        {!stats && (
          <p className="mt-4 rounded-xl border border-white/8 bg-white/[0.02] px-3 py-3 text-[11.5px] leading-relaxed text-slate-500">
            The engine enumerates port-admissible bindings between every free-standing cluster,
            tests each one on deterministic sample assignments, and ranks what survives. Raise the
            scale to let it look further and speculate harder.
          </p>
        )}

        {applied > 0 && (
          <p className="mt-3 rounded-lg border border-teal-300/25 bg-teal-300/[0.06] px-2 py-1.5 text-[10.5px] text-teal-200">
            {applied} discovered connection{applied === 1 ? "" : "s"} plugged in this session.
          </p>
        )}

        {log.length > 0 && (
          <section className="mt-4">
            <div className="mb-1.5 flex items-center gap-1.5">
              <Icon name="history" className="h-3 w-3 text-slate-600" />
              <span className="eyebrow">Discovery log</span>
            </div>
            <div className="space-y-1">
              {log.slice(0, 8).map((entry) => (
                <div key={entry.id} className="rounded-lg px-1.5 py-1">
                  <div className="flex items-center gap-1.5">
                    <span className="mono text-[9px] text-slate-600">
                      ×{entry.scale.toFixed(2)}
                    </span>
                    <span className="mono text-[9px] text-teal-200/80">{entry.holds} hold</span>
                    <span className="mono text-[9px] text-rose-300/70">{entry.refuted} refuted</span>
                    <span className="mono ml-auto text-[9px] text-slate-700">
                      {entry.clusters} clusters
                    </span>
                  </div>
                  <div className="mono truncate text-[9.5px] text-slate-500">{entry.summary}</div>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
