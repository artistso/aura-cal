import {
  boolean,
  doublePrecision,
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";

import type { AuraGraph, NodeKind, MathType } from "@/lib/aura/ontology";

/** A parsed document (one infinite canvas). */
export const documents = pgTable("documents", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: text("title").notNull(),
  subtitle: text("subtitle").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Vertices of the typed hypergraph. One row per mathematical element. */
export const nodes = pgTable(
  "nodes",
  {
    id: uuid("id").primaryKey(),
    documentId: uuid("document_id")
      .notNull()
      .references(() => documents.id, { onDelete: "cascade" }),
    kind: text("kind").$type<NodeKind>().notNull(),
    type: text("type").$type<MathType>().notNull(),
    token: text("token").notNull(),
    label: text("label").notNull(),
    variant: text("variant"),
    x: doublePrecision("x").notNull().default(0),
    y: doublePrecision("y").notNull().default(0),
    collapsed: boolean("collapsed").notNull().default(false),
    meta: jsonb("meta").$type<Record<string, unknown> | null>(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("nodes_document_idx").on(table.documentId)],
);

/** Hyperedge: `source` is the binder, `port` names the slot, `target` is the bound vertex. */
export const edges = pgTable(
  "edges",
  {
    id: uuid("id").primaryKey(),
    documentId: uuid("document_id")
      .notNull()
      .references(() => documents.id, { onDelete: "cascade" }),
    sourceId: uuid("source_id").notNull(),
    targetId: uuid("target_id").notNull(),
    port: text("port").notNull(),
    role: text("role").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  // Leaf vertices are references and may be shared across operators; composite
  // vertices form a tree and are validated to have at most one parent in
  // `validateGraph`, which runs inside every mutation transaction.
  (table) => [index("edges_document_idx").on(table.documentId)],
);

/** Snapshot transaction log: every graph mutation is reversible. */
export const transactions = pgTable(
  "transactions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    documentId: uuid("document_id")
      .notNull()
      .references(() => documents.id, { onDelete: "cascade" }),
    seq: integer("seq").notNull(),
    action: text("action").notNull(),
    summary: text("summary").notNull(),
    before: jsonb("before").$type<AuraGraph>().notNull(),
    after: jsonb("after").$type<AuraGraph>().notNull(),
    undone: boolean("undone").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("transactions_document_seq_idx").on(table.documentId, table.seq)],
);

/** Journal of discovery runs: what the engine looked at and what held true. */
export const discoveries = pgTable(
  "discoveries",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    documentId: uuid("document_id")
      .notNull()
      .references(() => documents.id, { onDelete: "cascade" }),
    scale: doublePrecision("scale").notNull(),
    clusters: integer("clusters").notNull().default(0),
    considered: integer("considered").notNull().default(0),
    proposed: integer("proposed").notNull().default(0),
    holds: integer("holds").notNull().default(0),
    refuted: integer("refuted").notNull().default(0),
    applied: integer("applied").notNull().default(0),
    summary: text("summary").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("discoveries_document_idx").on(table.documentId)],
);

export type DiscoveryRow = typeof discoveries.$inferSelect;
export type DocumentRow = typeof documents.$inferSelect;
export type NodeRow = typeof nodes.$inferSelect;
export type EdgeRow = typeof edges.$inferSelect;
export type TransactionRow = typeof transactions.$inferSelect;
