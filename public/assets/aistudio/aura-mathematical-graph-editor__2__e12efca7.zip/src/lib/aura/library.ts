/**
 * Aura's exhaustive symbol library.
 *
 * Every entry is a typed vertex blueprint: a LaTeX token, a display label, a
 * node kind (which determines its ports) and a variant (which determines its
 * rendering and evaluation). Domains and subdomains mirror mathematical
 * practice rather than UI convenience, so the browser can answer "what exists
 * in linear algebra?" as easily as "where is ∂?".
 */

import type { MathType, NodeKind } from "./ontology";

export interface Entry {
  token: string;
  label: string;
  kind: NodeKind;
  variant?: string;
  type?: MathType;
}

export interface SymbolEntry extends Omit<Entry, "variant"> {
  id: string;
  domain: string;
  subdomain: string;
  variant: string | null;
  type: MathType;
}

const L = (token: string, label: string, type: MathType = "Scalar"): Entry => ({
  token,
  label,
  kind: "literal",
  type,
});
const V = (token: string, label: string, type: MathType = "Variable"): Entry => ({
  token,
  label,
  kind: "variable",
  type,
});
const O = (token: string, label: string, variant: string, type: MathType = "Operator"): Entry => ({
  token,
  label,
  kind: "operator",
  variant,
  type,
});
const R = (token: string, label: string, variant: string): Entry => ({
  token,
  label,
  kind: "relation",
  variant,
  type: "Relation",
});
const F = (token: string, label: string, variant?: string): Entry => ({
  token,
  label,
  kind: "function",
  variant: variant ?? token.replace(/\\/g, ""),
  type: "Function",
});
const C = (token: string, label: string, variant: string): Entry => ({
  token,
  label,
  kind: "container",
  variant,
  type: "Expression",
});
const S = (token: string, label: string): Entry => ({ token, label, kind: "set", type: "Set" });

interface Domain {
  domain: string;
  groups: { name: string; items: Entry[] }[];
}

const GREEK = "αβγδεζηθικλμνξοπρστυφχψω".split("");
const GREEK_UPPER = ["Γ", "Δ", "Θ", "Λ", "Ξ", "Π", "Σ", "Υ", "Φ", "Ψ", "Ω"];
const DAYS = ["alpha", "beta", "gamma", "delta", "epsilon", "zeta", "eta", "theta", "iota", "kappa", "lambda", "mu", "nu", "xi", "omicron", "pi", "rho", "sigma", "tau", "upsilon", "phi", "chi", "psi", "omega"];
const DAYS_UPPER = ["Gamma", "Delta", "Theta", "Lambda", "Xi", "Pi", "Sigma", "Upsilon", "Phi", "Psi", "Omega"];

export const RAW_LIBRARY: Domain[] = [
  {
    domain: "Constants & numbers",
    groups: [
      {
        name: "Numerals",
        items: [
          L("0", "Zero"),
          L("1", "One"),
          L("2", "Two"),
          L("3", "Three"),
          L("4", "Four"),
          L("5", "Five"),
          L("6", "Six"),
          L("7", "Seven"),
          L("8", "Eight"),
          L("9", "Nine"),
          L("\\tfrac{1}{2}", "One half"),
          L("\\tfrac{1}{3}", "One third"),
          L("0.5", "Decimal"),
        ],
      },
      {
        name: "Universal constants",
        items: [
          L("\\pi", "π — circle constant"),
          L("e", "e — Euler number"),
          L("i", "i — imaginary unit"),
          L("\\infty", "∞ — infinity"),
          L("\\varphi", "φ — golden ratio"),
          L("\\gamma", "γ — Euler–Mascheroni"),
          L("\\sqrt{2}", "√2"),
          L("\\tau", "τ — turn constant"),
        ],
      },
      {
        name: "Physical constants",
        items: [
          V("\\hbar", "ℏ — reduced Planck"),
          V("c", "c — speed of light"),
          V("G", "G — gravitational constant"),
          V("g", "g — standard gravity"),
          V("k_B", "kʙ — Boltzmann"),
          V("\\varepsilon_0", "ε₀ — vacuum permittivity"),
          V("\\mu_0", "μ₀ — vacuum permeability"),
          V("N_A", "Nᴀ — Avogadro"),
          V("R", "R — gas constant"),
          V("h", "h — Planck"),
          V("\\alpha", "α — fine structure"),
        ],
      },
    ],
  },
  {
    domain: "Algebra",
    groups: [
      {
        name: "Arithmetic operators",
        items: [
          O("+", "Addition", "add"),
          O("-", "Subtraction", "sub"),
          O("\\times", "Multiplication", "mul"),
          O("\\div", "Division", "div"),
          O("\\cdot", "Dot product", "mul"),
          O("\\pm", "Plus-minus", "pm"),
          O("\\mp", "Minus-plus", "mp"),
          O("\\frac{\\phantom{a}}{\\phantom{a}}", "Fraction", "frac"),
          O("\\binom{\\phantom{n}}{\\phantom{k}}", "Binomial coefficient", "binom"),
          O("^", "Power", "power"),
          O("\\sqrt{\\phantom{x}}", "Square root", "sqrt"),
          O("\\sqrt[\\phantom{n}]{\\phantom{x}}", "nth root", "root"),
          O("!", "Factorial", "fact"),
          O("\\bmod", "Modulo", "mul"),
          O("\\%", "Percent", "mul"),
          O("\\lfloor\\cdot\\rfloor", "Floor", "floor"),
          O("\\lceil\\cdot\\rceil", "Ceiling", "ceil"),
          O("\\gcd", "gcd", "gcd"),
          O("\\operatorname{lcm}", "lcm", "gcd"),
        ],
      },
      {
        name: "Algebraic relations",
        items: [
          R("=", "Equality", "equal"),
          R("\\neq", "Not equal", "neq"),
          R("\\approx", "Approximately equal", "approx"),
          R("\\equiv", "Congruent / identical", "equiv"),
          R("\\sim", "Similar / distributed as", "sim"),
          R("\\simeq", "Asymptotically equal", "sim"),
          R("\\cong", "Isomorphic", "cong"),
          R("\\propto", "Proportional to", "propto"),
          R("<", "Less than", "lt"),
          R(">", "Greater than", "gt"),
          R("\\le", "Less or equal", "leq"),
          R("\\ge", "Greater or equal", "geq"),
          R("\\ll", "Much less", "ll"),
          R("\\gg", "Much greater", "gg"),
        ],
      },
      {
        name: "Algebraic symbols",
        items: [
          V("a", "Variable a"),
          V("b", "Variable b"),
          V("x", "Variable x"),
          V("y", "Variable y"),
          V("z", "Variable z"),
          V("n", "Variable n"),
          V("m", "Variable m"),
          V("k", "Variable k"),
          V("P(x)", "Polynomial P(x)", "Expression"),
          V("Q(x)", "Polynomial Q(x)", "Expression"),
          V("f(x)", "Function f(x)", "Function"),
          V("a_n", "Sequence term aₙ", "Expression"),
          V("A^{-1}", "Matrix inverse", "Matrix"),
        ],
      },
    ],
  },
  {
    domain: "Trigonometry",
    groups: [
      {
        name: "Circular functions",
        items: [
          F("\\sin", "sin"),
          F("\\cos", "cos"),
          F("\\tan", "tan"),
          F("\\sec", "sec"),
          F("\\csc", "csc"),
          F("\\cot", "cot"),
          F("\\operatorname{sinc}", "sinc"),
          F("\\operatorname{versin}", "versin"),
          F("\\operatorname{coversin}", "coversin"),
        ],
      },
      {
        name: "Inverse circular",
        items: [
          F("\\arcsin", "arcsin"),
          F("\\arccos", "arccos"),
          F("\\arctan", "arctan"),
          F("\\operatorname{arcsec}", "arcsec"),
          F("\\operatorname{arccsc}", "arccsc"),
          F("\\operatorname{arccot}", "arccot"),
        ],
      },
      {
        name: "Hyperbolic",
        items: [
          F("\\sinh", "sinh"),
          F("\\cosh", "cosh"),
          F("\\tanh", "tanh"),
          F("\\operatorname{sech}", "sech"),
          F("\\operatorname{csch}", "csch"),
          F("\\coth", "coth"),
          F("\\operatorname{arsinh}", "arsinh"),
          F("\\operatorname{arcosh}", "arcosh"),
          F("\\operatorname{artanh}", "artanh"),
        ],
      },
      {
        name: "Angles & measures",
        items: [
          V("\\theta", "Angle θ"),
          V("\\varphi", "Angle φ"),
          V("\\omega", "Angular frequency ω"),
          O("^\\circ", "Degree", "degree"),
          L("\\pi", "π radians"),
          O("\\perp", "Perpendicular", "mul"),
          R("\\propto", "Proportional to", "propto"),
        ],
      },
    ],
  },
  {
    domain: "Calculus",
    groups: [
      {
        name: "Limits & continuity",
        items: [
          C("\\lim", "Limit", "lim"),
          C("\\limsup", "Limit superior", "limsup"),
          C("\\liminf", "Limit inferior", "liminf"),
          C("\\sup", "Supremum", "sup"),
          C("\\inf", "Infimum", "inf"),
          C("\\max", "Maximum", "max"),
          C("\\min", "Minimum", "min"),
          R("\\to", "Tends to", "mapsto"),
          L("\\infty", "Infinity"),
          V("\\varepsilon", "ε — epsilon"),
          V("\\delta", "δ — delta"),
          V("\\Delta", "Δ — increment"),
        ],
      },
      {
        name: "Differential",
        items: [
          O("\\frac{d}{dx}", "Derivative d/dx", "frac"),
          O("\\frac{\\partial}{\\partial x}", "Partial derivative", "frac"),
          V("\\partial", "∂ — partial", "Operator"),
          V("\\nabla", "∇ — gradient", "Operator"),
          O("\\prime", "First derivative", "prime"),
          O("\\doubleprime", "Second derivative", "doubleprime"),
          V("d", "Differential d"),
          V("dx", "Differential dx", "Expression"),
          O("\\circ", "Composition", "mul"),
          C("\\dot{x}", "Time derivative", "dot"),
          C("\\ddot{x}", "Second time derivative", "ddot"),
        ],
      },
      {
        name: "Integral calculus",
        items: [
          C("\\int", "Integral", "int"),
          C("\\iint", "Double integral", "iint"),
          C("\\iiint", "Triple integral", "iiint"),
          C("\\oint", "Contour integral", "oint"),
          C("\\int_{\\phantom{a}}^{\\phantom{b}}", "Definite integral", "int"),
          O("\\left|\\cdot\\right|", "Absolute value", "abs"),
          O("\\left\\|\\cdot\\right\\|", "Norm", "norm"),
          V("C", "Constant of integration C"),
        ],
      },
      {
        name: "Sequences & series",
        items: [
          C("\\sum", "Summation", "sum"),
          C("\\prod", "Product", "prod"),
          C("\\coprod", "Coproduct", "coprod"),
          C("\\sum_{n=0}^{\\infty}", "Infinite series", "sum"),
          L("\\ldots", "Ellipsis"),
          L("\\cdots", "Centred ellipsis"),
          L("\\vdots", "Vertical dots"),
          L("\\ddots", "Diagonal dots"),
          R("\\to", "Converges to", "mapsto"),
          V("n", "Index n"),
        ],
      },
      {
        name: "Vector calculus",
        items: [
          V("\\nabla", "∇ — del", "Operator"),
          O("\\nabla", "Gradient", "nabla"),
          O("\\nabla\\cdot", "Divergence", "mul"),
          O("\\nabla\\times", "Curl", "mul"),
          V("\\partial", "∂ — boundary", "Operator"),
          C("\\oint", "Circulation", "oint"),
          V("\\vec{F}", "Vector field F", "Vector"),
          V("\\Phi", "Flux Φ"),
          L("\\Delta", "Laplacian Δ", "Operator"),
        ],
      },
    ],
  },
  {
    domain: "Linear algebra",
    groups: [
      {
        name: "Vectors & matrices",
        items: [
          V("\\vec{v}", "Vector v", "Vector"),
          V("\\vec{w}", "Vector w", "Vector"),
          V("\\vec{u}", "Vector u", "Vector"),
          V("\\vec{e}_1", "Basis vector e₁", "Vector"),
          V("\\mathbf{A}", "Matrix A", "Matrix"),
          V("\\mathbf{B}", "Matrix B", "Matrix"),
          V("\\mathbf{I}", "Identity matrix", "Matrix"),
          V("\\mathbf{0}", "Zero vector", "Vector"),
          C("\\begin{pmatrix}\\cdot\\end{pmatrix}", "Parenthesised matrix", "matrix"),
          C("\\begin{bmatrix}\\cdot\\end{bmatrix}", "Bracketed matrix", "bmatrix"),
          C("\\begin{vmatrix}\\cdot\\end{vmatrix}", "Determinant array", "vmatrix"),
          C("\\begin{cases}\\cdot\\end{cases}", "Piecewise cases", "cases"),
        ],
      },
      {
        name: "Matrix operations",
        items: [
          O("\\cdot", "Dot product", "mul"),
          O("\\times", "Cross product", "mul"),
          O("\\otimes", "Tensor product", "mul"),
          O("\\oplus", "Direct sum", "add"),
          O("\\ominus", "Direct difference", "sub"),
          O("^{\\top}", "Transpose", "transpose"),
          O("{}^{-1}", "Inverse", "inverse"),
          O("\\dagger", "Conjugate transpose", "transpose"),
          O("\\overline{z}", "Complex conjugate", "conj"),
          O("\\left\\|\\cdot\\right\\|", "Norm", "norm"),
        ],
      },
      {
        name: "Linear operators",
        items: [
          C("\\det", "Determinant", "det"),
          F("\\operatorname{tr}", "Trace"),
          F("\\operatorname{rank}", "Rank"),
          F("\\operatorname{nullity}", "Nullity"),
          F("\\dim", "Dimension"),
          F("\\ker", "Kernel"),
          F("\\operatorname{im}", "Image"),
          C("\\operatorname{span}", "Span", "span"),
          F("\\operatorname{diag}", "Diagonal"),
          F("\\operatorname{proj}", "Projection"),
          F("\\lambda", "Eigenvalue λ"),
          V("\\lambda", "Eigenvalue λ"),
          V("\\mu", "Eigenvalue μ"),
        ],
      },
    ],
  },
  {
    domain: "Set theory",
    groups: [
      {
        name: "Number sets",
        items: [
          S("\\mathbb{N}", "ℕ — naturals"),
          S("\\mathbb{Z}", "ℤ — integers"),
          S("\\mathbb{Q}", "ℚ — rationals"),
          S("\\mathbb{R}", "ℝ — reals"),
          S("\\mathbb{C}", "ℂ — complex"),
          S("\\mathbb{H}", "ℍ — quaternions"),
          S("\\mathbb{F}", "𝔽 — field"),
          S("\\mathbb{P}", "ℙ — primes"),
          S("\\varnothing", "∅ — empty set"),
          S("\\mathcal{P}", "Power set"),
        ],
      },
      {
        name: "Set operations",
        items: [
          O("\\cup", "Union", "add"),
          O("\\cap", "Intersection", "mul"),
          O("\\setminus", "Set difference", "sub"),
          O("\\triangle", "Symmetric difference", "add"),
          O("\\times", "Cartesian product", "mul"),
          C("\\bigcup", "Arbitrary union", "bigcup"),
          C("\\bigcap", "Arbitrary intersection", "bigcap"),
          O("\\complement", "Complement", "complement"),
        ],
      },
      {
        name: "Set relations",
        items: [
          R("\\in", "Member of", "in"),
          R("\\notin", "Not a member", "notin"),
          R("\\ni", "Contains element", "in"),
          R("\\subset", "Proper subset", "subset"),
          R("\\supset", "Proper superset", "superset"),
          R("\\subseteq", "Subset or equal", "subseteq"),
          R("\\supseteq", "Superset or equal", "superseteq"),
          R("\\cup", "Set union relation", "equal"),
          L("\\aleph_0", "ℵ₀ — cardinality"),
          V("\\#", "Cardinality #", "Operator"),
          L("\\emptyset", "Empty set"),
        ],
      },
    ],
  },
  {
    domain: "Logic",
    groups: [
      {
        name: "Connectives",
        items: [
          O("\\land", "Conjunction", "mul"),
          O("\\lor", "Disjunction", "add"),
          O("\\neg", "Negation", "neg"),
          O("\\oplus", "Exclusive or", "add"),
          O("\\implies", "Implication", "add"),
          O("\\iff", "Biconditional", "equal"),
          O("\\therefore", "Therefore", "mul"),
          O("\\because", "Because", "mul"),
        ],
      },
      {
        name: "Quantifiers & turnstiles",
        items: [
          O("\\forall", "Universal quantifier", "forall"),
          O("\\exists", "Existential quantifier", "exists"),
          V("\\nexists", "Does not exist", "Operator"),
          O("\\vdash", "Syntactic entailment", "mul"),
          O("\\models", "Semantic entailment", "mul"),
          V("\\top", "Truth", "Operator"),
          V("\\bot", "Falsity", "Operator"),
          V("\\Box", "Necessity", "Operator"),
          V("\\Diamond", "Possibility", "Operator"),
        ],
      },
      {
        name: "Boolean algebra",
        items: [
          O("\\bar{x}", "Boolean complement", "conj"),
          O("\\cdot", "AND", "mul"),
          O("+", "OR", "add"),
          V("p", "Proposition p"),
          V("q", "Proposition q"),
          V("r", "Proposition r"),
          R("\\equiv", "Logical equivalence", "equiv"),
        ],
      },
    ],
  },
  {
    domain: "Number theory",
    groups: [
      {
        name: "Divisibility",
        items: [
          R("\\mid", "Divides", "in"),
          R("\\nmid", "Does not divide", "notin"),
          O("\\operatorname{mod}", "Modulo", "mul"),
          R("\\equiv", "Congruence", "equiv"),
          C("\\gcd", "Greatest common divisor", "gcd"),
          C("\\operatorname{lcm}", "Least common multiple", "gcd"),
          V("\\phi", "Euler totient φ"),
          V("\\tau", "Divisor function τ"),
          V("\\sigma", "Sum of divisors σ"),
          V("\\mu", "Möbius function μ"),
        ],
      },
      {
        name: "Prime structures",
        items: [
          S("\\mathbb{P}", "Primes"),
          V("p", "Prime p"),
          V("q", "Prime q"),
          F("\\pi", "Prime counting function"),
          V("\\zeta", "Riemann zeta ζ"),
          V("\\operatorname{ord}", "Multiplicative order", "Function"),
          L("\\aleph_0", "Countably infinite"),
          O("\\mid", "Divisibility", "mul"),
        ],
      },
      {
        name: "Combinatorics",
        items: [
          O("!", "Factorial", "fact"),
          O("\\binom{n}{k}", "Binomial coefficient", "binom"),
          F("\\operatorname{P}", "Permutations"),
          F("\\operatorname{C}", "Combinations"),
          O("\\lfloor\\cdot\\rfloor", "Floor", "floor"),
          O("\\lceil\\cdot\\rceil", "Ceiling", "ceil"),
          V("\\#", "Cardinality", "Operator"),
          S("\\mathcal{P}", "Power set"),
        ],
      },
    ],
  },
  {
    domain: "Probability & statistics",
    groups: [
      {
        name: "Distributions & measures",
        items: [
          V("\\mathbb{P}", "Probability ℙ", "Operator"),
          V("\\mathbb{E}", "Expectation 𝔼", "Operator"),
          F("\\operatorname{Var}", "Variance"),
          F("\\operatorname{Cov}", "Covariance"),
          F("\\operatorname{Corr}", "Correlation"),
          F("\\operatorname{std}", "Standard deviation"),
          F("\\operatorname{median}", "Median"),
          F("\\operatorname{mode}", "Mode"),
          V("\\mathcal{N}", "Normal distribution", "Set"),
          F("\\Phi", "CDF Φ"),
          V("\\chi^2", "Chi-squared", "Expression"),
        ],
      },
      {
        name: "Probabilistic notation",
        items: [
          V("\\mu", "Mean μ"),
          V("\\sigma", "Standard deviation σ"),
          V("\\sigma^2", "Variance σ²", "Expression"),
          V("p", "Probability p"),
          V("X", "Random variable X"),
          V("Y", "Random variable Y"),
          C("\\bar{x}", "Sample mean", "bar"),
          C("\\hat{\\theta}", "Estimator θ̂", "hat"),
          R("\\sim", "Distributed as", "sim"),
          R("\\propto", "Proportional to", "propto"),
          R("\\mid", "Conditional", "in"),
          C("\\binom{n}{k}", "Binomial coefficient", "sqrt"),
          L("\\infty", "Infinity"),
        ],
      },
    ],
  },
  {
    domain: "Geometry & topology",
    groups: [
      {
        name: "Shapes & relations",
        items: [
          V("\\angle", "Angle", "Operator"),
          V("\\measuredangle", "Measured angle", "Operator"),
          L("\\triangle", "Triangle"),
          L("\\square", "Square"),
          L("\\odot", "Circle"),
          R("\\parallel", "Parallel", "equal"),
          R("\\perp", "Perpendicular", "equal"),
          R("\\cong", "Congruent", "cong"),
          R("\\sim", "Similar", "sim"),
          O("^\\circ", "Degrees", "degree"),
          C("\\sqrt{\\phantom{x}}", "Distance", "sqrt"),
        ],
      },
      {
        name: "Topology",
        items: [
          V("\\mathbb{R}^n", "Euclidean space", "Set"),
          O("\\cup", "Open cover union", "add"),
          V("\\partial", "Boundary ∂", "Operator"),
          V("\\tau", "Topology τ", "Set"),
          V("\\mathcal{T}", "Topology 𝒯", "Set"),
          O("\\to", "Continuous map", "mul"),
          R("\\cong", "Homeomorphic", "cong"),
          R("\\simeq", "Homotopy equivalent", "sim"),
          F("\\operatorname{int}", "Interior"),
          F("\\operatorname{cl}", "Closure"),
          C("\\bigcup", "Arbitrary union", "bigcup"),
        ],
      },
      {
        name: "Mappings & arrows",
        items: [
          R("\\to", "Arrow", "mapsto"),
          R("\\mapsto", "Maps to", "mapsto"),
          R("\\hookrightarrow", "Injection", "mapsto"),
          R("\\twoheadrightarrow", "Surjection", "mapsto"),
          R("\\leftrightarrow", "Bijection", "equal"),
          R("\\rightleftharpoons", "Equilibrium", "equal"),
          R("\\Rightarrow", "Implies", "equal"),
          R("\\Leftarrow", "Implied by", "equal"),
          R("\\uparrow", "Up arrow", "mapsto"),
          R("\\downarrow", "Down arrow", "mapsto"),
          R("\\nearrow", "Up-right arrow", "mapsto"),
          R("\\searrow", "Down-right arrow", "mapsto"),
        ],
      },
    ],
  },
  {
    domain: "Complex analysis",
    groups: [
      {
        name: "Complex notation",
        items: [
          V("z", "Complex z"),
          V("i", "Imaginary unit i"),
          V("\\overline{z}", "Conjugate z̄", "Expression"),
          F("\\Re", "Real part"),
          F("\\Im", "Imaginary part"),
          F("\\arg", "Argument"),
          F("\\operatorname{Log}", "Principal logarithm"),
          C("\\oint", "Contour integral", "oint"),
          F("\\operatorname{Res}", "Residue"),
          V("\\omega", "Root of unity ω"),
          L("\\infty", "Complex infinity"),
        ],
      },
      {
        name: "Analytic tools",
        items: [
          V("\\partial", "Cauchy–Riemann ∂", "Operator"),
          O("\\frac{\\partial}{\\partial x}", "Partial derivative", "frac"),
          C("\\sum", "Laurent series", "sum"),
          C("\\lim", "Limit", "lim"),
          V("\\varepsilon", "ε-neighbourhood"),
          C("\\left|\\cdot\\right|", "Modulus", "abs"),
        ],
      },
    ],
  },
  {
    domain: "Abstract algebra",
    groups: [
      {
        name: "Groups & rings",
        items: [
          S("\\mathbb{Z}", "ℤ — integers"),
          V("\\mathbb{Z}_n", "ℤₙ — cyclic group", "Set"),
          V("\\mathbb{F}_p", "𝔽ₚ — finite field", "Set"),
          V("\\mathfrak{g}", "Lie algebra 𝔤", "Set"),
          O("\\oplus", "Direct sum", "add"),
          O("\\otimes", "Tensor product", "mul"),
          O("\\circ", "Group operation", "mul"),
          R("\\trianglelefteq", "Normal subgroup", "subset"),
          R("\\cong", "Isomorphic", "cong"),
          R("\\simeq", "Isomorphic", "sim"),
          V("e", "Identity element"),
          V("\\operatorname{Aut}", "Automorphism group", "Set"),
          V("\\operatorname{Hom}", "Homomorphism set", "Set"),
          V("\\operatorname{Gal}", "Galois group", "Set"),
        ],
      },
      {
        name: "Structure notation",
        items: [
          C("\\langle\\cdot\\rangle", "Generated subgroup", "sqrt"),
          O("\\times", "Direct product", "mul"),
          O("\\rtimes", "Semidirect product", "mul"),
          R("\\hookrightarrow", "Embedding", "mapsto"),
          R("\\twoheadrightarrow", "Quotient map", "mapsto"),
          R("\\to", "Homomorphism", "mapsto"),
          V("\\varphi", "Homomorphism φ"),
          V("\\psi", "Homomorphism ψ"),
        ],
      },
    ],
  },
  {
    domain: "Optimization & numerics",
    groups: [
      {
        name: "Optimization",
        items: [
          C("\\arg\\min", "Argument of minimum", "argmin"),
          C("\\arg\\max", "Argument of maximum", "argmax"),
          V("\\nabla", "Gradient ∇", "Operator"),
          O("\\nabla", "Gradient operator", "nabla"),
          R("\\le", "Constraint ≤", "leq"),
          R("\\ge", "Constraint ≥", "geq"),
          R("\\approx", "Approximation", "approx"),
          V("\\lambda", "Lagrange multiplier λ"),
          V("\\epsilon", "Tolerance ε"),
          R("\\to", "Converges to", "mapsto"),
          C("\\left\\|\\cdot\\right\\|", "Objective norm", "norm"),
        ],
      },
      {
        name: "Numerical analysis",
        items: [
          V("h", "Step size h"),
          V("\\Delta x", "Grid spacing", "Expression"),
          C("\\sum", "Quadrature sum", "sum"),
          C("\\int", "Quadrature", "int"),
          O("\\left|\\cdot\\right|", "Error magnitude", "abs"),
          R("\\le", "Error bound", "leq"),
          L("\\infty", "Divergence"),
          C("\\lim", "Limit", "lim"),
        ],
      },
    ],
  },
  {
    domain: "Special functions",
    groups: [
      {
        name: "Classical special functions",
        items: [
          F("\\Gamma", "Gamma function"),
          F("\\operatorname{B}", "Beta function"),
          F("\\zeta", "Riemann zeta"),
          F("\\operatorname{erf}", "Error function"),
          F("\\operatorname{erfc}", "Complementary error function"),
          F("\\operatorname{Li}", "Logarithmic integral"),
          F("J_n", "Bessel function"),
          F("Y_n", "Neumann function"),
          F("P_n", "Legendre polynomial"),
          F("H_n", "Hermite polynomial"),
          F("T_n", "Chebyshev polynomial"),
          F("\\mathcal{L}", "Laplace transform"),
          F("\\mathcal{F}", "Fourier transform"),
          V("\\delta", "Dirac delta", "Operator"),
        ],
      },
      {
        name: "Transforms & operators",
        items: [
          C("\\int", "Transform integral", "int"),
          C("\\lim", "Limit", "lim"),
          O("\\ast", "Convolution", "mul"),
          O("\\star", "Cross-correlation", "mul"),
          V("s", "Laplace variable s"),
          V("\\omega", "Frequency ω"),
          V("\\xi", "Fourier variable ξ"),
        ],
      },
    ],
  },
  {
    domain: "Greek alphabet",
    groups: [
      {
        name: "Lowercase",
        items: DAYS.map((name, index) => V(`\\${name}`, `${GREEK[index]} — ${name}`)),
      },
      {
        name: "Uppercase",
        items: DAYS_UPPER.map((name, index) => V(`\\${name}`, `${GREEK_UPPER[index]} — ${name}`)),
      },
    ],
  },
  {
    domain: "Notation & decoration",
    groups: [
      {
        name: "Accents",
        items: [
          C("\\hat{x}", "Hat", "hat"),
          C("\\bar{x}", "Bar", "bar"),
          C("\\vec{v}", "Vector accent", "vec"),
          C("\\dot{x}", "Dot accent", "dot"),
          C("\\ddot{x}", "Double dot", "ddot"),
          C("\\tilde{x}", "Tilde", "tilde"),
          C("\\overline{x}", "Overline", "overline"),
          C("\\underline{x}", "Underline", "underline"),
          C("\\check{x}", "Check", "check"),
          C("\\widehat{AB}", "Wide hat", "widehat"),
          C("\\widetilde{AB}", "Wide tilde", "widetilde"),
        ],
      },
      {
        name: "Enclosures & delimiters",
        items: [
          O("\\left|\\cdot\\right|", "Absolute value", "abs"),
          O("\\left\\|\\cdot\\right\\|", "Norm", "norm"),
          O("\\lfloor\\cdot\\rfloor", "Floor", "floor"),
          O("\\lceil\\cdot\\rceil", "Ceiling", "ceil"),
          L("\\langle", "Left angle"),
          L("\\rangle", "Right angle"),
          L("\\{", "Left brace"),
          L("\\}", "Right brace"),
          L("|", "Vertical bar"),
          L("\\|", "Double bar"),
          L("\\#", "Hash"),
          L("\\&", "Ampersand"),
          C("\\langle\\cdot\\rangle", "Inner product", "sqrt"),
        ],
      },
      {
        name: "Ellipses & marks",
        items: [
          L("\\ldots", "Ellipsis"),
          L("\\cdots", "Centred ellipsis"),
          L("\\vdots", "Vertical dots"),
          L("\\ddots", "Diagonal dots"),
          L("\\dots", "Dots"),
          L("\\square", "QED"),
          L("\\checkmark", "Check"),
          L("\\ast", "Asterisk"),
          L("\\star", "Star"),
          L("\\bullet", "Bullet"),
          L("\\circ", "Ring"),
        ],
      },
    ],
  },
];

function slugDomain(domain: string): string {
  return domain
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

function buildLibrary(): SymbolEntry[] {
  const byToken = new Map<string, SymbolEntry>();
  RAW_LIBRARY.forEach((domain) => {
    domain.groups.forEach((group) => {
      group.items.forEach((item, offset) => {
        const existing = byToken.get(item.token);
        if (existing) {
          // A wrapper (accent / postfix / prefix operator) is richer than a bare
          // variable of the same token, so it upgrades the first occurrence.
          if (existing.kind === "variable" && (item.kind === "container" || item.kind === "operator")) {
            byToken.set(item.token, {
              ...existing,
              kind: item.kind,
              variant: item.variant ?? null,
              label: item.label,
              type: item.kind === "container" ? "Expression" : "Operator",
            });
          }
          return;
        }
        byToken.set(item.token, {
          ...item,
          id: `lib-${slugDomain(domain.domain)}-${group.name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${offset}`,
          domain: domain.domain,
          subdomain: group.name,
          variant: item.variant ?? null,
          type:
            item.type ??
            (item.kind === "literal"
              ? "Scalar"
              : item.kind === "set"
                ? "Set"
                : item.kind === "relation"
                  ? "Relation"
                  : item.kind === "operator"
                    ? "Operator"
                    : item.kind === "function"
                      ? "Function"
                      : item.kind === "container"
                        ? "Expression"
                        : "Variable"),
        });
      });
    });
  });
  return Array.from(byToken.values());
}

export const SYMBOL_LIBRARY: SymbolEntry[] = buildLibrary();

export const LIBRARY_BY_ID = new Map(SYMBOL_LIBRARY.map((entry) => [entry.id, entry]));
export const LIBRARY_BY_TOKEN = new Map(SYMBOL_LIBRARY.map((entry) => [entry.token, entry]));

/** Command-level lookup so `\hat`, `\binom`, `\vec` resolve their library spec. */
export const LIBRARY_BY_COMMAND = (() => {
  const priority = (entry: SymbolEntry): number => {
    if (entry.kind === "container") return 4;
    if (entry.kind === "operator") return 3;
    if (entry.kind === "function") return 2;
    if (entry.kind === "relation") return 1;
    return 0;
  };
  const map = new Map<string, SymbolEntry>();
  for (const entry of SYMBOL_LIBRARY) {
    if (!entry.token.startsWith("\\")) continue;
    const brace = entry.token.search(/[\[{[]/);
    const command = brace === -1 ? entry.token : entry.token.slice(0, brace);
    if (!command.startsWith("\\") || command.length < 2) continue;
    const existing = map.get(command);
    if (!existing || priority(entry) > priority(existing)) map.set(command, entry);
  }
  return map;
})();

export const LIBRARY_DOMAINS: { domain: string; count: number; subdomains: string[] }[] =
  RAW_LIBRARY.map((entry) => {
    const seen = new Set<string>();
    const subdomains: string[] = [];
    for (const group of entry.groups) {
      if (!subdomains.includes(group.name)) subdomains.push(group.name);
      for (const item of group.items) {
        if (LIBRARY_BY_TOKEN.get(item.token)?.domain === entry.domain) seen.add(item.token);
      }
    }
    return { domain: entry.domain, count: seen.size, subdomains };
  });

export const LIBRARY_COUNT = SYMBOL_LIBRARY.length;

export interface SymbolFilter {
  query?: string;
  domain?: string;
}

export function filterLibrary({ query = "", domain = "All" }: SymbolFilter): SymbolEntry[] {
  const needle = query.trim().toLowerCase();
  return SYMBOL_LIBRARY.filter((entry) => {
    if (domain !== "All" && entry.domain !== domain) return false;
    if (!needle) return true;
    return (
      entry.token.toLowerCase().includes(needle) ||
      entry.label.toLowerCase().includes(needle) ||
      entry.domain.toLowerCase().includes(needle) ||
      entry.subdomain.toLowerCase().includes(needle) ||
      (entry.variant ?? "").toLowerCase().includes(needle)
    );
  });
}
