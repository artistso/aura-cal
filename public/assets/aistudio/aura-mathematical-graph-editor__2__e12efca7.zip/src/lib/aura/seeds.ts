import {
  type AuraEdge,
  type AuraGraph,
  type AuraNode,
  type PortId,
  makeNode,
  newId,
} from "./ontology";
import { indexGraph, layoutComponent } from "./engine";

export interface SeedDocument {
  title: string;
  subtitle: string;
  graph: AuraGraph;
}

interface Draft {
  nodes: AuraNode[];
  edges: AuraEdge[];
  add(spec: Parameters<typeof makeNode>[0]): AuraNode;
  bind(parent: AuraNode, port: PortId, child: AuraNode): AuraEdge;
  finish(rootId: string, anchor: { x: number; y: number }): AuraGraph;
}

function draft(): Draft {
  const nodes: AuraNode[] = [];
  const edges: AuraEdge[] = [];
  return {
    nodes,
    edges,
    add(spec) {
      const node = makeNode(spec);
      nodes.push(node);
      return node;
    },
    bind(parent, port, child) {
      const edge: AuraEdge = { id: newId(), source: parent.id, target: child.id, port, role: port };
      edges.push(edge);
      return edge;
    },
    finish(rootId, anchor) {
      const graph: AuraGraph = { nodes: [...nodes], edges: [...edges] };
      const positions = layoutComponent(graph, rootId, anchor, indexGraph(graph));
      return {
        nodes: nodes.map((node) => {
          const point = positions.get(node.id);
          return point ? { ...node, x: point.x, y: point.y } : node;
        }),
        edges,
      };
    },
  };
}

export const SEED_DOCUMENTS: SeedDocument[] = [
  {
    title: "Energy–mass equivalence",
    subtitle: "Drag E toward the mc² cluster and watch the ghost paths resolve.",
    graph: (() => {
      const d = draft();
      const energy = d.add({
        kind: "variable",
        token: "E",
        label: "Energy E",
        type: "Variable",
        x: 300,
        y: 300,
      });
      const mass = d.add({ kind: "variable", token: "m", label: "Mass m", type: "Variable" });
      const speed = d.add({ kind: "variable", token: "c", label: "Speed c", type: "Variable" });
      const two = d.add({ kind: "literal", token: "2", label: "Literal 2", type: "Scalar" });
      const power = d.add({
        kind: "operator",
        token: "^",
        label: "Power",
        type: "Operator",
        variant: "power",
      });
      const product = d.add({
        kind: "operator",
        token: "\\,",
        label: "Juxtaposition",
        type: "Operator",
        variant: "juxta",
      });
      d.bind(power, "base", speed);
      d.bind(power, "exponent", two);
      d.bind(product, "left", mass);
      d.bind(product, "right", power);
      const mapping = d.add({
        kind: "relation",
        token: "\\to",
        label: "Mapping",
        type: "Relation",
        variant: "mapsto",
        x: 300,
        y: 452,
      });
      const radical = d.add({
        kind: "container",
        token: "\\sqrt{\\phantom{x}}",
        label: "Square root",
        type: "Expression",
        variant: "sqrt",
        x: 470,
        y: 452,
      });
      void energy;
      void mapping;
      void radical;
      return d.finish(product.id, { x: 820, y: 300 });
    })(),
  },
  {
    title: "Pythagorean identity",
    subtitle: "A committed relation. Select a vertex to inspect ports, types and diagnostics.",
    graph: (() => {
      const d = draft();
      const a = d.add({ kind: "variable", token: "a", label: "Variable a", type: "Variable" });
      const b = d.add({ kind: "variable", token: "b", label: "Variable b", type: "Variable" });
      const c = d.add({ kind: "variable", token: "c", label: "Variable c", type: "Variable" });
      const twoA = d.add({ kind: "literal", token: "2", label: "Literal 2", type: "Scalar" });
      const twoB = d.add({ kind: "literal", token: "2", label: "Literal 2", type: "Scalar" });
      const twoC = d.add({ kind: "literal", token: "2", label: "Literal 2", type: "Scalar" });
      const powA = d.add({ kind: "operator", token: "^", label: "Power", type: "Operator", variant: "power" });
      const powB = d.add({ kind: "operator", token: "^", label: "Power", type: "Operator", variant: "power" });
      const powC = d.add({ kind: "operator", token: "^", label: "Power", type: "Operator", variant: "power" });
      const add = d.add({ kind: "operator", token: "+", label: "Addition", type: "Operator", variant: "add" });
      const equal = d.add({
        kind: "relation",
        token: "=",
        label: "Equality",
        type: "Relation",
        variant: "equal",
      });
      d.bind(powA, "base", a);
      d.bind(powA, "exponent", twoA);
      d.bind(powB, "base", b);
      d.bind(powB, "exponent", twoB);
      d.bind(powC, "base", c);
      d.bind(powC, "exponent", twoC);
      d.bind(add, "left", powA);
      d.bind(add, "right", powB);
      d.bind(equal, "left", add);
      d.bind(equal, "right", powC);
      d.add({
        kind: "container",
        token: "\\int",
        label: "Integral",
        type: "Expression",
        variant: "int",
        x: 360,
        y: 560,
      });
      d.add({ kind: "literal", token: "2", label: "Literal 2", type: "Scalar", x: 520, y: 560 });
      return d.finish(equal.id, { x: 760, y: 320 });
    })(),
  },
  {
    title: "Integral · type sandbox",
    subtitle: "Limits bind into the ∫ container. Try binding the matrix A into + with scalar 2.",
    graph: (() => {
      const d = draft();
      const zero = d.add({ kind: "literal", token: "0", label: "Literal 0", type: "Scalar" });
      const one = d.add({ kind: "literal", token: "1", label: "Literal 1", type: "Scalar" });
      const x = d.add({ kind: "variable", token: "x", label: "Variable x", type: "Variable" });
      const twoUpper = d.add({ kind: "literal", token: "2", label: "Literal 2", type: "Scalar" });
      const twoLower = d.add({ kind: "literal", token: "2", label: "Literal 2", type: "Scalar" });
      const dx = d.add({ kind: "variable", token: "d", label: "Differential d", type: "Variable" });
      const body = d.add({ kind: "operator", token: "\\times", label: "Product", type: "Operator", variant: "mul" });
      const power = d.add({ kind: "operator", token: "^", label: "Power", type: "Operator", variant: "power" });
      const frac = d.add({ kind: "operator", token: "\\frac", label: "Fraction", type: "Operator", variant: "frac" });
      const integral = d.add({
        kind: "container",
        token: "\\int",
        label: "Integral",
        type: "Expression",
        variant: "int",
      });
      d.bind(power, "base", x);
      d.bind(power, "exponent", twoUpper);
      d.bind(frac, "numerator", power);
      d.bind(frac, "denominator", twoLower);
      d.bind(body, "left", frac);
      d.bind(body, "right", dx);
      d.bind(integral, "lower", zero);
      d.bind(integral, "upper", one);
      d.bind(integral, "body", body);
      d.add({
        kind: "operator",
        token: "+",
        label: "Addition",
        type: "Operator",
        variant: "add",
        x: 520,
        y: 560,
      });
      d.add({
        kind: "variable",
        token: "A",
        label: "Matrix A",
        type: "Matrix",
        x: 660,
        y: 560,
      });
      d.add({ kind: "literal", token: "2", label: "Literal 2", type: "Scalar", x: 790, y: 560 });
      d.add({
        kind: "set",
        token: "\\mathbb{R}",
        label: "ℝ",
        type: "Set",
        x: 380,
        y: 460,
      });
      return d.finish(integral.id, { x: 720, y: 300 });
    })(),
  },
  {
    title: "Evaluator & plot",
    subtitle:
      "Fold the constant cluster, then open the plot tab to sample y = 2x² − 3 and sin x straight from the graph.",
    graph: (() => {
      const d = draft();
      // y = 2x^2 - 3
      const y = d.add({ kind: "variable", token: "y", label: "Variable y", type: "Variable" });
      const x1 = d.add({ kind: "variable", token: "x", label: "Variable x", type: "Variable" });
      const two = d.add({ kind: "literal", token: "2", label: "Literal 2", type: "Scalar" });
      const three = d.add({ kind: "literal", token: "3", label: "Literal 3", type: "Scalar" });
      const twoExp = d.add({ kind: "literal", token: "2", label: "Literal 2", type: "Scalar" });
      const power = d.add({ kind: "operator", token: "^", label: "Power", type: "Operator", variant: "power" });
      const product = d.add({ kind: "operator", token: "\\,", label: "Juxtaposition", type: "Operator", variant: "juxta" });
      const minus = d.add({ kind: "operator", token: "-", label: "Subtraction", type: "Operator", variant: "sub" });
      const equal = d.add({ kind: "relation", token: "=", label: "Equality", type: "Relation", variant: "equal" });
      d.bind(power, "base", x1);
      d.bind(power, "exponent", twoExp);
      d.bind(product, "left", two);
      d.bind(product, "right", power);
      d.bind(minus, "left", product);
      d.bind(minus, "right", three);
      d.bind(equal, "left", y);
      d.bind(equal, "right", minus);
      // sin x as a standalone plottable cluster
      const sin = d.add({ kind: "function", token: "\\sin", label: "sin", type: "Function", variant: "sin" });
      const x2 = d.add({ kind: "variable", token: "x", label: "Variable x", type: "Variable" });
      d.bind(sin, "arg", x2);
      // A constant cluster for fold-constants: (6 + 2) / 4
      const six = d.add({ kind: "literal", token: "6", label: "Literal 6", type: "Scalar" });
      const twoC = d.add({ kind: "literal", token: "2", label: "Literal 2", type: "Scalar" });
      const four = d.add({ kind: "literal", token: "4", label: "Literal 4", type: "Scalar" });
      const plus = d.add({ kind: "operator", token: "+", label: "Addition", type: "Operator", variant: "add" });
      const frac = d.add({ kind: "operator", token: "\\frac", label: "Fraction", type: "Operator", variant: "frac" });
      d.bind(plus, "left", six);
      d.bind(plus, "right", twoC);
      d.bind(frac, "numerator", plus);
      d.bind(frac, "denominator", four);
      const relation = d.finish(equal.id, { x: 620, y: 300 });
      const sinLayout = d.finish(sin.id, { x: 420, y: 470 });
      const fracLayout = d.finish(frac.id, { x: 760, y: 470 });
      const merged = new Map<string, { x: number; y: number }>();
      for (const node of [...relation.nodes, ...sinLayout.nodes, ...fracLayout.nodes]) {
        if (!merged.has(node.id)) merged.set(node.id, { x: node.x, y: node.y });
      }
      return {
        nodes: d.nodes.map((node) => {
          const point = merged.get(node.id);
          return point ? { ...node, x: point.x, y: point.y } : node;
        }),
        edges: d.edges,
      };
    })(),
  },
  {
    title: "Discovery playground",
    subtitle:
      "Six free clusters. Press Auto-connect and let the engine find, test and rank bindings that hold true.",
    graph: (() => {
      const d = draft();
      const layouts: { rootId: string; anchor: { x: number; y: number } }[] = [];

      // Cluster 1 — sin²θ + cos²θ
      const theta = d.add({ kind: "variable", token: "\\theta", label: "Angle θ", type: "Variable" });
      const twoA = d.add({ kind: "literal", token: "2", label: "Literal 2", type: "Scalar" });
      const twoB = d.add({ kind: "literal", token: "2", label: "Literal 2", type: "Scalar" });
      const sin = d.add({ kind: "function", token: "\\sin", label: "sin", type: "Function", variant: "sin" });
      const cos = d.add({ kind: "function", token: "\\cos", label: "cos", type: "Function", variant: "cos" });
      const sinSq = d.add({ kind: "operator", token: "^", label: "Power", type: "Operator", variant: "power" });
      const cosSq = d.add({ kind: "operator", token: "^", label: "Power", type: "Operator", variant: "power" });
      const identity = d.add({ kind: "operator", token: "+", label: "Addition", type: "Operator", variant: "add" });
      d.bind(sin, "arg", theta);
      d.bind(cos, "arg", theta);
      d.bind(sinSq, "base", sin);
      d.bind(sinSq, "exponent", twoA);
      d.bind(cosSq, "base", cos);
      d.bind(cosSq, "exponent", twoB);
      d.bind(identity, "left", sinSq);
      d.bind(identity, "right", cosSq);
      layouts.push({ rootId: identity.id, anchor: { x: 520, y: 250 } });

      // Cluster 2 — 1
      const one = d.add({ kind: "literal", token: "1", label: "Literal 1", type: "Scalar" });
      layouts.push({ rootId: one.id, anchor: { x: 900, y: 250 } });

      // Cluster 3 — (6 + 2) / 4
      const six = d.add({ kind: "literal", token: "6", label: "Literal 6", type: "Scalar" });
      const twoC = d.add({ kind: "literal", token: "2", label: "Literal 2", type: "Scalar" });
      const four = d.add({ kind: "literal", token: "4", label: "Literal 4", type: "Scalar" });
      const plus = d.add({ kind: "operator", token: "+", label: "Addition", type: "Operator", variant: "add" });
      const quotient = d.add({ kind: "operator", token: "\\frac", label: "Fraction", type: "Operator", variant: "frac" });
      d.bind(plus, "left", six);
      d.bind(plus, "right", twoC);
      d.bind(quotient, "numerator", plus);
      d.bind(quotient, "denominator", four);
      layouts.push({ rootId: quotient.id, anchor: { x: 520, y: 470 } });

      // Cluster 4 — 2
      const twoD = d.add({ kind: "literal", token: "2", label: "Literal 2", type: "Scalar" });
      layouts.push({ rootId: twoD.id, anchor: { x: 760, y: 470 } });

      // Cluster 5 — E
      const energy = d.add({ kind: "variable", token: "E", label: "Energy E", type: "Variable" });
      layouts.push({ rootId: energy.id, anchor: { x: 300, y: 660 } });

      // Cluster 6 — m c²
      const mass = d.add({ kind: "variable", token: "m", label: "Mass m", type: "Variable" });
      const speed = d.add({ kind: "variable", token: "c", label: "Speed c", type: "Variable" });
      const twoE = d.add({ kind: "literal", token: "2", label: "Literal 2", type: "Scalar" });
      const cSquared = d.add({ kind: "operator", token: "^", label: "Power", type: "Operator", variant: "power" });
      const mcSquared = d.add({ kind: "operator", token: "\\,", label: "Juxtaposition", type: "Operator", variant: "juxta" });
      d.bind(cSquared, "base", speed);
      d.bind(cSquared, "exponent", twoE);
      d.bind(mcSquared, "left", mass);
      d.bind(mcSquared, "right", cSquared);
      layouts.push({ rootId: mcSquared.id, anchor: { x: 700, y: 660 } });

      // Cluster 7 — the reals, so membership has a valid target
      const reals = d.add({ kind: "set", token: "\\mathbb{R}", label: "ℝ", type: "Set" });
      layouts.push({ rootId: reals.id, anchor: { x: 1040, y: 660 } });

      const positions = new Map<string, { x: number; y: number }>();
      for (const entry of layouts) {
        const layout = d.finish(entry.rootId, entry.anchor);
        for (const node of layout.nodes) {
          if (!positions.has(node.id)) positions.set(node.id, { x: node.x, y: node.y });
        }
      }
      return {
        nodes: d.nodes.map((node) => {
          const point = positions.get(node.id);
          return point ? { ...node, x: point.x, y: point.y } : node;
        }),
        edges: d.edges,
      };
    })(),
  },
];

export const EMPTY_DOCUMENT = (title: string): SeedDocument => ({
  title,
  subtitle: "An empty infinite canvas. Add elements or write an expression with the pen.",
  graph: (() => {
    const d = draft();
    d.add({ kind: "variable", token: "x", label: "Variable x", type: "Variable", x: 620, y: 320 });
    return { nodes: d.nodes, edges: d.edges };
  })(),
});
