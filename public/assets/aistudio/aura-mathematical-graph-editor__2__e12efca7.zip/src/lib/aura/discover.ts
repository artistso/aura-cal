/**
 * Aura's discovery engine.
 *
 * Given a canvas, enumerate *structurally admissible* connections between
 * free-standing clusters, verify each proposal numerically, and rank the
 * survivors so that surprising-but-true bindings rise to the top.
 *
 * The single scalar `scale` (0–1) controls how far the engine looks and how
 * speculative it is allowed to be:
 *   0.00–0.25  literal   — nearby clusters, equality and addition only
 *   0.25–0.50  cautious  — adjacent clusters, arithmetic, comparisons
 *   0.50–0.75  balanced  — whole canvas, set/arrow/speculative relations
 *   0.75–1.00  wild      — everything, novelty weighted over proximity
 *
 * Verification is sampling-based and deterministic: every proposal is tested
 * on the same pseudo-random assignments, so the same canvas always yields the
 * same verdicts.
 */

import {
  OPERAND_TYPES,
  type AuraEdge,
  type AuraGraph,
  type AuraNode,
  type MathType,
  type PortId,
  admits,
  isShareable,
  makeNode,
  newId,
} from "./ontology";
import {
  childOf,
  commitCandidate,
  componentRoot,
  effectiveType,
  graphBounds,
  indexGraph,
  toLatex,
} from "./engine";
import { collectVariables, evalExpression } from "./evaluate";

export type Verdict = "holds" | "refuted" | "unknown";

export type Family =
  | "relation"
  | "arithmetic"
  | "comparison"
  | "set"
  | "speculative"
  | "transform";

export interface ConnectionPatch {
  kind: string;
  addedNodes: AuraNode[];
  addedEdges: AuraEdge[];
  removedEdgeIds: string[];
  draggedId: string;
  focusId: string;
}

export interface Proposal {
  id: string;
  kind: string;
  family: Family;
  title: string;
  rationale: string;
  hint: string | null;
  leftLatex: string;
  rightLatex: string;
  previewLatex: string;
  score: number;
  novelty: number;
  verdict: Verdict;
  confidence: number;
  evidence: string;
  counterexample: string | null;
  samples: number;
  clusterIds: string[];
  patch: ConnectionPatch;
  color: string;
}

export interface DiscoveryOptions {
  scale: number;
  families?: Family[];
  limit?: number;
  focusIds?: string[];
}

export interface DiscoveryResult {
  proposals: Proposal[];
  clusters: number;
  considered: number;
  holds: number;
  refuted: number;
  scale: number;
  families: Family[];
}

interface Cluster {
  node: AuraNode;
  latex: string;
  vars: string[];
  type: MathType;
  isSet: boolean;
  value: number | null;
}

interface Template {
  id: string;
  kind: "relation" | "operator";
  variant: string;
  token: string;
  label: string;
  family: Family;
  ports: [PortId, PortId];
  scaleMin: number;
  check: "equality" | "order" | "none";
  requireSetRight?: boolean;
  commutative?: boolean;
}

const TEMPLATES: Template[] = [
  {
    id: "equal",
    kind: "relation",
    variant: "equal",
    token: "=",
    label: "Equality",
    family: "relation",
    ports: ["left", "right"],
    scaleMin: 0,
    check: "equality",
    commutative: true,
  },
  {
    id: "add",
    kind: "operator",
    variant: "add",
    token: "+",
    label: "Addition",
    family: "arithmetic",
    ports: ["left", "right"],
    scaleMin: 0.05,
    check: "none",
    commutative: true,
  },
  {
    id: "mul",
    kind: "operator",
    variant: "mul",
    token: "\\times",
    label: "Multiplication",
    family: "arithmetic",
    ports: ["left", "right"],
    scaleMin: 0.2,
    check: "none",
    commutative: true,
  },
  {
    id: "juxta",
    kind: "operator",
    variant: "juxta",
    token: "\\,",
    label: "Juxtaposition",
    family: "arithmetic",
    ports: ["left", "right"],
    scaleMin: 0.3,
    check: "none",
  },
  {
    id: "sub",
    kind: "operator",
    variant: "sub",
    token: "-",
    label: "Subtraction",
    family: "arithmetic",
    ports: ["left", "right"],
    scaleMin: 0.4,
    check: "none",
  },
  {
    id: "power",
    kind: "operator",
    variant: "power",
    token: "^",
    label: "Exponentiation",
    family: "arithmetic",
    ports: ["base", "exponent"],
    scaleMin: 0.35,
    check: "none",
  },
  {
    id: "frac",
    kind: "operator",
    variant: "frac",
    token: "\\frac",
    label: "Ratio",
    family: "arithmetic",
    ports: ["numerator", "denominator"],
    scaleMin: 0.5,
    check: "none",
  },
  {
    id: "leq",
    kind: "relation",
    variant: "leq",
    token: "\\le",
    label: "Order",
    family: "comparison",
    ports: ["left", "right"],
    scaleMin: 0.35,
    check: "order",
  },
  {
    id: "approx",
    kind: "relation",
    variant: "approx",
    token: "\\approx",
    label: "Approximation",
    family: "comparison",
    ports: ["left", "right"],
    scaleMin: 0.55,
    check: "equality",
    commutative: true,
  },
  {
    id: "mapsto",
    kind: "relation",
    variant: "mapsto",
    token: "\\to",
    label: "Mapping",
    family: "speculative",
    ports: ["left", "right"],
    scaleMin: 0.6,
    check: "none",
  },
  {
    id: "in",
    kind: "relation",
    variant: "in",
    token: "\\in",
    label: "Membership",
    family: "set",
    ports: ["left", "right"],
    scaleMin: 0.5,
    check: "none",
    requireSetRight: true,
  },
];

interface Transform {
  id: string;
  kind: "function" | "container" | "operator";
  variant: string;
  token: string;
  label: string;
}

const TRANSFORMS: Transform[] = [
  { id: "sqrt", kind: "container", variant: "sqrt", token: "\\sqrt{\\phantom{x}}", label: "Square root" },
  { id: "sin", kind: "function", variant: "sin", token: "\\sin", label: "sin" },
  { id: "cos", kind: "function", variant: "cos", token: "\\cos", label: "cos" },
  { id: "ln", kind: "function", variant: "ln", token: "\\ln", label: "ln" },
  { id: "abs", kind: "operator", variant: "abs", token: "\\left|\\cdot\\right|", label: "Absolute value" },
  { id: "exp", kind: "function", variant: "exp", token: "\\exp", label: "exp" },
  { id: "det", kind: "function", variant: "det", token: "\\det", label: "det" },
];

const COLORS = ["#f0b45a", "#5eead4", "#f472b6", "#a78bfa", "#60a5fa", "#34d399"];

const SAMPLE_VALUES = [
  -2.4, -1.7, -1.1, -0.5, -0.2, 0.333, 0.6, 1.3, 1.9, 2.7, -3.1, 4.2,
];

export function scaleBand(scale: number): string {
  if (scale < 0.25) return "literal";
  if (scale < 0.5) return "cautious";
  if (scale < 0.75) return "balanced";
  return "wild";
}

function clampScale(scale: number): number {
  if (!Number.isFinite(scale)) return 0.5;
  return Math.max(0, Math.min(1, scale));
}

function normalise(latex: string): string {
  return latex.replace(/\\[a-zA-Z]+|[{}^_\s]/g, "").toLowerCase();
}

function similarity(a: string, b: string): number {
  const left = normalise(a);
  const right = normalise(b);
  if (!left || !right) return 0;
  if (left === right) return 1;
  const set = new Set(left);
  let shared = 0;
  for (const char of new Set(right)) if (set.has(char)) shared += 1;
  return shared / Math.max(set.size, new Set(right).size, 1);
}

function buildClusters(graph: AuraGraph): Cluster[] {
  const index = indexGraph(graph);
  return graph.nodes
    .filter((node) => !index.parent.has(node.id))
    .map((node) => {
      const type = effectiveType(index, node.id);
      const value = evalExpression(index, node.id, {});
      return {
        node,
        latex: toLatex(graph, node.id, index),
        vars: Array.from(collectVariables(index, node.id)).sort(),
        type,
        isSet: type === "Set" || node.kind === "set",
        value: value !== null && Number.isFinite(value) ? value : null,
      } satisfies Cluster;
    });
}

function envFor(vars: string[], step: number): Record<string, number> {
  const env: Record<string, number> = {};
  vars.forEach((name, offset) => {
    const seat = (step + offset * 3) % SAMPLE_VALUES.length;
    env[name] = SAMPLE_VALUES[seat];
  });
  return env;
}

interface Verification {
  verdict: Verdict;
  confidence: number;
  evidence: string;
  counterexample: string | null;
  samples: number;
}

function verifyPair(
  index: ReturnType<typeof indexGraph>,
  left: Cluster,
  right: Cluster,
  check: "equality" | "order" | "none",
): Verification {
  const vars = Array.from(new Set([...left.vars, ...right.vars]));
  if (vars.length > 4) {
    return {
      verdict: "unknown",
      confidence: 0.3,
      evidence: `${vars.length} free variables — too many to sample meaningfully`,
      counterexample: null,
      samples: 0,
    };
  }
  const rounds = vars.length > 0 ? 12 : 1;
  let valid = 0;
  let agreeing = 0;
  let counterexample: string | null = null;

  for (let step = 0; step < rounds; step += 1) {
    const env = envFor(vars, step);
    const a = evalExpression(index, left.node.id, env, new Set<string>());
    const b = evalExpression(index, right.node.id, env, new Set<string>());
    if (a === null || b === null || !Number.isFinite(a) || !Number.isFinite(b)) continue;
    valid += 1;
    const scale = Math.max(1, Math.abs(a), Math.abs(b));
    const tolerance = 1e-6 * scale;
    const passed =
      check === "equality"
        ? Math.abs(a - b) <= tolerance
        : check === "order"
          ? a <= b + tolerance
          : true;
    if (passed) {
      agreeing += 1;
    } else if (!counterexample) {
      const assignment = vars.length
        ? vars.map((name) => `${name}=${Number(env[name].toFixed(3))}`).join(", ")
        : "numeric case";
      counterexample = `${assignment}: ${Number(a.toPrecision(6))} ${check === "order" ? ">" : "≠"} ${Number(b.toPrecision(6))}`;
    }
  }

  if (check === "none") {
    return {
      verdict: "unknown",
      confidence: valid > 0 ? 0.5 : 0.25,
      evidence:
        valid > 0
          ? `evaluable on ${valid} sampled point${valid === 1 ? "" : "s"} — no truth value to test`
          : "not numerically evaluable",
      counterexample: null,
      samples: valid,
    };
  }

  if (valid === 0) {
    return {
      verdict: "unknown",
      confidence: 0.25,
      evidence: "no sampled point evaluated on both sides",
      counterexample: null,
      samples: 0,
    };
  }
  if (agreeing === valid) {
    return {
      verdict: "holds",
      confidence: Math.min(0.99, 0.62 + 0.037 * valid),
      evidence:
        vars.length === 0
          ? `numeric check passes — both sides evaluate to ${Number(
              evalExpression(index, left.node.id, {}, new Set<string>()) ?? 0,
            )}`
          : `${valid}/${valid} sampled assignments agree within relative 1e-6`,
      counterexample: null,
      samples: valid,
    };
  }
  return {
    verdict: "refuted",
    confidence: Math.min(0.97, 0.55 + 0.04 * (valid - agreeing)),
    evidence: `${agreeing}/${valid} sampled assignments agree — counterexample found`,
    counterexample,
    samples: valid,
  };
}

function recognisedLaw(leftLatex: string, rightLatex: string, token: string): string | null {
  const left = normalise(leftLatex);
  const right = normalise(rightLatex);
  if (token !== "=" && token !== "\\approx") return null;
  const both = `${left}|${right}`;
  const has = (...parts: string[]) => parts.every((part) => both.includes(part));
  if (has("sin", "cos") && (left === "1" || right === "1")) return "Pythagorean trigonometric identity";
  if (has("cos2")) return "Double-angle identity";
  if (has("m", "c2") && (left === "e" || right === "e")) return "Mass–energy equivalence";
  if (has("a2", "b2", "c2")) return "Pythagorean relation";
  if (has("ln", "e")) return "Logarithm–exponential inverse pair";
  if (has("det") && has("ab")) return "Multiplicativity of the determinant";
  if (left.includes("int") || right.includes("int")) return "Integral identity candidate";
  if (has("sum") && has("n")) return "Series identity candidate";
  return null;
}

function buildPatch(
  graph: AuraGraph,
  left: Cluster,
  right: Cluster,
  template: Template,
  scale: number,
  hint: string | null,
): { patch: ConnectionPatch; previewLatex: string } {
  const binder = makeNode({
    kind: template.kind,
    type: template.kind === "relation" ? "Relation" : "Operator",
    token: template.kind === "relation" ? template.token : template.label === "Ratio" ? "\\frac" : template.token,
    label: template.label,
    variant: template.variant,
    x: (left.node.x + right.node.x) / 2,
    y: (left.node.y + right.node.y) / 2,
    meta: { discovered: true, scale, template: template.id, hint },
  });
  const leftEdge: AuraEdge = {
    id: newId(),
    source: binder.id,
    target: left.node.id,
    port: template.ports[0],
    role: template.ports[0],
  };
  const rightEdge: AuraEdge = {
    id: newId(),
    source: binder.id,
    target: right.node.id,
    port: template.ports[1],
    role: template.ports[1],
  };
  const temp: AuraGraph = {
    nodes: [...graph.nodes, binder],
    edges: [...graph.edges, leftEdge, rightEdge],
  };
  let previewLatex = "";
  try {
    previewLatex = toLatex(temp, binder.id, indexGraph(temp));
  } catch {
    previewLatex = `${left.latex} ${template.token} ${right.latex}`;
  }
  return {
    patch: {
      kind: `discover-${template.id}`,
      addedNodes: [binder],
      addedEdges: [leftEdge, rightEdge],
      removedEdgeIds: [],
      draggedId: left.node.id,
      focusId: binder.id,
    },
    previewLatex,
  };
}

function buildTransformPatch(
  graph: AuraGraph,
  cluster: Cluster,
  transform: Transform,
  scale: number,
): { patch: ConnectionPatch; previewLatex: string } {
  const node = makeNode({
    kind: transform.kind,
    type: transform.kind === "function" ? "Function" : transform.kind === "operator" ? "Operator" : "Expression",
    token: transform.token,
    label: transform.label,
    variant: transform.variant,
    x: cluster.node.x - 70,
    y: cluster.node.y,
    meta: { discovered: true, scale, transform: transform.id },
  });
  const port: PortId = transform.kind === "container" ? "body" : "arg";
  const edge: AuraEdge = {
    id: newId(),
    source: node.id,
    target: cluster.node.id,
    port,
    role: port,
  };
  const temp: AuraGraph = { nodes: [...graph.nodes, node], edges: [...graph.edges, edge] };
  let previewLatex = "";
  try {
    previewLatex = toLatex(temp, node.id, indexGraph(temp));
  } catch {
    previewLatex = `${transform.token}\\left(${cluster.latex}\\right)`;
  }
  return {
    patch: {
      kind: `discover-transform-${transform.id}`,
      addedNodes: [node],
      addedEdges: [edge],
      removedEdgeIds: [],
      draggedId: cluster.node.id,
      focusId: node.id,
    },
    previewLatex,
  };
}

export function discover(graph: AuraGraph, options: DiscoveryOptions): DiscoveryResult {
  const scale = clampScale(options.scale);
  const families: Family[] = options.families?.length
    ? options.families
    : ["relation", "arithmetic", "comparison", "set", "speculative", "transform"];
  const index = indexGraph(graph);
  const focus = new Set(
    (options.focusIds ?? [])
      .map((id) => componentRoot(index, id)?.id ?? id)
      .filter((id): id is string => Boolean(id)),
  );
  const allClusters = buildClusters(graph);
  const clusters = focus.size > 0 ? allClusters.filter((cluster) => focus.has(cluster.node.id)) : allClusters;
  const bounds = graphBounds(graph);
  const diagonal = Math.max(
    320,
    Math.hypot(bounds.maxX - bounds.minX, bounds.maxY - bounds.minY),
  );
  const radius = diagonal * (0.18 + 0.82 * scale);
  const limit = options.limit ?? Math.round(8 + scale * 20);
  const proposals: Proposal[] = [];
  let considered = 0;

  const typeAdmitted = (cluster: Cluster): boolean =>
    admits(OPERAND_TYPES, cluster.type).ok || cluster.isSet;

  clusterLoop: for (let leftIndex = 0; leftIndex < clusters.length; leftIndex += 1) {
    for (let rightIndex = 0; rightIndex < clusters.length; rightIndex += 1) {
      if (leftIndex === rightIndex) continue;
      const left = clusters[leftIndex];
      const right = clusters[rightIndex];
      if (normalise(left.latex) === normalise(right.latex)) continue;
      if (left.node.collapsed || right.node.collapsed) continue;

      const distance = Math.hypot(left.node.x - right.node.x, left.node.y - right.node.y);
      if (distance > radius) continue;

      const structural = 1 - Math.min(1, distance / radius);
      for (const template of TEMPLATES) {
        if (!families.includes(template.family)) continue;
        if (template.family === "transform") continue;
        if (scale < template.scaleMin) continue;
        if (template.id === "equal" && leftIndex > rightIndex && template.commutative) continue;
        if (!typeAdmitted(left) || !typeAdmitted(right)) continue;
        if (template.requireSetRight && !right.isSet) continue;
        if (template.id !== "in" && (left.isSet || right.isSet)) continue;
        if (template.id === "leq" && left.vars.length === 0 && right.vars.length === 0) continue;
        considered += 1;

        const verification = verifyPair(index, left, right, template.check);
        const novelty = 1 - similarity(left.latex, right.latex);
        const weight = verification.verdict === "holds" ? 1 : verification.verdict === "unknown" ? 0.45 : 0.12;
        const canonical =
          template.id === "equal"
            ? 0.07
            : template.id === "approx"
              ? 0.04
              : template.id === "leq"
                ? -0.09
                : template.id === "in"
                  ? 0.06
                  : 0;
        const constantOrder = template.check === "order" && left.vars.length === 0 && right.vars.length === 0 ? -0.09 : 0;
        const inert = verification.verdict === "unknown" && left.value === null && right.value === null ? -0.06 : 0;
        const score =
          0.38 * weight +
          0.22 * verification.confidence +
          0.17 * novelty +
          0.13 * structural +
          0.1 * (1 - template.scaleMin) +
          canonical +
          constantOrder +
          inert;
        if (verification.verdict === "refuted" && scale < 0.45) continue;

        const hint = recognisedLaw(left.latex, right.latex, template.token);
        let verdict = verification.verdict;
        let evidence = verification.evidence;
        let confidence = verification.confidence;
        if (template.id === "in") {
          const realValued =
            right.node.token === "\\mathbb{R}" &&
            ["Scalar", "Variable", "Expression", "Function"].includes(left.type);
          if (realValued) {
            verdict = "holds";
            confidence = 0.9;
            evidence = `type-level: ${left.type} is ℝ-valued by default, so membership is admissible`;
          } else {
            verdict = "unknown";
            confidence = 0.5;
            evidence = `type-level membership claim — ${left.type} against ${right.latex}`;
          }
        }
        if (hint && verdict === "refuted") {
          verdict = "unknown";
          evidence = `recognised law — random sampling cannot decide it (${verification.evidence})`;
        }
        const { patch, previewLatex } = buildPatch(graph, left, right, template, scale, hint);
        proposals.push({
          id: `${template.id}-${left.node.id}-${right.node.id}`,
          kind: template.id,
          family: template.family,
          title: `${left.latex} ${template.token} ${right.latex}`,
          rationale:
            template.family === "relation"
              ? `Both clusters admit expression operands (${left.type}, ${right.type}); a ${template.label.toLowerCase()} vertex is structure-preserving.`
              : template.family === "set"
                ? `Right cluster infers ${right.type}, so a membership edge is admissible.`
                : `A ${template.label.toLowerCase()} binder preserves the arity and type contracts of both clusters.`,
          hint,
          leftLatex: left.latex,
          rightLatex: right.latex,
          previewLatex,
          score: Math.min(0.99, score + (hint ? 0.14 : 0)),
          novelty,
          verdict,
          confidence,
          evidence,
          counterexample: verification.counterexample,
          samples: verification.samples,
          clusterIds: [left.node.id, right.node.id],
          patch,
          color: COLORS[proposals.length % COLORS.length],
        });
      }

      if (families.includes("transform") && scale >= 0.25) {
        const candidate = left;
        if (typeAdmitted(candidate) && candidate.vars.length <= 3) {
          for (const transform of TRANSFORMS) {
            considered += 1;
            const { patch, previewLatex } = buildTransformPatch(graph, candidate, transform, scale);
            proposals.push({
              id: `${transform.id}-${candidate.node.id}`,
              kind: transform.id,
              family: "transform",
              title: `${transform.label} of ${candidate.latex}`,
              rationale: `Wrapping ${candidate.latex} in ${transform.label.toLowerCase()} creates a new evaluable object without rebinding anything.`,
              hint: null,
              leftLatex: candidate.latex,
              rightLatex: "",
              previewLatex,
              score: Math.min(0.9, 0.3 + 0.2 * structural + 0.18 * (1 - similarity(candidate.latex, previewLatex)) + 0.1 * scale),
              novelty: 1 - similarity(candidate.latex, previewLatex),
              verdict: "unknown",
              confidence: 0.45,
              evidence: "transform — evaluated numerically, no truth value to refute",
              counterexample: null,
              samples: 0,
              clusterIds: [candidate.node.id],
              patch,
              color: COLORS[proposals.length % COLORS.length],
            });
          }
        }
      }
      if (proposals.length > 900) break clusterLoop;
    }
  }

  // Rank, keep diversity (max 2 per cluster pair), prefer verdicts that hold.
  const ranked = proposals.sort((a, b) => {
    const verdictRank = (verdict: Verdict) => (verdict === "holds" ? 2 : verdict === "unknown" ? 1 : 0);
    if (verdictRank(a.verdict) !== verdictRank(b.verdict)) {
      return verdictRank(b.verdict) - verdictRank(a.verdict);
    }
    return b.score - a.score;
  });

  const perPair = new Map<string, number>();
  const perTemplate = new Set<string>();
  const templateCounts = new Map<string, number>();
  const templateCaps: Record<string, number> = {
    in: 2,
    equal: 7,
    approx: 3,
    leq: 4,
    mapsto: 3,
    add: 4,
    mul: 4,
    sub: 3,
    juxta: 3,
    power: 3,
    frac: 3,
    sin: 2,
    cos: 2,
    ln: 2,
    sqrt: 2,
    abs: 2,
    exp: 2,
    det: 2,
  };
  const chosen: Proposal[] = [];
  const familyPriority = (family: Family): number =>
    family === "relation"
      ? 5
      : family === "set"
        ? 4
        : family === "arithmetic"
          ? 3
          : family === "comparison"
            ? 2
            : family === "speculative"
              ? 1
              : 0;
  const ordered = [...ranked].sort((a, b) => {
    const verdictRank = (verdict: Verdict) => (verdict === "holds" ? 2 : verdict === "unknown" ? 1 : 0);
    if (verdictRank(a.verdict) !== verdictRank(b.verdict)) return verdictRank(b.verdict) - verdictRank(a.verdict);
    if (familyPriority(a.family) !== familyPriority(b.family)) {
      return familyPriority(b.family) - familyPriority(a.family);
    }
    if (Boolean(a.hint) !== Boolean(b.hint)) return a.hint ? -1 : 1;
    return b.score - a.score;
  });
  for (const proposal of ordered) {
    const pairKey = [...proposal.clusterIds].sort().join("|");
    const templateKey = `${pairKey}|${proposal.kind}`;
    if (perTemplate.has(templateKey)) continue;
    const used = perPair.get(pairKey) ?? 0;
    if (used >= 2) continue;
    const kindUsed = templateCounts.get(proposal.kind) ?? 0;
    if (kindUsed >= (templateCaps[proposal.kind] ?? 4)) continue;
    templateCounts.set(proposal.kind, kindUsed + 1);
    perTemplate.add(templateKey);
    perPair.set(pairKey, used + 1);
    chosen.push(proposal);
    if (chosen.length >= limit) break;
  }

  const noiseCap = Math.round(3 + scale * 9);
  let noise = 0;
  const balanced = chosen.filter((proposal) => {
    if (proposal.verdict !== "unknown" || proposal.hint) return true;
    noise += 1;
    return noise <= noiseCap;
  });

  return {
    proposals: balanced,
    clusters: clusters.length,
    considered,
    holds: balanced.filter((proposal) => proposal.verdict === "holds").length,
    refuted: balanced.filter((proposal) => proposal.verdict === "refuted").length,
    scale,
    families,
  };
}

/** Apply a batch of proposals as one reversible graph transaction. */
export function applyProposals(
  graph: AuraGraph,
  candidates: ConnectionPatch[],
): { graph: AuraGraph; applied: number; skipped: number } {
  let working = graph;
  let applied = 0;
  let skipped = 0;

  for (const candidate of candidates) {
    const ids = new Set(working.nodes.map((node) => node.id));
    const targetNodes = new Map(working.nodes.map((node) => [node.id, node]));
    const parented = new Set(
      working.edges
        .map((edge) => targetNodes.get(edge.target))
        .filter((node): node is NonNullable<typeof node> => Boolean(node) && !isShareable(node!))
        .map((node) => node.id),
    );
    const addable = candidate.addedNodes.every((node) => !ids.has(node.id));
    const validEdges = candidate.addedEdges.every(
      (edge) =>
        ids.has(edge.source) || candidate.addedNodes.some((node) => node.id === edge.source),
    );
    const targetsFree = candidate.addedEdges.every(
      (edge) =>
        ids.has(edge.target) &&
        !parented.has(edge.target) &&
        !candidate.addedEdges.some(
          (other) => other !== edge && other.target === edge.target,
        ),
    );
    if (!addable || !validEdges || !targetsFree) {
      skipped += 1;
      continue;
    }
    try {
      working = commitCandidate(working, candidate);
      applied += 1;
    } catch {
      skipped += 1;
    }
  }

  return { graph: working, applied, skipped };
}

export function proposalToLatex(proposal: Proposal): string {
  return proposal.previewLatex;
}

export function clusterAnalyses(graph: AuraGraph): { id: string; latex: string; type: MathType; vars: string[] }[] {
  const index = indexGraph(graph);
  return buildClusters(graph).map((cluster) => ({
    id: cluster.node.id,
    latex: cluster.latex,
    type: cluster.type,
    vars: cluster.vars,
  }));
}

export function clusterValue(graph: AuraGraph, rootId: string): number | null {
  const index = indexGraph(graph);
  const child = childOf(index, rootId, "left");
  void child;
  return evalExpression(index, rootId, {});
}
