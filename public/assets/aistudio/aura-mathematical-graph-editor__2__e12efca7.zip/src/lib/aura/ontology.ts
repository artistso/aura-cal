/**
 * Aura's mathematical ontology: the type lattice, port vocabulary and the
 * element catalogue used by the palette, the connection engine and the
 * recognition pipeline.
 */

export type MathType =
  | "Scalar"
  | "Variable"
  | "Vector"
  | "Matrix"
  | "Set"
  | "Expression"
  | "Relation"
  | "Function"
  | "Operator"
  | "Unknown";

export type NodeKind =
  | "literal"
  | "variable"
  | "operator"
  | "relation"
  | "function"
  | "container"
  | "set"
  | "group";

export type PortId =
  | "left"
  | "right"
  | "base"
  | "exponent"
  | "subscript"
  | "numerator"
  | "denominator"
  | "lower"
  | "upper"
  | "body"
  | "arg";

export type PortSide =
  | "left"
  | "right"
  | "top"
  | "bottom"
  | "topright"
  | "bottomright"
  | "righttop"
  | "rightbottom";

export interface AuraNode {
  id: string;
  kind: NodeKind;
  type: MathType;
  token: string;
  label: string;
  variant: string | null;
  x: number;
  y: number;
  collapsed: boolean;
  meta: Record<string, unknown> | null;
}

export interface AuraEdge {
  id: string;
  source: string;
  target: string;
  port: PortId;
  role: string;
}

export interface AuraGraph {
  nodes: AuraNode[];
  edges: AuraEdge[];
}

export interface PortDef {
  id: PortId;
  label: string;
  accepts: MathType[];
  required: boolean;
  hint: string;
  side: PortSide;
}

export interface Diagnostic {
  nodeId: string;
  edgeId?: string | null;
  severity: "error" | "warning" | "info";
  message: string;
}

export interface GhostPath {
  color: string;
  title: string;
  rationale: string;
  score: number;
  kind: string;
  draggedId: string;
  targetId: string;
  targetPort: PortId;
  anchor: { x: number; y: number };
  previewLatex: string;
  addedNodes: AuraNode[];
  addedEdges: AuraEdge[];
  removedEdgeIds: string[];
  focusId: string;
}

/** Derived types that may legally sit in an operand slot. */
export const OPERAND_TYPES: MathType[] = [
  "Scalar",
  "Variable",
  "Vector",
  "Matrix",
  "Expression",
];

export const EXPRESSIONISH: MathType[] = [
  "Scalar",
  "Variable",
  "Vector",
  "Matrix",
  "Expression",
  "Function",
  "Set",
];

export const GHOST_COLORS = ["#f0b45a", "#5eead4", "#f472b6", "#a78bfa"] as const;

/** Unary postfix operators: rendered to the right of their operand. */
export const POSTFIX_VARIANTS = new Set([
  "fact",
  "transpose",
  "inverse",
  "conj",
  "prime",
  "doubleprime",
  "degree",
  "complement",
]);

/** Prefix unary operators: rendered to the left of their operand. */
export const PREFIX_VARIANTS = new Set(["neg", "forall", "exists", "nabla", "partial"]);

/** Accents / decorations that wrap a single body. */
export const ACCENT_VARIANTS = new Set([
  "hat",
  "bar",
  "vec",
  "dot",
  "ddot",
  "tilde",
  "overline",
  "underline",
  "check",
  "widehat",
  "widetilde",
]);

/** Big operators with optional limits and a body. */
export const BIG_VARIANTS = new Set([
  "sum",
  "prod",
  "coprod",
  "int",
  "iint",
  "iiint",
  "oint",
  "lim",
  "limsup",
  "liminf",
  "sup",
  "inf",
  "max",
  "min",
  "bigcup",
  "bigcap",
  "bigoplus",
  "bigotimes",
  "det",
  "gcd",
  "argmin",
  "argmax",
  "span",
]);

/** Matrix-like containers: a single entries slot. */
export const MATRIX_VARIANTS = new Set(["matrix", "bmatrix", "vmatrix", "cases"]);

/** Enclosure containers: |x|, ||x||, floor, ceil. */
export const ENCLOSURE_VARIANTS = new Set(["abs", "norm", "floor", "ceil"]);

export function newId(): string {
  const cryptoObj = globalThis.crypto as Crypto | undefined;
  if (cryptoObj && typeof cryptoObj.randomUUID === "function") {
    return cryptoObj.randomUUID();
  }
  // Postgres stores vertex ids as uuid, so the fallback must still be a UUID.
  const bytes = new Uint8Array(16);
  if (cryptoObj && typeof cryptoObj.getRandomValues === "function") {
    cryptoObj.getRandomValues(bytes);
  } else {
    for (let index = 0; index < bytes.length; index += 1) {
      bytes[index] = Math.floor(Math.random() * 256);
    }
  }
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

export function makeNode(
  input: Pick<AuraNode, "kind" | "token" | "label"> & Partial<AuraNode>,
): AuraNode {
  return {
    id: input.id ?? newId(),
    kind: input.kind,
    type: input.type ?? "Expression",
    token: input.token,
    label: input.label,
    variant: input.variant ?? null,
    x: input.x ?? 0,
    y: input.y ?? 0,
    collapsed: input.collapsed ?? false,
    meta: input.meta ?? null,
  };
}

export function port(
  id: PortId,
  label: string,
  accepts: MathType[],
  required: boolean,
  hint: string,
  side: PortSide,
): PortDef {
  return { id, label, accepts, required, hint, side };
}

/** Every vertex advertises its ports; the connection engine only binds into these. */
export function portsFor(node: AuraNode): PortDef[] {
  const exponent = port(
    "exponent",
    "Exponent",
    ["Scalar", "Variable", "Expression"],
    false,
    "Raise this element to a power",
    "topright",
  );
  const subscript = port(
    "subscript",
    "Subscript",
    ["Scalar", "Variable"],
    false,
    "Attach an index",
    "bottomright",
  );

  switch (node.kind) {
    case "operator":
      if (node.variant && ["abs", "norm", "floor", "ceil"].includes(node.variant)) {
        return [port("arg", "Operand", OPERAND_TYPES, true, `Expression inside ${node.variant}`, "right")];
      }
      if (node.variant && POSTFIX_VARIANTS.has(node.variant)) {
        return [
          port("arg", "Operand", OPERAND_TYPES, true, `Apply ${node.variant} to this expression`, "left"),
        ];
      }
      if (node.variant && PREFIX_VARIANTS.has(node.variant)) {
        return [
          port("arg", "Operand", OPERAND_TYPES, true, `Scope of ${node.variant}`, "right"),
        ];
      }
      if (node.variant === "binom") {
        return [
          port("numerator", "Upper index", OPERAND_TYPES, true, "Choose from", "topright"),
          port("denominator", "Lower index", OPERAND_TYPES, true, "Choose this many", "bottomright"),
        ];
      }
      if (node.variant === "power") {
        return [
          port("base", "Base", OPERAND_TYPES, true, "Value being exponentiated", "left"),
          port("exponent", "Exponent", OPERAND_TYPES, true, "Power to raise to", "right"),
        ];
      }
      if (node.variant === "frac") {
        return [
          port("numerator", "Numerator", OPERAND_TYPES, true, "Top of the fraction", "topright"),
          port(
            "denominator",
            "Denominator",
            OPERAND_TYPES,
            true,
            "Bottom of the fraction",
            "bottomright",
          ),
        ];
      }
      return [
        port("left", "Left operand", OPERAND_TYPES, true, "First operand", "left"),
        port("right", "Right operand", OPERAND_TYPES, true, "Second operand", "right"),
      ];
    case "relation":
      if (
        node.variant &&
        ["in", "notin", "subset", "supset", "subseteq", "supseteq"].includes(node.variant)
      ) {
        return [
          port("left", "Element", OPERAND_TYPES, true, "Member expression", "left"),
          port("right", "Set", ["Set"], true, "Set it belongs to", "right"),
        ];
      }
      return [
        port("left", "Left side", OPERAND_TYPES, true, "Left expression", "left"),
        port("right", "Right side", OPERAND_TYPES, true, "Right expression", "right"),
      ];
    case "function":
      return [
        port("arg", "Argument", OPERAND_TYPES, true, "Value the function acts on", "right"),
      ];
    case "container":
      if (node.variant && ACCENT_VARIANTS.has(node.variant)) {
        return [port("body", "Accented body", OPERAND_TYPES, true, "Expression under the accent", "right")];
      }
      if (node.variant && MATRIX_VARIANTS.has(node.variant)) {
        return [
          port("body", "Entries", OPERAND_TYPES, true, "Rows and columns of the array", "right"),
        ];
      }
      if (node.variant && ENCLOSURE_VARIANTS.has(node.variant)) {
        return [port("body", "Body", OPERAND_TYPES, true, "Expression inside the enclosure", "right")];
      }
      if (node.variant === "sqrt") {
        return [port("body", "Radicand", OPERAND_TYPES, true, "Expression under the radical", "right")];
      }
      if (node.variant === "root") {
        return [
          port("upper", "Index", ["Scalar", "Variable"], false, "Root index", "topright"),
          port("body", "Radicand", OPERAND_TYPES, true, "Expression under the radical", "right"),
        ];
      }
      if (node.variant && BIG_VARIANTS.has(node.variant)) {
        return [
          port("lower", "Lower limit", ["Scalar", "Variable"], false, "Lower bound", "bottomright"),
          port("upper", "Upper limit", ["Scalar", "Variable"], false, "Upper bound", "topright"),
          port("body", "Body", OPERAND_TYPES, true, "Integrand / summand", "right"),
        ];
      }
      return [port("body", "Body", OPERAND_TYPES, true, "Contained expression", "right")];
    case "set":
      return [];
    case "group":
      return [exponent];
    default:
      return [exponent, subscript];
  }
}

export function findPort(node: AuraNode, portId: PortId): PortDef | undefined {
  return portsFor(node).find((entry) => entry.id === portId);
}

/** Type admissibility, with the atom-is-an-expression widening rule. */
export function admits(accepts: MathType[], type: MathType): { ok: boolean; exact: boolean } {
  if (accepts.includes(type)) return { ok: true, exact: true };
  if (type === "Unknown") return { ok: false, exact: false };
  if (accepts.includes("Expression") && OPERAND_TYPES.includes(type)) {
    return { ok: true, exact: false };
  }
  if (accepts.includes("Variable") && type === "Scalar") return { ok: true, exact: false };
  if (accepts.includes("Scalar") && (type === "Variable" || type === "Expression")) {
    return { ok: true, exact: false };
  }
  return { ok: false, exact: false };
}

export function portAdmits(port: PortDef, type: MathType): { ok: boolean; exact: boolean } {
  return admits(port.accepts, type);
}

/**
 * Leaf vertices are *references*: the same variable may appear in several
 * operators (θ in sin²θ and cos²θ). Composite vertices are tree nodes and may
 * only occupy one port.
 */
export const SHAREABLE_KINDS: NodeKind[] = ["literal", "variable", "set"];

export function isShareable(node: AuraNode): boolean {
  return SHAREABLE_KINDS.includes(node.kind);
}

/** Atom-sized elements can be lifted into a relation / product by the engine. */
export function isOperandLike(node: AuraNode, type: MathType): boolean {
  if (node.kind === "relation" || node.kind === "operator") return false;
  return EXPRESSIONISH.includes(type);
}

const TILE_HEIGHT = 52;
const TILE_MIN = 46;

export function estimateWidth(node: AuraNode): number {
  const token = node.token ?? "";
  switch (node.kind) {
    case "operator":
      if (node.variant === "power") return 20;
      if (node.variant === "frac") return 44;
      if (node.variant === "binom") return 48;
      if (node.variant && (POSTFIX_VARIANTS.has(node.variant) || PREFIX_VARIANTS.has(node.variant))) {
        return 40;
      }
      return 46;
    case "relation":
      return token.length > 3 ? 58 : 52;
    case "function":
      return Math.max(64, 24 + token.replace(/\\/g, "").length * 13);
    case "container":
      if (node.variant && MATRIX_VARIANTS.has(node.variant)) return 66;
      if (node.variant && (ACCENT_VARIANTS.has(node.variant) || node.variant === "sqrt")) return 56;
      if (node.variant === "frac") return 44;
      return 54;
    case "set":
      return 54;
    case "group": {
      const inner = typeof node.meta?.latex === "string" ? node.meta.latex : token;
      return Math.min(190, Math.max(64, 30 + inner.length * 9));
    }
    default:
      return Math.max(TILE_MIN, 22 + token.length * 11);
  }
}

export function tileHeight(): number {
  return TILE_HEIGHT;
}

export interface CatalogItem {
  id: string;
  kind: NodeKind;
  token: string;
  label: string;
  type: MathType;
  variant?: string;
  group: string;
  hint: string;
}

export const CATALOG: CatalogItem[] = [
  { id: "two", kind: "literal", token: "2", label: "Literal 2", type: "Scalar", group: "Literals", hint: "Scalar literal" },
  { id: "zero", kind: "literal", token: "0", label: "Literal 0", type: "Scalar", group: "Literals", hint: "Scalar literal" },
  { id: "pi", kind: "literal", token: "\\pi", label: "π", type: "Scalar", group: "Literals", hint: "Transcendental constant" },
  { id: "half", kind: "literal", token: "\\tfrac{1}{2}", label: "One half", type: "Scalar", group: "Literals", hint: "Rational literal" },
  { id: "x", kind: "variable", token: "x", label: "x", type: "Variable", group: "Variables", hint: "Free variable" },
  { id: "y", kind: "variable", token: "y", label: "y", type: "Variable", group: "Variables", hint: "Free variable" },
  { id: "E", kind: "variable", token: "E", label: "Energy E", type: "Variable", group: "Variables", hint: "Physical quantity" },
  { id: "m", kind: "variable", token: "m", label: "Mass m", type: "Variable", group: "Variables", hint: "Physical quantity" },
  { id: "c", kind: "variable", token: "c", label: "Speed c", type: "Variable", group: "Variables", hint: "Physical quantity" },
  { id: "theta", kind: "variable", token: "\\theta", label: "θ", type: "Variable", group: "Variables", hint: "Angle" },
  { id: "matrixA", kind: "variable", token: "A", label: "Matrix A", type: "Matrix", group: "Variables", hint: "Matrix-valued symbol" },
  { id: "vectorv", kind: "variable", token: "\\vec{v}", label: "Vector v", type: "Vector", group: "Variables", hint: "Vector-valued symbol" },
  { id: "add", kind: "operator", token: "+", label: "Addition", type: "Operator", variant: "add", group: "Operators", hint: "Binary, arity 2" },
  { id: "sub", kind: "operator", token: "-", label: "Subtraction", type: "Operator", variant: "sub", group: "Operators", hint: "Binary, arity 2" },
  { id: "mul", kind: "operator", token: "\\times", label: "Multiplication", type: "Operator", variant: "mul", group: "Operators", hint: "Binary, arity 2" },
  { id: "frac", kind: "operator", token: "\\frac{\\phantom{a}}{\\phantom{a}}", label: "Fraction", type: "Operator", variant: "frac", group: "Operators", hint: "Numerator / denominator" },
  { id: "power", kind: "operator", token: "^", label: "Power", type: "Operator", variant: "power", group: "Operators", hint: "Base ^ exponent" },
  { id: "equal", kind: "relation", token: "=", label: "Equality", type: "Relation", variant: "equal", group: "Relations", hint: "Expression = Expression" },
  { id: "approx", kind: "relation", token: "\\approx", label: "Approximation", type: "Relation", variant: "approx", group: "Relations", hint: "Approximate equality" },
  { id: "mapsto", kind: "relation", token: "\\to", label: "Mapping", type: "Relation", variant: "mapsto", group: "Relations", hint: "Transformation arrow" },
  { id: "leq", kind: "relation", token: "\\le", label: "Order", type: "Relation", variant: "leq", group: "Relations", hint: "Inequality" },
  { id: "in", kind: "relation", token: "\\in", label: "Membership", type: "Relation", variant: "in", group: "Relations", hint: "Element ∈ Set" },
  { id: "sin", kind: "function", token: "\\sin", label: "sin", type: "Function", variant: "sin", group: "Functions", hint: "Unary function" },
  { id: "cos", kind: "function", token: "\\cos", label: "cos", type: "Function", variant: "cos", group: "Functions", hint: "Unary function" },
  { id: "ln", kind: "function", token: "\\ln", label: "ln", type: "Function", variant: "ln", group: "Functions", hint: "Unary function" },
  { id: "f", kind: "function", token: "f", label: "f", type: "Function", variant: "f", group: "Functions", hint: "Arbitrary function" },
  { id: "sqrt", kind: "container", token: "\\sqrt{\\phantom{x}}", label: "Square root", type: "Expression", variant: "sqrt", group: "Containers", hint: "Radical with one slot" },
  { id: "int", kind: "container", token: "\\int", label: "Integral", type: "Expression", variant: "int", group: "Containers", hint: "Integrand, lower, upper" },
  { id: "sum", kind: "container", token: "\\sum", label: "Summation", type: "Expression", variant: "sum", group: "Containers", hint: "Summand, lower, upper" },
  { id: "reals", kind: "set", token: "\\mathbb{R}", label: "ℝ", type: "Set", group: "Sets", hint: "The reals" },
  { id: "ints", kind: "set", token: "\\mathbb{Z}", label: "ℤ", type: "Set", group: "Sets", hint: "The integers" },
  { id: "complex", kind: "set", token: "\\mathbb{C}", label: "ℂ", type: "Set", group: "Sets", hint: "The complex plane" },
];

export const CATALOG_GROUPS = Array.from(new Set(CATALOG.map((item) => item.group)));

export function catalogNode(itemId: string, position: { x: number; y: number }): AuraNode | null {
  const item = CATALOG.find((entry) => entry.id === itemId);
  if (!item) return null;
  return makeNode({
    kind: item.kind,
    token: item.token,
    label: item.label,
    type: item.type,
    variant: item.variant ?? null,
    x: position.x,
    y: position.y,
  });
}

export function nodeDisplayKind(node: AuraNode): string {
  switch (node.kind) {
    case "literal":
      return "Literal";
    case "variable":
      return "Variable";
    case "operator":
      return "Operator";
    case "relation":
      return "Relation";
    case "function":
      return "Function";
    case "container":
      return "Container";
    case "set":
      return "Set";
    default:
      return "Collapsed expression";
  }
}

/** Minimum arity for the inspector. */
export function arityOf(node: AuraNode): number {
  return portsFor(node).filter((entry) => entry.required).length;
}
