/**
 * Tier 1 stroke recognition. In the tablet build this is an on-device HMER
 * model; in the browser prototype it is a local geometric classifier with
 * calibrated confidence. Anything below the confidence floor is escalated to
 * Tier 2 (structural LaTeX recovery), never silently committed.
 */

import type { MathType, NodeKind } from "./ontology";

export interface Stroke {
  points: { x: number; y: number }[];
}

export interface InkPrediction {
  symbol: string;
  latex: string;
  label: string;
  kind: NodeKind;
  type: MathType;
  variant?: string | null;
  confidence: number;
  rationale: string;
}

interface StrokeFeature {
  angle: number;
  straightness: number;
  length: number;
  closed: boolean;
  width: number;
  height: number;
  cx: number;
  cy: number;
}

const SYMBOL_SPECS: Record<string, Omit<InkPrediction, "confidence" | "rationale">> = {
  "=": { symbol: "=", latex: "=", label: "Equality", kind: "relation", type: "Relation", variant: "equal" },
  "-": { symbol: "−", latex: "-", label: "Subtraction", kind: "operator", type: "Operator", variant: "sub" },
  "+": { symbol: "+", latex: "+", label: "Addition", kind: "operator", type: "Operator", variant: "add" },
  x: { symbol: "x", latex: "x", label: "Variable x", kind: "variable", type: "Variable", variant: null },
  y: { symbol: "y", latex: "y", label: "Variable y", kind: "variable", type: "Variable", variant: null },
  "1": { symbol: "1", latex: "1", label: "Literal 1", kind: "literal", type: "Scalar", variant: null },
  "2": { symbol: "2", latex: "2", label: "Literal 2", kind: "literal", type: "Scalar", variant: null },
  "0": { symbol: "0", latex: "0", label: "Literal 0", kind: "literal", type: "Scalar", variant: null },
  sqrt: { symbol: "√", latex: "\\sqrt{\\phantom{x}}", label: "Square root", kind: "container", type: "Expression", variant: "sqrt" },
  int: { symbol: "∫", latex: "\\int", label: "Integral", kind: "container", type: "Expression", variant: "int" },
  theta: { symbol: "θ", latex: "\\theta", label: "Angle θ", kind: "variable", type: "Variable", variant: null },
  pi: { symbol: "π", latex: "\\pi", label: "π", kind: "literal", type: "Scalar", variant: null },
};

function predict(symbol: string, confidence: number, rationale: string): InkPrediction {
  const spec = SYMBOL_SPECS[symbol] ?? SYMBOL_SPECS.x;
  return { ...spec, confidence: Math.max(0.05, Math.min(0.98, confidence)), rationale };
}

function feature(stroke: Stroke): StrokeFeature {
  const points = stroke.points.filter(
    (point) => Number.isFinite(point.x) && Number.isFinite(point.y),
  );
  if (points.length === 0) {
    return { angle: 0, straightness: 0, length: 0, closed: false, width: 0, height: 0, cx: 0, cy: 0 };
  }
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  let length = 0;
  for (let i = 0; i < points.length; i += 1) {
    const point = points[i];
    minX = Math.min(minX, point.x);
    minY = Math.min(minY, point.y);
    maxX = Math.max(maxX, point.x);
    maxY = Math.max(maxY, point.y);
    if (i > 0) length += Math.hypot(point.x - points[i - 1].x, point.y - points[i - 1].y);
  }
  const first = points[0];
  const last = points[points.length - 1];
  const chord = Math.hypot(last.x - first.x, last.y - first.y);
  const width = maxX - minX;
  const height = maxY - minY;
  return {
    angle: (Math.atan2(last.y - first.y, last.x - first.x) * 180) / Math.PI,
    straightness: length > 0 ? chord / length : 0,
    length,
    closed: chord < Math.max(width, height) * 0.42 && Math.hypot(width, height) > 24,
    width,
    height,
    cx: (minX + maxX) / 2,
    cy: (minY + maxY) / 2,
  };
}

function nearlyHorizontal(angle: number): boolean {
  const normalized = Math.abs(((angle + 180) % 180 + 180) % 180);
  return normalized < 24 || normalized > 156;
}

function nearlyVertical(angle: number): boolean {
  const normalized = Math.abs(((angle + 180) % 180 + 180) % 180);
  return Math.abs(normalized - 90) < 28;
}

export function classifyInk(strokes: Stroke[]): InkPrediction[] {
  const valid = strokes.filter((stroke) => stroke.points.length > 1);
  if (valid.length === 0) return [];
  const features = valid.map(feature);
  const straight = features.filter((entry) => entry.straightness > 0.82);
  const horizontal = straight.filter((entry) => nearlyHorizontal(entry.angle));
  const vertical = straight.filter((entry) => nearlyVertical(entry.angle));

  if (valid.length >= 2 && horizontal.length >= 2) {
    const ys = horizontal.map((entry) => entry.cy).sort((a, b) => a - b);
    if (Math.abs(ys[ys.length - 1] - ys[0]) > 6) {
      return [
        predict("=", 0.92, "Two parallel horizontal strokes with vertical separation."),
        predict("-", 0.32, "A single horizontal stroke would also be admissible."),
        predict("2", 0.14, "No curved stroke found for a numeral."),
      ];
    }
  }

  if (valid.length === 2 && straight.length === 2) {
    const [first, second] = straight;
    const crossing =
      Math.hypot(first.cx - second.cx, first.cy - second.cy) <
      Math.max(first.width, first.height, second.width, second.height) * 0.55;
    if (crossing && ((nearlyHorizontal(first.angle) && nearlyVertical(second.angle)) || (nearlyVertical(first.angle) && nearlyHorizontal(second.angle)))) {
      return [
        predict("+", 0.88, "Horizontal and vertical strokes intersect near their midpoints."),
        predict("x", 0.24, "Two intersecting strokes could also be a product sign."),
        predict("=", 0.11, "Parallel strokes were not detected."),
      ];
    }
    if (crossing) {
      return [
        predict("x", 0.74, "Two diagonal strokes cross in the centre."),
        predict("+", 0.4, "The stroke angles are unusual for a plus sign."),
        predict("1", 0.12, "Neither stroke is vertical enough."),
      ];
    }
    if (nearlyVertical(features[0].angle) && nearlyVertical(features[1].angle)) {
      return [
        predict("1", 0.52, "Two vertical strokes — likely two separate numerals."),
        predict("=", 0.2, "Horizontal parallelism not found."),
        predict("x", 0.16, "No diagonal crossing."),
      ];
    }
  }

  const main = features[0];
  if (main.closed && main.height > 18 && main.width > 12) {
    return [
      predict("0", 0.7, "Closed loop with balanced aspect ratio."),
      predict("theta", 0.32, "A closed loop with a crossing bar would be θ."),
      predict("pi", 0.08, "No horizontal top bar detected."),
    ];
  }
  if (main.straightness > 0.85 && nearlyHorizontal(main.angle)) {
    return [
      predict("-", 0.86, "Single straight horizontal stroke."),
      predict("1", 0.14, "Stroke is horizontal, not vertical."),
      predict("=", 0.1, "Only one horizontal stroke present."),
    ];
  }
  if (main.straightness > 0.85 && nearlyVertical(main.angle)) {
    return [
      predict("1", 0.74, "Single straight vertical stroke."),
      predict("-", 0.15, "Stroke is vertical, not horizontal."),
      predict("y", 0.12, "No descender curve found for y."),
    ];
  }
  if (main.straightness > 0.7) {
    return [
      predict("x", 0.46, "Straight diagonal stroke — x needs a second crossing stroke."),
      predict("1", 0.3, "Could be a slanted numeral."),
      predict("+", 0.18, "No intersecting stroke found."),
    ];
  }
  if (main.height > main.width * 1.5) {
    return [
      predict("int", 0.58, "Tall open curve — integral sign or a cursive numeral."),
      predict("1", 0.22, "Too curved to be a straight numeral."),
      predict("y", 0.18, "Possible descender loop."),
    ];
  }
  return [
    predict("2", 0.34, "Curved open stroke — low confidence, escalate to Tier 2."),
    predict("y", 0.28, "Curved stem with a tail is ambiguous."),
    predict("0", 0.2, "Stroke is not closed."),
  ];
}

export const SYMBOL_PALETTE = Object.entries(SYMBOL_SPECS).map(([key, spec]) => ({
  key,
  ...spec,
}));
