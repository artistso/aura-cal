/**
 * Aura kernel verification suite.
 *
 * Executable specifications for the typed hypergraph: every claim the README
 * or the UI makes about types, serialisation, evaluation, discovery and
 * reversibility is asserted here. Runs head-less in CI via `GET /api/kernel`
 * and is surfaced in the workspace under the Verify tab.
 */

import {
  type AuraEdge,
  type AuraNode,
  makeNode,
  newId,
  portsFor,
  portAdmits,
} from "./ontology";
import {
  collapseSelection,
  diagnose,
  documentLatex,
  expandGroup,
  effectiveType,
  graphBounds,
  indexGraph,
  layoutComponent,
  reflowGraph,
  rootsOf as rootNodes,
  toLatex,
  validateGraph,
} from "./engine";
import { analyzeGraph, evalExpression, foldConstants, scopeIndex } from "./evaluate";
import { discover, applyProposals, scaleBand, type ConnectionPatch } from "./discover";
import { parseLatex } from "./parse";
import { LIBRARY_COUNT, SYMBOL_LIBRARY } from "./library";

export interface TestCase {
  suite: string;
  name: string;
  run: () => void;
}

export interface TestOutcome {
  suite: string;
  name: string;
  ok: boolean;
  error: string | null;
}

export interface SuiteReport {
  generatedAt: string;
  total: number;
  passed: number;
  failed: number;
  durationMs: number;
  suites: { suite: string; passed: number; failed: number }[];
  outcomes: TestOutcome[];
  librarySymbols: number;
}

function assert(condition: unknown, message: string): void {
  if (!condition) throw new Error(message);
}

function equal<T>(actual: T, expected: T, message: string): void {
  if (actual !== expected) {
    throw new Error(`${message} — expected ${JSON.stringify(expected)}, received ${JSON.stringify(actual)}`);
  }
}

/* ------------------------------------------------------------------ */
/* Fixtures                                                            */
/* ------------------------------------------------------------------ */

interface Draft {
  nodes: AuraNode[];
  edges: AuraEdge[];
  node(spec: Parameters<typeof makeNode>[0]): AuraNode;
  bind(source: AuraNode, port: AuraEdge["port"], target: AuraNode): void;
}

function draft(): Draft {
  const nodes: AuraNode[] = [];
  const edges: AuraEdge[] = [];
  return {
    nodes,
    edges,
    node(spec) {
      const node = makeNode(spec);
      nodes.push(node);
      return node;
    },
    bind(source, port, target) {
      edges.push({ id: newId(), source: source.id, target: target.id, port, role: port });
    },
  };
}

const num = (d: Draft, token: string) =>
  d.node({ kind: "literal", token, label: `Literal ${token}`, type: "Scalar" });
const variable = (d: Draft, token: string, type: AuraNode["type"] = "Variable") =>
  d.node({ kind: "variable", token, label: `Variable ${token}`, type });
const operator = (d: Draft, token: string, variant: string) =>
  d.node({ kind: "operator", token, label: variant, type: "Operator", variant });
const latexOf = (nodes: AuraNode[], edges: AuraEdge[], rootId: string) =>
  toLatex({ nodes, edges }, rootId);

/** m c² — the fixture used in the proposal document. */
function massEnergy() {
  const d = draft();
  const m = variable(d, "m");
  const c = variable(d, "c");
  const two = num(d, "2");
  const power = operator(d, "^", "power");
  const product = operator(d, "\\,", "juxta");
  d.bind(power, "base", c);
  d.bind(power, "exponent", two);
  d.bind(product, "left", m);
  d.bind(product, "right", power);
  return { ...d, m, c, two, power, product };
}

/* ------------------------------------------------------------------ */
/* Specifications                                                      */
/* ------------------------------------------------------------------ */

export const TEST_CASES: TestCase[] = [
  {
    suite: "Ontology",
    name: "postfix operators expose a single operand port",
    run: () => {
      const node = makeNode({ kind: "operator", token: "!", label: "Factorial", variant: "fact", type: "Operator" });
      const ports = portsFor(node);
      equal(ports.length, 1, "factorial arity");
      equal(ports[0].id, "arg", "factorial port id");
      assert(ports[0].required, "factorial port must be required");
    },
  },
  {
    suite: "Ontology",
    name: "big operators expose lower, upper and body ports",
    run: () => {
      const node = makeNode({ kind: "container", token: "\\sum", label: "Summation", variant: "sum", type: "Expression" });
      const ids = portsFor(node).map((port) => port.id).sort();
      equal(ids.join(","), "body,lower,upper", "summation ports");
    },
  },
  {
    suite: "Ontology",
    name: "matrices expose exactly one entries port",
    run: () => {
      const node = makeNode({ kind: "container", token: "\\begin{pmatrix}", label: "Matrix", variant: "matrix", type: "Expression" });
      equal(portsFor(node).length, 1, "matrix arity");
      equal(portsFor(node)[0].id, "body", "matrix port");
    },
  },
  {
    suite: "Ontology",
    name: "membership accepts a Set but not a Matrix",
    run: () => {
      const relation = makeNode({ kind: "relation", token: "\\in", label: "Member of", variant: "in", type: "Relation" });
      const right = portsFor(relation).find((port) => port.id === "right");
      if (!right) throw new Error("membership must expose a right port");
      assert(portAdmits(right, "Set").ok, "Set must be admitted");
      assert(!portAdmits(right, "Matrix").ok, "Matrix must be rejected");
    },
  },
  {
    suite: "Types",
    name: "matrix + scalar is diagnosed as ill-typed",
    run: () => {
      const d = draft();
      const matrix = variable(d, "A", "Matrix");
      const two = num(d, "2");
      const plus = operator(d, "+", "add");
      d.bind(plus, "left", matrix);
      d.bind(plus, "right", two);
      const errors = diagnose({ nodes: d.nodes, edges: d.edges }).filter((entry) => entry.severity === "error");
      assert(
        errors.some((entry) => entry.message.includes("Scalar and Matrix")),
        "expected a scalar/matrix conflict diagnostic",
      );
    },
  },
  {
    suite: "Types",
    name: "type propagation lifts a product of variables to Scalar",
    run: () => {
      const d = massEnergy();
      const index = indexGraph({ nodes: d.nodes, edges: d.edges });
      equal(effectiveType(index, d.product.id), "Scalar", "product type");
    },
  },
  {
    suite: "Types",
    name: "a set operand is flagged on arithmetic",
    run: () => {
      const d = draft();
      const reals = d.node({ kind: "set", token: "\\mathbb{R}", label: "Reals", type: "Set" });
      const two = num(d, "2");
      const plus = operator(d, "+", "add");
      d.bind(plus, "left", reals);
      d.bind(plus, "right", two);
      const errors = diagnose({ nodes: d.nodes, edges: d.edges }).filter((entry) => entry.severity === "error");
      assert(errors.length > 0, "set arithmetic must be rejected");
    },
  },
  {
    suite: "Serialisation",
    name: "renders mass–energy as mc²",
    run: () => {
      const d = massEnergy();
      equal(latexOf(d.nodes, d.edges, d.product.id), "m\\,{c}^{2}", "product latex");
    },
  },
  {
    suite: "Serialisation",
    name: "precedence inserts parentheses for (a+b)·c",
    run: () => {
      const d = draft();
      const a = variable(d, "a");
      const b = variable(d, "b");
      const c = variable(d, "c");
      const sum = operator(d, "+", "add");
      const product = operator(d, "\\times", "mul");
      d.bind(sum, "left", a);
      d.bind(sum, "right", b);
      d.bind(product, "left", sum);
      d.bind(product, "right", c);
      const latex = latexOf(d.nodes, d.edges, product.id);
      assert(latex.includes("\\left("), `expected parentheses, received ${latex}`);
    },
  },
  {
    suite: "Serialisation",
    name: "renders binomials, accents and n-th roots",
    run: () => {
      const d = draft();
      const n = variable(d, "n");
      const k = variable(d, "k");
      const binom = operator(d, "\\binom", "binom");
      d.bind(binom, "numerator", n);
      d.bind(binom, "denominator", k);
      equal(latexOf(d.nodes, d.edges, binom.id), "\\binom{n}{k}", "binomial latex");

      const d2 = draft();
      const x = variable(d2, "x");
      const hat = d2.node({ kind: "container", token: "\\hat", label: "Hat", variant: "hat", type: "Expression" });
      d2.bind(hat, "body", x);
      equal(latexOf(d2.nodes, d2.edges, hat.id), "\\hat{x}", "accent latex");

      const d3 = draft();
      const three = num(d3, "3");
      const y = variable(d3, "y");
      const root = d3.node({ kind: "container", token: "\\sqrt", label: "nth root", variant: "root", type: "Expression" });
      d3.bind(root, "upper", three);
      d3.bind(root, "body", y);
      equal(latexOf(d3.nodes, d3.edges, root.id), "\\sqrt[3]{y}", "nth root latex");
    },
  },
  {
    suite: "Serialisation",
    name: "every library token survives a parse → render round trip",
    run: () => {
      const failures: string[] = [];
      for (const entry of SYMBOL_LIBRARY) {
        // Bare relations and operators are not standalone expressions.
        if (!["literal", "variable", "set"].includes(entry.kind)) continue;
        try {
          const parsed = parseLatex(entry.token);
          if (parsed.nodeCount === 0) failures.push(entry.token);
        } catch {
          failures.push(entry.token);
        }
      }
      assert(failures.length === 0, `unparsable leaf tokens: ${failures.slice(0, 6).join(", ")}`);
    },
  },
  {
    suite: "Parser",
    name: "decomposes the quadratic formula into typed vertices",
    run: () => {
      const parsed = parseLatex("\\frac{-b + \\sqrt{b^2 - 4ac}}{2a}");
      assert(parsed.nodeCount >= 12, `expected ≥12 vertices, received ${parsed.nodeCount}`);
      assert(parsed.edgeCount >= 11, `expected ≥11 bindings, received ${parsed.edgeCount}`);
      assert(parsed.normalized.includes("\\frac"), "normalised form must retain the fraction");
    },
  },
  {
    suite: "Parser",
    name: "parses limits, integrals and indexed unions",
    run: () => {
      const sum = parseLatex("\\sum_{n=1}^{10} n^2");
      assert(sum.normalized.includes("\\sum"), "summation head");
      assert(sum.nodeCount >= 7, "summation vertices");
      const integral = parseLatex("\\int_{0}^{1} x^2");
      assert(integral.normalized.includes("\\int_{0}^{1}"), `integral limits, received ${integral.normalized}`);
      const union = parseLatex("\\cup_{i=1}^{n} A_i");
      assert(union.normalized.includes("\\bigcup"), `indexed union, received ${union.normalized}`);
    },
  },
  {
    suite: "Parser",
    name: "rejects malformed input instead of inventing bindings",
    run: () => {
      let threw = false;
      try {
        parseLatex("\\frac{a}{");
      } catch {
        threw = true;
      }
      assert(threw, "unbalanced braces must raise a ParseError");
    },
  },
  {
    suite: "Evaluator",
    name: "evaluates constant arithmetic, powers and fractions",
    run: () => {
      const parsed = parseLatex("\\frac{6 + 2}{4}");
      const index = indexGraph(parsed.graph);
      const value = evalExpression(index, parsed.rootId as string, {});
      equal(value, 2, "fraction value");
    },
  },
  {
    suite: "Evaluator",
    name: "evaluates trigonometric, factorial and binomial forms",
    run: () => {
      const trig = parseLatex("\\sin(\\pi)");
      const trigValue = evalExpression(indexGraph(trig.graph), trig.rootId as string, {});
      assert(trigValue !== null && Math.abs(trigValue) < 1e-9, `sin(π) — received ${trigValue}`);
      const factorial = parseLatex("5!");
      equal(evalExpression(indexGraph(factorial.graph), factorial.rootId as string, {}), 120, "5!");
      const binom = parseLatex("\\binom{6}{2}");
      equal(evalExpression(indexGraph(binom.graph), binom.rootId as string, {}), 15, "C(6,2)");
    },
  },
  {
    suite: "Evaluator",
    name: "numeric summation respects its bounds",
    run: () => {
      const parsed = parseLatex("\\sum_{n=1}^{10} n");
      const value = evalExpression(indexGraph(parsed.graph), parsed.rootId as string, {});
      equal(value, 55, "sum 1..10");
    },
  },
  {
    suite: "Evaluator",
    name: "recognises y = f(x) as plottable",
    run: () => {
      const parsed = parseLatex("y = x^2 - 3");
      const analysis = analyzeGraph(parsed.graph);
      const plottable = analysis.find((entry) => entry.plottable);
      assert(plottable, "quadratic must be plottable");
      equal(plottable?.plottable?.variable, "x", "independent variable");
    },
  },
  {
    suite: "Evaluator",
    name: "folds constant subexpressions only",
    run: () => {
      const parsed = parseLatex("y = x + \\frac{6+2}{4}");
      const before = parsed.graph.nodes.length;
      const folded = foldConstants(parsed.graph);
      assert(folded.folded >= 1, "expected at least one fold");
      assert(folded.graph.nodes.length < before, "folding must remove vertices");
      const remaining = toLatex(
        folded.graph,
        rootNodes(folded.graph).find((node) => node.kind === "relation")?.id ?? rootNodes(folded.graph)[0].id,
        indexGraph(folded.graph),
      );
      assert(remaining.includes("x"), "the variable must survive folding");
    },
  },
  {
    suite: "Graph",
    name: "detects cyclic binding",
    run: () => {
      const d = draft();
      const a = operator(d, "\\times", "mul");
      const b = operator(d, "+", "add");
      d.bind(a, "left", b);
      d.bind(b, "left", a);
      const errors = diagnose({ nodes: d.nodes, edges: d.edges }).filter((entry) => entry.severity === "error");
      assert(errors.some((entry) => entry.message.includes("Cyclic")), "cycles must be reported");
    },
  },
  {
    suite: "Graph",
    name: "shared variables may feed several operators",
    run: () => {
      const parsed = parseLatex("\\sin^2\\theta + \\cos^2\\theta");
      assert(validateGraph(parsed.graph) === null, "sharing a variable must stay valid");
      const errors = diagnose(parsed.graph).filter((entry) => entry.severity === "error");
      equal(errors.length, 0, "sharing must not be diagnosed");
    },
  },
  {
    suite: "Graph",
    name: "composite vertices may not have two parents",
    run: () => {
      const d = draft();
      const a = num(d, "1");
      const b = num(d, "2");
      const c = num(d, "3");
      const sum = operator(d, "+", "add");
      d.bind(sum, "left", a);
      d.bind(sum, "right", b);
      const product = operator(d, "\\times", "mul");
      d.bind(product, "left", sum);
      d.bind(product, "right", c);
      const product2 = operator(d, "\\times", "mul");
      d.bind(product2, "left", sum);
      d.bind(product2, "right", a);
      const problem = validateGraph({ nodes: d.nodes, edges: d.edges });
      assert(problem !== null, "a composite with two parents must be rejected");
    },
  },
  {
    suite: "Graph",
    name: "rejects dangling edges at the validation boundary",
    run: () => {
      const d = draft();
      const a = num(d, "1");
      const problem = validateGraph({
        nodes: d.nodes,
        edges: [{ id: newId(), source: a.id, target: "missing", port: "left", role: "left" }],
      });
      assert(problem !== null, "dangling edge must be rejected");
    },
  },
  {
    suite: "Graph",
    name: "collapse → expand is a round trip",
    run: () => {
      const d = massEnergy();
      const graph = { nodes: d.nodes, edges: d.edges };
      const collapsed = collapseSelection(graph, [d.product.id, d.power.id, d.c.id, d.m.id, d.two.id]);
      assert(collapsed, "collapse must succeed");
      const groupId = collapsed as { groupId: string; graph: typeof graph };
      assert(groupId.graph.nodes.length === 1, "one vertex after collapse");
      const expanded = expandGroup(groupId.graph, groupId.groupId);
      assert(expanded, "expand must succeed");
      equal(expanded!.nodes.length, graph.nodes.length, "vertex count restored");
      equal(expanded!.edges.length, graph.edges.length, "binding count restored");
    },
  },
  {
    suite: "Graph",
    name: "auto-layout places roots without overlap in y",
    run: () => {
      const d = massEnergy();
      const index = indexGraph({ nodes: d.nodes, edges: d.edges });
      const positions = layoutComponent({ nodes: d.nodes, edges: d.edges }, d.product.id, { x: 500, y: 300 }, index);
      equal(positions.size, d.nodes.length, "every vertex positioned");
      const root: { x: number; y: number } | undefined = positions.get(d.product.id);
      assert(root !== undefined && Math.abs(root.y - 300) < 0.001, "root anchored at its y");
    },
  },
  {
    suite: "Graph",
    name: "bounds enclose every rendered vertex",
    run: () => {
      const d = massEnergy();
      const graph = reflowGraph({ nodes: d.nodes, edges: d.edges });
      const bounds = graphBounds(graph);
      for (const node of graph.nodes) {
        assert(node.x >= bounds.minX && node.x <= bounds.maxX, `${node.label} inside x bounds`);
        assert(node.y >= bounds.minY && node.y <= bounds.maxY, `${node.label} inside y bounds`);
      }
    },
  },
  {
    suite: "Scope",
    name: "groups variables by symbol across clusters",
    run: () => {
      const parsed = parseLatex("x + y");
      const second = parseLatex("x^2");
      const merged = {
        nodes: [...parsed.graph.nodes, ...second.graph.nodes],
        edges: [...parsed.graph.edges, ...second.graph.edges],
      };
      const scopes = scopeIndex(merged);
      const x = scopes.find((entry) => entry.token === "x");
      assert(x, "x must be scoped");
      equal(x?.nodeIds.length, 2, "two occurrences of x");
    },
  },
  {
    suite: "Discovery",
    name: "verifies a true identity",
    run: () => {
      const identity = parseLatex("\\sin^2\\theta + \\cos^2\\theta");
      const one = parseLatex("1");
      const merged = {
        nodes: [...identity.graph.nodes, ...one.graph.nodes],
        edges: [...identity.graph.edges, ...one.graph.edges],
      };
      const result = discover(merged, { scale: 0.9, families: ["relation"] });
      const equalities = result.proposals.filter((proposal) => proposal.kind === "equal");
      const holds = equalities.find((proposal) => proposal.verdict === "holds");
      assert(holds, "sin²θ + cos²θ = 1 must verify");
    },
  },
  {
    suite: "Discovery",
    name: "refutes a false equality with a counterexample",
    run: () => {
      const left = parseLatex("x");
      const right = parseLatex("x + 1");
      const merged = {
        nodes: [...left.graph.nodes, ...right.graph.nodes],
        edges: [...left.graph.edges, ...right.graph.edges],
      };
      const result = discover(merged, { scale: 0.9, families: ["relation"], limit: 20 });
      const refuted = result.proposals.find((proposal) => proposal.kind === "equal" && proposal.verdict === "refuted");
      assert(refuted, "x = x + 1 must be refuted");
      assert(refuted?.counterexample, "refutation must cite a counterexample");
    },
  },
  {
    suite: "Discovery",
    name: "respects the discovery focus",
    run: () => {
      const a = parseLatex("2");
      const b = parseLatex("3");
      const c = parseLatex("4");
      const merged = {
        nodes: [...a.graph.nodes, ...b.graph.nodes, ...c.graph.nodes],
        edges: [...a.graph.edges, ...b.graph.edges, ...c.graph.edges],
      };
      merged.nodes[0].x = 0;
      merged.nodes[1].x = 100;
      merged.nodes[2].x = 900;
      const result = discover(merged, { scale: 1, focusIds: [merged.nodes[0].id] });
      equal(result.clusters, 1, "focus restricts to one cluster");
    },
  },
  {
    suite: "Discovery",
    name: "scale band boundaries are monotone",
    run: () => {
      equal(scaleBand(0), "literal", "lower bound");
      equal(scaleBand(0.25), "cautious", "cautious start");
      equal(scaleBand(0.5), "balanced", "balanced start");
      equal(scaleBand(0.75), "wild", "wild start");
    },
  },
  {
    suite: "Discovery",
    name: "batch application preserves the single-binding invariant",
    run: () => {
      const left = parseLatex("2");
      const right = parseLatex("2 + 1");
      const merged = {
        nodes: [...left.graph.nodes, ...right.graph.nodes],
        edges: [...left.graph.edges, ...right.graph.edges],
      };
      merged.nodes[0].x = 0;
      merged.nodes[0].y = 0;
      for (const node of merged.nodes.slice(1)) {
        node.x = 80;
        node.y = 0;
      }
      const result = discover(merged, { scale: 1 });
      const patches: ConnectionPatch[] = result.proposals.slice(0, 4).map((proposal) => proposal.patch);
      const applied = applyProposals(merged, patches);
      const parents = new Map<string, number>();
      for (const edge of applied.graph.edges) {
        parents.set(edge.target, (parents.get(edge.target) ?? 0) + 1);
      }
      const byId = new Map(applied.graph.nodes.map((node) => [node.id, node]));
      for (const [target, count] of parents) {
        const node = byId.get(target);
        if (!node || ["literal", "variable", "set"].includes(node.kind)) continue;
        assert(count === 1, `composite vertex ${target} has ${count} bindings`);
      }
      assert(validateGraph(applied.graph) === null, "batch result must satisfy validateGraph");
    },
  },
  {
    suite: "Library",
    name: "every symbol declares a domain and a subdomain",
    run: () => {
      assert(LIBRARY_COUNT >= 300, `expected ≥300 symbols, received ${LIBRARY_COUNT}`);
      const missing = SYMBOL_LIBRARY.filter((entry) => !entry.domain || !entry.subdomain);
      equal(missing.length, 0, "symbols missing taxonomy");
    },
  },
  {
    suite: "Library",
    name: "every symbol derives at least one port or is a leaf",
    run: () => {
      const broken = SYMBOL_LIBRARY.filter((entry) => {
        const node = makeNode({
          kind: entry.kind,
          token: entry.token,
          label: entry.label,
          type: entry.type,
          variant: entry.variant,
        });
        if (["literal", "variable", "set"].includes(entry.kind)) return false;
        return portsFor(node).length === 0;
      });
      equal(broken.length, 0, `symbols without ports: ${broken.slice(0, 4).map((entry) => entry.token).join(", ")}`);
    },
  },
  {
    suite: "Library",
    name: "domains are unique and cover the taxonomy",
    run: () => {
      const domains = new Set(SYMBOL_LIBRARY.map((entry) => entry.domain));
      assert(domains.size >= 14, `expected ≥14 domains, received ${domains.size}`);
      for (const required of ["Algebra", "Trigonometry", "Calculus", "Linear algebra", "Set theory", "Logic"]) {
        assert(domains.has(required), `missing domain ${required}`);
      }
    },
  },
  {
    suite: "Interop",
    name: "document export serialises every cluster",
    run: () => {
      const a = parseLatex("a^2 + b^2 = c^2");
      const exported = documentLatex(a.graph);
      equal(exported.length, 1, "one cluster");
      assert(exported[0].latex.includes("="), "equality serialised");
      assert(exported[0].nodeIds.length >= 8, "node ids listed");
    },
  },
];

export function runKernelSuite(): SuiteReport {
  const started = Date.now();
  const outcomes: TestOutcome[] = TEST_CASES.map((test) => {
    try {
      test.run();
      return { suite: test.suite, name: test.name, ok: true, error: null };
    } catch (error) {
      return {
        suite: test.suite,
        name: test.name,
        ok: false,
        error: error instanceof Error ? error.message : String(error),
      };
    }
  });

  const suites = Array.from(new Set(outcomes.map((outcome) => outcome.suite))).map((suite) => {
    const entries = outcomes.filter((outcome) => outcome.suite === suite);
    return {
      suite,
      passed: entries.filter((entry) => entry.ok).length,
      failed: entries.filter((entry) => !entry.ok).length,
    };
  });

  return {
    generatedAt: new Date().toISOString(),
    total: outcomes.length,
    passed: outcomes.filter((outcome) => outcome.ok).length,
    failed: outcomes.filter((outcome) => !outcome.ok).length,
    durationMs: Date.now() - started,
    suites,
    outcomes,
    librarySymbols: LIBRARY_COUNT,
  };
}
