/**
 * Aura's numeric layer: a small, dependency-free evaluator over the typed
 * hypergraph. It powers three features:
 *   1. constant values shown in the inspector,
 *   2. the fold-constants "simplify" graph mutation,
 *   3. the plot pane (sampling f(x) straight out of the graph).
 * No `eval`, no string parsing of the expression — we walk ports.
 */

import {
  ACCENT_VARIANTS,
  BIG_VARIANTS,
  ENCLOSURE_VARIANTS,
  POSTFIX_VARIANTS,
  PREFIX_VARIANTS,
  type AuraEdge,
  type AuraGraph,
  type AuraNode,
  newId,
} from "./ontology";
import {
  type GraphIndex,
  childOf,
  componentRoot,
  indexGraph,
  subtreeIds,
  toLatex,
} from "./engine";

export function parseLiteral(token: string): number | null {
  const text = token.trim();
  if (/^[+-]?\d+(\.\d+)?$/.test(text)) return Number(text);
  if (/^[+-]?\.\d+$/.test(text)) return Number(text);
  if (text === "\\pi") return Math.PI;
  if (text === "e") return Math.E;
  const fraction = text.match(/^\\[td]?frac\{([^}]+)\}\{([^}]+)\}$/);
  if (fraction) {
    const numerator = parseLiteral(fraction[1]);
    const denominator = parseLiteral(fraction[2]);
    if (numerator !== null && denominator !== null && denominator !== 0) {
      return numerator / denominator;
    }
  }
  return null;
}

export function formatNumber(value: number): string {
  if (!Number.isFinite(value)) return "\\infty";
  if (Number.isInteger(value) && Math.abs(value) < 1e12) return String(value);
  const rounded = Number(value.toPrecision(6));
  return String(rounded);
}

const UNARY: Record<string, (value: number) => number> = {
  sin: Math.sin,
  cos: Math.cos,
  tan: Math.tan,
  sec: (value) => 1 / Math.cos(value),
  csc: (value) => 1 / Math.sin(value),
  cot: (value) => 1 / Math.tan(value),
  sinc: (value) => (value === 0 ? 1 : Math.sin(value) / value),
  arcsin: Math.asin,
  arccos: Math.acos,
  arctan: Math.atan,
  asin: Math.asin,
  acos: Math.acos,
  atan: Math.atan,
  sinh: Math.sinh,
  cosh: Math.cosh,
  tanh: Math.tanh,
  sech: (value) => 1 / Math.cosh(value),
  csch: (value) => 1 / Math.sinh(value),
  coth: (value) => 1 / Math.tanh(value),
  arsinh: Math.asinh,
  arcosh: Math.acosh,
  artanh: Math.atanh,
  asinh: Math.asinh,
  acosh: Math.acosh,
  atanh: Math.atanh,
  ln: Math.log,
  log: Math.log10,
  log10: Math.log10,
  log2: Math.log2,
  exp: Math.exp,
  sqrt: Math.sqrt,
  abs: Math.abs,
  floor: Math.floor,
  ceil: Math.ceil,
  tr: (value) => value,
  re: (value) => value,
  im: () => 0,
};

function factorial(value: number): number | null {
  if (!Number.isInteger(value) || value < 0 || value > 170) return null;
  let result = 1;
  for (let step = 2; step <= value; step += 1) result *= step;
  return result;
}

export function evalExpression(
  index: GraphIndex,
  nodeId: string,
  env: Record<string, number>,
  guard = new Set<string>(),
): number | null {
  const node = index.byId.get(nodeId);
  if (!node || guard.has(nodeId)) return null;
  const next = new Set(guard).add(nodeId);
  const child = (port: Parameters<typeof childOf>[2]): number | null => {
    const bound = childOf(index, nodeId, port);
    return bound ? evalExpression(index, bound.id, env, next) : null;
  };

  switch (node.kind) {
    case "literal":
      return parseLiteral(node.token);
    case "variable":
      if (node.token === "e" && env.e === undefined) return Math.E;
      return env[node.token] ?? env[node.label] ?? null;
    case "set":
    case "group":
    case "relation":
      return null;
    case "function": {
      const arg = child("arg");
      if (arg === null) return null;
      const key = (node.variant ?? node.token.replace("\\", "")).replace(/^operatorname\{?|\}?$/g, "").toLowerCase();
      const fn = UNARY[key];
      return fn ? fn(arg) : null;
    }
    case "container": {
      const variant = node.variant ?? "";
      if (ACCENT_VARIANTS.has(variant)) return child("body");
      if (variant === "sqrt") {
        const body = child("body");
        return body === null || body < 0 ? null : Math.sqrt(body);
      }
      if (variant === "root") {
        const body = child("body");
        const index = child("upper") ?? 2;
        if (body === null) return null;
        if (body < 0 && index % 2 === 0) return null;
        return Math.sign(body) * Math.pow(Math.abs(body), 1 / index);
      }
      if (ENCLOSURE_VARIANTS.has(variant)) {
        const body = child("body");
        if (body === null) return null;
        if (variant === "floor") return Math.floor(body);
        if (variant === "ceil") return Math.ceil(body);
        return Math.abs(body);
      }
      if (BIG_VARIANTS.has(variant)) {
        const bodyNode = childOf(index, nodeId, "body");
        if (!bodyNode) return null;
        if (variant !== "sum" && variant !== "prod") return null;

        // Bounds may be plain values or index relations such as `n = 1`.
        const lowerNode = childOf(index, nodeId, "lower");
        const upperNode = childOf(index, nodeId, "upper");
        let indexVar = "n";
        let start: number | null = null;
        let end: number | null = null;

        if (lowerNode) {
          if (lowerNode.kind === "relation" && lowerNode.variant === "equal") {
            const bound = childOf(index, lowerNode.id, "left");
            const value = childOf(index, lowerNode.id, "right");
            if (bound?.kind === "variable") indexVar = bound.token;
            start = value ? evalExpression(index, value.id, env, new Set<string>()) : null;
          } else {
            start = evalExpression(index, lowerNode.id, env, new Set<string>());
          }
        }
        end = upperNode ? evalExpression(index, upperNode.id, env, new Set<string>()) : null;

        if (start === null || end === null) {
          return evalExpression(index, bodyNode.id, env, new Set<string>());
        }
        if (!Number.isInteger(start) || !Number.isInteger(end) || end - start > 2000) return null;

        let total = variant === "sum" ? 0 : 1;
        for (let step = start; step <= end; step += 1) {
          const term = evalExpression(index, bodyNode.id, { ...env, [indexVar]: step }, new Set<string>());
          if (term === null || !Number.isFinite(term)) return null;
          total = variant === "sum" ? total + term : total * term;
        }
        return total;
      }
      return null;
    }
    case "operator": {
      if (node.variant === "power") {
        const base = child("base");
        const exponent = child("exponent");
        if (base === null || exponent === null) return null;
        const result = Math.pow(base, exponent);
        return Number.isFinite(result) ? result : null;
      }
      if (node.variant === "frac") {
        const numerator = child("numerator");
        const denominator = child("denominator");
        if (numerator === null || denominator === null || denominator === 0) return null;
        return numerator / denominator;
      }
      if (node.variant === "binom") {
        const upper = child("numerator");
        const lower = child("denominator");
        if (upper === null || lower === null) return null;
        const upperFact = factorial(upper);
        const lowerFact = factorial(lower);
        const diffFact = factorial(upper - lower);
        if (!upperFact || lowerFact === null || diffFact === null) return null;
        return upperFact / (lowerFact * diffFact);
      }
      if (node.variant && POSTFIX_VARIANTS.has(node.variant)) {
        const arg = child("arg");
        if (arg === null) return null;
        if (node.variant === "fact") return factorial(arg);
        if (node.variant === "degree") return (arg * 180) / Math.PI;
        return arg;
      }
      if (node.variant && PREFIX_VARIANTS.has(node.variant)) {
        const arg = child("arg");
        if (arg === null) return null;
        return node.variant === "neg" ? -arg : arg;
      }
      const left = child("left");
      const right = child("right");
      if (left === null || right === null) return null;
      switch (node.variant) {
        case "add":
          return left + right;
        case "sub":
          return left - right;
        case "mul":
        case "juxta":
          return left * right;
        default:
          return null;
      }
    }
    default:
      return null;
  }
}

export function collectVariables(
  index: GraphIndex,
  nodeId: string,
  out = new Set<string>(),
  guard = new Set<string>(),
): Set<string> {
  const node = index.byId.get(nodeId);
  if (!node || guard.has(nodeId)) return out;
  const next = new Set(guard).add(nodeId);
  if (node.kind === "variable") {
    out.add(node.token);
    return out;
  }
  const slots = index.children.get(nodeId);
  if (!slots) return out;
  for (const edge of slots.values()) collectVariables(index, edge.target, out, next);
  return out;
}

export interface PlotTarget {
  yRootId: string;
  yLatex: string;
  variable: string;
}

export interface ClusterAnalysis {
  rootId: string;
  nodeIds: string[];
  latex: string;
  variables: string[];
  /** Value when the whole cluster is constant. */
  value: number | null;
  /** Set when the cluster is a function of a single variable. */
  plottable: PlotTarget | null;
  isRelation: boolean;
}

export function analyzeCluster(
  graph: AuraGraph,
  rootId: string,
  index = indexGraph(graph),
): ClusterAnalysis | null {
  const root = index.byId.get(rootId);
  if (!root) return null;
  const variables = Array.from(collectVariables(index, rootId)).sort();
  const latex = toLatex(graph, rootId, index);
  let value: number | null = null;
  let plottable: PlotTarget | null = null;
  const isRelation = root.kind === "relation";

  if (isRelation && root.variant === "equal") {
    const left = childOf(index, rootId, "left");
    const right = childOf(index, rootId, "right");
    if (left && right) {
      const leftVars = Array.from(collectVariables(index, left.id));
      const rightVars = Array.from(collectVariables(index, right.id));
      // `y = f(x)` (or `f(t) = y`): the lone side names the output, the other
      // side supplies the independent variable.
      const leftLone = left.kind === "variable" && !rightVars.includes(left.token);
      const rightLone = right.kind === "variable" && !leftVars.includes(right.token);
      if (leftLone && rightVars.length === 1) {
        plottable = {
          yRootId: right.id,
          yLatex: toLatex(graph, right.id, index),
          variable: rightVars[0],
        };
      } else if (rightLone && leftVars.length === 1) {
        plottable = {
          yRootId: left.id,
          yLatex: toLatex(graph, left.id, index),
          variable: leftVars[0],
        };
      } else if (rightVars.length === 1 && leftVars.length === 0) {
        plottable = {
          yRootId: right.id,
          yLatex: toLatex(graph, right.id, index),
          variable: rightVars[0],
        };
      } else if (leftVars.length === 1 && rightVars.length === 0) {
        plottable = {
          yRootId: left.id,
          yLatex: toLatex(graph, left.id, index),
          variable: leftVars[0],
        };
      }
    }
  } else if (variables.length === 1) {
    plottable = { yRootId: rootId, yLatex: latex, variable: variables[0] };
  }

  if (variables.length === 0) value = evalExpression(index, rootId, {});

  return {
    rootId,
    nodeIds: Array.from(subtreeIds(index, rootId)),
    latex,
    variables,
    value,
    plottable,
    isRelation,
  };
}

export function analyzeGraph(graph: AuraGraph): ClusterAnalysis[] {
  const index = indexGraph(graph);
  return graph.nodes
    .filter((node) => !index.parent.has(node.id))
    .map((node) => analyzeCluster(graph, node.id, index))
    .filter((entry): entry is ClusterAnalysis => entry !== null);
}

export interface SamplePoint {
  x: number;
  y: number;
}

export function plotSamples(
  graph: AuraGraph,
  exprRootId: string,
  min: number,
  max: number,
  count = 280,
  variable = "x",
): SamplePoint[] {
  const index = indexGraph(graph);
  const points: SamplePoint[] = [];
  for (let step = 0; step <= count; step += 1) {
    const x = min + ((max - min) * step) / count;
    const y = evalExpression(index, exprRootId, { [variable]: x }, new Set<string>());
    if (y !== null && Number.isFinite(y)) points.push({ x, y });
  }
  return points;
}

/** Robust y-range that ignores asymptote blow-ups at the 2–98% band. */
export function sampleRange(points: SamplePoint[]): { min: number; max: number } {
  if (points.length === 0) return { min: -1, max: 1 };
  const sorted = points.map((point) => point.y).sort((a, b) => a - b);
  const low = sorted[Math.floor(sorted.length * 0.02)];
  const high = sorted[Math.floor(sorted.length * 0.98)];
  let min = Math.min(low, high);
  let max = Math.max(low, high);
  if (min === max) {
    min -= 1;
    max += 1;
  }
  const pad = (max - min) * 0.12;
  return { min: min - pad, max: max + pad };
}

/* ------------------------------------------------------------------ */
/* Constant folding (the "simplify" graph mutation)                    */
/* ------------------------------------------------------------------ */

export interface FoldResult {
  graph: AuraGraph;
  folded: number;
  summaries: string[];
}

export function foldConstants(graph: AuraGraph): FoldResult {
  const index = indexGraph(graph);
  const values = new Map<string, number | null>();
  for (const node of graph.nodes) values.set(node.id, evalExpression(index, node.id, {}));

  const chosen: string[] = [];
  for (const node of graph.nodes) {
    if (["literal", "relation", "set", "group"].includes(node.kind)) continue;
    const value = values.get(node.id);
    if (value === null || value === undefined) continue;
    const subtree = subtreeIds(index, node.id);
    if (subtree.size < 2) continue;
    let ancestor: AuraEdge | undefined = index.parent.get(node.id);
    let shadowed = false;
    while (ancestor) {
      const parentValue = values.get(ancestor.source);
      if (parentValue !== null && parentValue !== undefined) {
        shadowed = true;
        break;
      }
      ancestor = index.parent.get(ancestor.source);
    }
    if (!shadowed) chosen.push(node.id);
  }

  if (chosen.length === 0) return { graph, folded: 0, summaries: [] };

  const remove = new Set<string>();
  const addedNodes: AuraNode[] = [];
  const addedEdges: AuraEdge[] = [];
  const summaries: string[] = [];

  for (const id of chosen) {
    const node = index.byId.get(id);
    const value = values.get(id);
    if (!node || value === null || value === undefined) continue;
    const token = formatNumber(value);
    summaries.push(`${toLatex(graph, id, index)} \\to ${token}`);
    const literal: AuraNode = {
      id: newId(),
      kind: "literal",
      type: "Scalar",
      token,
      label: `Literal ${token}`,
      variant: null,
      x: node.x,
      y: node.y,
      collapsed: false,
      meta: { foldedFrom: id },
    };
    addedNodes.push(literal);
    const parentEdge = index.parent.get(id);
    if (parentEdge) {
      addedEdges.push({
        id: newId(),
        source: parentEdge.source,
        target: literal.id,
        port: parentEdge.port,
        role: parentEdge.role,
      });
    }
    for (const sub of subtreeIds(index, id)) remove.add(sub);
  }

  return {
    graph: {
      nodes: [...graph.nodes.filter((node) => !remove.has(node.id)), ...addedNodes],
      edges: [
        ...graph.edges.filter((edge) => !remove.has(edge.source) && !remove.has(edge.target)),
        ...addedEdges,
      ],
    },
    folded: addedNodes.length,
    summaries,
  };
}

/* ------------------------------------------------------------------ */
/* Variable scope                                                      */
/* ------------------------------------------------------------------ */

const SCOPE_COLORS = [
  "#f0b45a",
  "#5eead4",
  "#f472b6",
  "#a78bfa",
  "#60a5fa",
  "#34d399",
  "#fb7185",
  "#fbbf24",
];

export interface ScopeEntry {
  token: string;
  color: string;
  nodeIds: string[];
  clusterIds: string[];
}

/** Group variable occurrences by symbol, across clusters, for halo rendering. */
export function scopeIndex(graph: AuraGraph): ScopeEntry[] {
  const index = indexGraph(graph);
  const byToken = new Map<string, string[]>();
  for (const node of graph.nodes) {
    if (node.kind !== "variable" || node.collapsed) continue;
    byToken.set(node.token, [...(byToken.get(node.token) ?? []), node.id]);
  }
  return Array.from(byToken.entries())
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([token, nodeIds], offset) => ({
      token,
      color: SCOPE_COLORS[offset % SCOPE_COLORS.length],
      nodeIds,
      clusterIds: Array.from(
        new Set(nodeIds.map((id) => componentRoot(index, id)?.id ?? id)),
      ),
    }));
}

export function scopeByNode(graph: AuraGraph): Map<string, { color: string; token: string }> {
  const out = new Map<string, { color: string; token: string }>();
  for (const entry of scopeIndex(graph)) {
    for (const nodeId of entry.nodeIds) out.set(nodeId, { color: entry.color, token: entry.token });
  }
  return out;
}
