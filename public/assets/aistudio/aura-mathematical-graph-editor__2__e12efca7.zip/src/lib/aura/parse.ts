/**
 * Tier-2 structural recovery: LaTeX tokens (from handwriting recognition or
 * typed input) are lexed straight into typed graph vertices and bindings.
 * Nothing here depends on a syntax string at runtime — LaTeX is only an input
 * and output format.
 */

import {
  type AuraEdge,
  type AuraGraph,
  type AuraNode,
  type MathType,
  type NodeKind,
  type PortId,
  makeNode,
  newId,
} from "./ontology";
import { indexGraph, toLatex } from "./engine";
import { LIBRARY_BY_COMMAND } from "./library";
import { ACCENT_VARIANTS, BIG_VARIANTS, ENCLOSURE_VARIANTS, MATRIX_VARIANTS, PREFIX_VARIANTS } from "./ontology";

export class ParseError extends Error {}

type TokenType =
  | "num"
  | "ident"
  | "cmd"
  | "op"
  | "rel"
  | "lparen"
  | "rparen"
  | "lbrace"
  | "rbrace"
  | "caret"
  | "underscore"
  | "lbracket"
  | "rbracket"
  | "comma"
  | "eof";

interface Token {
  type: TokenType;
  value: string;
}

const GREEK: Record<string, string> = {
  alpha: "\\alpha",
  beta: "\\beta",
  gamma: "\\gamma",
  delta: "\\delta",
  theta: "\\theta",
  lambda: "\\lambda",
  mu: "\\mu",
  pi: "\\pi",
  rho: "\\rho",
  sigma: "\\sigma",
  tau: "\\tau",
  phi: "\\phi",
  omega: "\\omega",
  Delta: "\\Delta",
  Sigma: "\\Sigma",
  Omega: "\\Omega",
};

const RELATION_COMMANDS: Record<string, { token: string; variant: string }> = {
  "=": { token: "=", variant: "equal" },
  "\\approx": { token: "\\approx", variant: "approx" },
  "\\neq": { token: "\\neq", variant: "neq" },
  "\\le": { token: "\\le", variant: "leq" },
  "\\leq": { token: "\\le", variant: "leq" },
  "\\ge": { token: "\\ge", variant: "geq" },
  "\\geq": { token: "\\ge", variant: "geq" },
  "\\to": { token: "\\to", variant: "mapsto" },
  "\\mapsto": { token: "\\to", variant: "mapsto" },
  "\\in": { token: "\\in", variant: "in" },
  "\\subset": { token: "\\subset", variant: "subset" },
  "<": { token: "<", variant: "leq" },
  ">": { token: ">", variant: "geq" },
};

const ARITHMETIC: Record<string, { token: string; variant: string }> = {
  "+": { token: "+", variant: "add" },
  "-": { token: "-", variant: "sub" },
  "*": { token: "\\times", variant: "mul" },
  "\\cdot": { token: "\\times", variant: "mul" },
  "\\times": { token: "\\times", variant: "mul" },
  "\\div": { token: "\\div", variant: "mul" },
};

const FUNCTIONS = new Set(["sin", "cos", "tan", "ln", "log", "exp"]);
const IGNORED = new Set(["left", "right", "displaystyle", "limits", "!", " ", ","]);

export function tokenizeLatex(source: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  const input = source.replace(/\s+/g, " ").trim();
  while (i < input.length) {
    const char = input[i];
    if (char === " ") {
      i += 1;
      continue;
    }
    if (/[0-9]/.test(char) || (char === "." && /[0-9]/.test(input[i + 1] ?? ""))) {
      let value = "";
      while (i < input.length && /[0-9.]/.test(input[i])) {
        value += input[i];
        i += 1;
      }
      tokens.push({ type: "num", value });
      continue;
    }
    if (char === "\\") {
      let name = "";
      i += 1;
      while (i < input.length && /[a-zA-Z]/.test(input[i])) {
        name += input[i];
        i += 1;
      }
      if (!name) {
        tokens.push({ type: "cmd", value: "\\" + (input[i] ?? "") });
        i += 1;
        continue;
      }
      if (name === "mathbb" || name === "mathbf" || name === "mathcal") {
        let inner = "";
        if (input[i] === "{") {
          const end = input.indexOf("}", i);
          if (end === -1) throw new ParseError("Unclosed \\mathbb{...}");
          inner = input.slice(i + 1, end);
          i = end + 1;
        } else {
          inner = input[i] ?? "R";
          i += 1;
        }
        tokens.push({ type: "cmd", value: `\\${name}{${inner}}` });
        continue;
      }
      if (name === "frac" || name === "sqrt") {
        tokens.push({ type: "cmd", value: `\\${name}` });
        continue;
      }
      if (name === "int" || name === "sum" || name === "prod") {
        tokens.push({ type: "cmd", value: `\\${name}` });
        continue;
      }
      if (FUNCTIONS.has(name)) {
        tokens.push({ type: "cmd", value: `\\${name}` });
        continue;
      }
      if (name === "pi" || name === "infty" || GREEK[name]) {
        tokens.push({ type: "cmd", value: name === "infty" ? "\\infty" : (GREEK[name] ?? `\\${name}`) });
        continue;
      }
      if (RELATION_COMMANDS[`\\${name}`]) {
        tokens.push({ type: "rel", value: `\\${name}` });
        continue;
      }
      if (ARITHMETIC[`\\${name}`]) {
        tokens.push({ type: "op", value: `\\${name}` });
        continue;
      }
      if (IGNORED.has(name)) continue;
      tokens.push({ type: "cmd", value: `\\${name}` });
      continue;
    }
    if (/[a-zA-Z]/.test(char)) {
      tokens.push({ type: "ident", value: char });
      i += 1;
      continue;
    }
    if (char === "^") {
      tokens.push({ type: "caret", value: "^" });
      i += 1;
      continue;
    }
    if (char === "_") {
      tokens.push({ type: "underscore", value: "_" });
      i += 1;
      continue;
    }
    if (char === "(") {
      tokens.push({ type: "lparen", value: "(" });
      i += 1;
      continue;
    }
    if (char === ")") {
      tokens.push({ type: "rparen", value: ")" });
      i += 1;
      continue;
    }
    if (char === "{") {
      tokens.push({ type: "lbrace", value: "{" });
      i += 1;
      continue;
    }
    if (char === "}") {
      tokens.push({ type: "rbrace", value: "}" });
      i += 1;
      continue;
    }
    if (char === ",") {
      tokens.push({ type: "comma", value: "," });
      i += 1;
      continue;
    }
    if (char === "[") {
      tokens.push({ type: "lbracket", value: "[" });
      i += 1;
      continue;
    }
    if (char === "]") {
      tokens.push({ type: "rbracket", value: "]" });
      i += 1;
      continue;
    }
    if (char === "!") {
      tokens.push({ type: "op", value: "!" });
      i += 1;
      continue;
    }
    if (char === "/") {
      tokens.push({ type: "op", value: "/" });
      i += 1;
      continue;
    }
    if (RELATION_COMMANDS[char]) {
      tokens.push({ type: "rel", value: char });
      i += 1;
      continue;
    }
    if (ARITHMETIC[char]) {
      tokens.push({ type: "op", value: char });
      i += 1;
      continue;
    }
    // Unknown glyph: treat as a variable so the node still materialises.
    tokens.push({ type: "ident", value: char });
    i += 1;
  }
  tokens.push({ type: "eof", value: "" });
  return tokens;
}

class Builder {
  graph: AuraGraph = { nodes: [], edges: [] };

  add(input: {
    kind: NodeKind;
    token: string;
    label: string;
    type: MathType;
    variant?: string | null;
  }): AuraNode {
    const node = makeNode({
      kind: input.kind,
      token: input.token,
      label: input.label,
      type: input.type,
      variant: input.variant ?? null,
    });
    this.graph.nodes.push(node);
    return node;
  }

  bind(parent: AuraNode, port: PortId, child: AuraNode | null): void {
    if (!child) return;
    const edge: AuraEdge = {
      id: newId(),
      source: parent.id,
      target: child.id,
      port,
      role: port,
    };
    this.graph.edges.push(edge);
  }
}

class Parser {
  private position = 0;
  private builder = new Builder();
  /**
   * A function written as `\sin^2\theta` defers its argument until after the
   * power has been constructed (the exponent binds tighter than application).
   */
  private pendingFunctionArgs: AuraNode[] = [];

  constructor(private tokens: Token[]) {}

  parse(): { graph: AuraGraph; rootId: string | null } {
    const root = this.parseRelation();
    return { graph: this.builder.graph, rootId: root?.id ?? null };
  }

  private peek(offset = 0): Token {
    return this.tokens[Math.min(this.position + offset, this.tokens.length - 1)];
  }

  private next(): Token {
    const token = this.peek();
    this.position += 1;
    return token;
  }

  private accept(type: TokenType): boolean {
    if (this.peek().type === type) {
      this.position += 1;
      return true;
    }
    return false;
  }

  private expect(type: TokenType, what: string): Token {
    if (this.peek().type !== type) {
      throw new ParseError(`Expected ${what} but found "${this.peek().value || "end of input"}".`);
    }
    return this.next();
  }

  private braced(parse: () => AuraNode | null): AuraNode | null {
    if (this.accept("lbrace")) {
      const node = parse();
      this.expect("rbrace", "}");
      return node;
    }
    return parse();
  }

  private startsPrimary(token: Token): boolean {
    if (token.type === "num" || token.type === "ident" || token.type === "lparen") return true;
    if (token.type === "cmd") {
      if (token.value.startsWith("\\mathbb")) return true;
      if (FUNCTIONS.has(token.value.replace("\\", ""))) return true;
      if (token.value === "\\frac" || token.value === "\\sqrt") return true;
      if (token.value === "\\int" || token.value === "\\sum" || token.value === "\\prod") return true;
      return token.value === "\\pi" || token.value === "\\infty" || token.value.startsWith("\\");
    }
    return false;
  }

  private parseRelation(): AuraNode | null {
    let left = this.parseAdditive();
    while (this.peek().type === "rel" && left) {
      const spec = RELATION_COMMANDS[this.next().value];
      if (!spec) continue;
      const right = this.parseAdditive();
      const relation = this.builder.add({
        kind: "relation",
        token: spec.token,
        label: relationLabel(spec.variant),
        type: "Relation",
        variant: spec.variant,
      });
      this.builder.bind(relation, "left", left);
      this.builder.bind(relation, "right", right);
      left = relation;
    }
    return left;
  }

  private parseAdditive(): AuraNode | null {
    let left = this.parseMultiplicative();
    while (this.peek().type === "op" && ["+", "-"].includes(this.peek().value) && left) {
      const op = ARITHMETIC[this.next().value];
      const right = this.parseMultiplicative();
      const operator = this.builder.add({
        kind: "operator",
        token: op.token,
        label: op.variant === "add" ? "Addition" : "Subtraction",
        type: "Operator",
        variant: op.variant,
      });
      this.builder.bind(operator, "left", left);
      this.builder.bind(operator, "right", right);
      left = operator;
    }
    return left;
  }

  private parseMultiplicative(): AuraNode | null {
    let left = this.parsePower();
    for (;;) {
      const token = this.peek();
      if (token.type === "op" && token.value === "/" && left) {
        this.next();
        const denominator = this.parsePower();
        const frac = this.builder.add({
          kind: "operator",
          token: "\\frac",
          label: "Fraction",
          type: "Operator",
          variant: "frac",
        });
        this.builder.bind(frac, "numerator", left);
        this.builder.bind(frac, "denominator", denominator);
        left = frac;
        continue;
      }
      if (token.type === "op" && ["*", "\\cdot", "\\times", "\\div"].includes(token.value) && left) {
        const spec = ARITHMETIC[this.next().value] ?? { token: "\\times", variant: "mul" };
        const right = this.parsePower();
        const operator = this.builder.add({
          kind: "operator",
          token: spec.token,
          label: "Product",
          type: "Operator",
          variant: spec.variant,
        });
        this.builder.bind(operator, "left", left);
        this.builder.bind(operator, "right", right);
        left = operator;
        continue;
      }
      if (this.startsPrimary(token) && left) {
        const right = this.parsePower();
        const operator = this.builder.add({
          kind: "operator",
          token: "\\,",
          label: "Juxtaposition",
          type: "Operator",
          variant: "juxta",
        });
        this.builder.bind(operator, "left", left);
        this.builder.bind(operator, "right", right);
        left = operator;
        continue;
      }
      break;
    }
    return left;
  }

  private attachPendingArguments(): void {
    if (this.pendingFunctionArgs.length === 0) return;
    const pendings = this.pendingFunctionArgs.splice(0, this.pendingFunctionArgs.length);
    if (!this.startsPrimary(this.peek())) return;
    const arg = this.parsePower();
    if (!arg) return;
    // Only the most recent degenerate function takes the argument.
    const target = pendings[pendings.length - 1];
    const index = this.builder.graph.nodes.findIndex((node) => node.id === target.id);
    if (index === -1) return;
    void index;
    this.builder.bind(target, "arg", arg);
  }

  private parsePower(): AuraNode | null {
    let base = this.parsePostfix();
    if (this.peek().type === "caret" && base) {
      this.next();
      const exponent = this.braced(() => this.parsePostfix()) ?? this.parsePostfix();
      const power = this.builder.add({
        kind: "operator",
        token: "^",
        label: "Power",
        type: "Operator",
        variant: "power",
      });
      this.builder.bind(power, "base", base);
      this.builder.bind(power, "exponent", exponent);
      base = power;
      this.attachPendingArguments();
    }
    return base;
  }

  private parsePostfix(): AuraNode | null {
    let base = this.parsePrimary();
    while (base && this.peek().type === "op" && this.peek().value === "!") {
      this.next();
      const factorial = this.builder.add({
        kind: "operator",
        token: "!",
        label: "Factorial",
        type: "Operator",
        variant: "fact",
      });
      this.builder.bind(factorial, "arg", base);
      base = factorial;
    }
    while (base && this.peek().type === "underscore") {
      this.next();
      const index = this.braced(() => this.parsePrimary()) ?? this.parsePrimary();
      if (["literal", "variable", "set", "group"].includes(base.kind)) {
        this.builder.bind(base, "subscript", index);
      }
    }
    return base;
  }

  /** Build a typed vertex for any symbol-library entry, wrapping its operand. */
  private fromLibrary(
    kind: NodeKind,
    token: string,
    label: string,
    type: MathType,
    variant: string | null,
    variantName: string,
  ): AuraNode {
    const node = this.builder.add({ kind, token, label, type, variant });
    const spec = variant ?? variantName;
    if (kind === "function") {
      // LaTeX puts an exponent before the argument: \sin^2\theta.
      let exponent: AuraNode | null = null;
      if (this.peek().type === "caret") {
        this.next();
        exponent = this.braced(() => this.parsePrimary()) ?? this.parsePrimary();
      }
      let arg: AuraNode | null = null;
      if (this.peek().type === "lparen") {
        this.next();
        arg = this.parseRelation();
        this.accept("rparen");
      } else if (this.peek().type === "lbrace") {
        arg = this.braced(() => this.parseRelation());
      } else if (this.startsPrimary(this.peek())) {
        arg = this.parsePower();
      }
      this.builder.bind(node, "arg", arg);
      if (!exponent) return node;
      if (!arg) this.pendingFunctionArgs.push(node);
      const power = this.builder.add({
        kind: "operator",
        token: "^",
        label: "Power",
        type: "Operator",
        variant: "power",
      });
      this.builder.bind(power, "base", node);
      this.builder.bind(power, "exponent", exponent);
      return power;
    }
    if (kind === "container" && (ACCENT_VARIANTS.has(spec) || MATRIX_VARIANTS.has(spec) || ENCLOSURE_VARIANTS.has(spec))) {
      const body = this.braced(() => this.parseRelation());
      this.builder.bind(node, "body", body);
      return node;
    }
    if (kind === "operator" && spec === "binom") {
      const upper = this.braced(() => this.parseRelation());
      const lower = this.braced(() => this.parseRelation());
      this.builder.bind(node, "numerator", upper);
      this.builder.bind(node, "denominator", lower);
      return node;
    }
    if (kind === "container" && BIG_VARIANTS.has(spec)) {
      for (const marker of ["underscore", "caret"] as const) {
        if (this.peek().type === marker) {
          this.next();
          const bound = this.braced(() => this.parseRelation()) ?? this.parsePrimary();
          this.builder.bind(node, marker === "underscore" ? "lower" : "upper", bound);
        }
      }
      const body = this.parseMultiplicative();
      this.builder.bind(node, "body", body);
      return node;
    }
    if (
      kind === "operator" &&
      (token === "\\cup" || token === "\\cap") &&
      (this.peek().type === "underscore" || this.peek().type === "caret")
    ) {
      // `\cup_{i}` is the indexed big union, not the binary connective.
      node.kind = "container";
      node.variant = token === "\\cup" ? "bigcup" : "bigcap";
      node.type = "Expression";
      node.token = token === "\\cup" ? "\\bigcup" : "\\bigcap";
      node.label = token === "\\cup" ? "Arbitrary union" : "Arbitrary intersection";
      for (const marker of ["underscore", "caret"] as const) {
        if (this.peek().type === marker) {
          this.next();
          const bound = this.braced(() => this.parseRelation());
          this.builder.bind(node, marker === "underscore" ? "lower" : "upper", bound);
        }
      }
      this.builder.bind(node, "body", this.parseMultiplicative());
      return node;
    }
    if (kind === "operator" && (spec === "abs" || spec === "norm" || spec === "floor" || spec === "ceil")) {
      const arg = this.peek().type === "lbrace" ? this.braced(() => this.parseRelation()) : this.parsePower();
      this.builder.bind(node, "arg", arg);
      return node;
    }
    if (kind === "operator" && PREFIX_VARIANTS.has(spec)) {
      const arg = this.startsPrimary(this.peek()) ? this.parsePower() : null;
      this.builder.bind(node, "arg", arg);
      return node;
    }
    return node;
  }

  private parsePrimary(): AuraNode | null {
    const token = this.peek();
    if (token.type === "op" && (token.value === "-" || token.value === "+")) {
      this.next();
      const operand = this.parsePower();
      if (token.value === "+") return operand;
      const negation = this.builder.add({
        kind: "operator",
        token: "\\neg",
        label: "Negation",
        type: "Operator",
        variant: "neg",
      });
      this.builder.bind(negation, "arg", operand);
      return negation;
    }
    if (token.type === "num") {
      this.next();
      return this.builder.add({
        kind: "literal",
        token: token.value,
        label: `Literal ${token.value}`,
        type: "Scalar",
      });
    }
    if (token.type === "lparen") {
      this.next();
      const inner = this.parseRelation();
      this.accept("rparen");
      return inner;
    }
    if (token.type === "lbrace") {
      this.next();
      const inner = this.parseRelation();
      this.expect("rbrace", "}");
      return inner;
    }
    if (token.type === "ident") {
      this.next();
      const char = token.value;
      if (this.peek().type === "lparen") {
        const fn = this.builder.add({
          kind: "function",
          token: char,
          label: `Function ${char}`,
          type: "Function",
          variant: char,
        });
        this.next();
        const arg = this.parseRelation();
        this.accept("rparen");
        this.builder.bind(fn, "arg", arg);
        return fn;
      }
      return this.builder.add({
        kind: "variable",
        token: char,
        label: `Variable ${char}`,
        type: "Variable",
      });
    }
    if (token.type === "cmd") {
      this.next();
      const command = token.value;
      if (command === "\\frac") {
        const numerator = this.braced(() => this.parseRelation());
        const denominator = this.braced(() => this.parseRelation());
        const frac = this.builder.add({
          kind: "operator",
          token: "\\frac",
          label: "Fraction",
          type: "Operator",
          variant: "frac",
        });
        this.builder.bind(frac, "numerator", numerator);
        this.builder.bind(frac, "denominator", denominator);
        return frac;
      }
      if (command === "\\sqrt") {
        let index: AuraNode | null = null;
        if (this.accept("lbracket")) {
          index = this.parseRelation();
          this.accept("rbracket");
        }
        const body = this.braced(() => this.parseRelation());
        const radical = this.builder.add({
          kind: "container",
          token: index ? "\\sqrt[\\phantom{n}]{\\phantom{x}}" : "\\sqrt{\\phantom{x}}",
          label: index ? "nth root" : "Square root",
          type: "Expression",
          variant: index ? "root" : "sqrt",
        });
        this.builder.bind(radical, "upper", index);
        this.builder.bind(radical, "body", body);
        return radical;
      }
      if (command === "\\int" || command === "\\sum" || command === "\\prod") {
        const container = this.builder.add({
          kind: "container",
          token: command,
          label: command === "\\int" ? "Integral" : "Summation",
          type: "Expression",
          variant: command === "\\int" ? "int" : "sum",
        });
        for (const type of ["underscore", "caret"] as const) {
          if (this.peek().type === type) {
            this.next();
            const bound = this.braced(() => this.parseRelation()) ?? this.parsePrimary();
            this.builder.bind(container, type === "underscore" ? "lower" : "upper", bound);
          }
        }
        const body = this.parseMultiplicative();
        this.builder.bind(container, "body", body);
        return container;
      }
      if (FUNCTIONS.has(command.replace("\\", ""))) {
        const fn = this.builder.add({
          kind: "function",
          token: command,
          label: command,
          type: "Function",
          variant: command.replace("\\", ""),
        });
        // `\sin^2 x` — the exponent precedes the argument and binds tighter.
        let exponent: AuraNode | null = null;
        if (this.peek().type === "caret") {
          this.next();
          exponent = this.braced(() => this.parsePrimary()) ?? this.parsePrimary();
        }
        let arg: AuraNode | null = null;
        if (this.peek().type === "lparen") {
          this.next();
          arg = this.parseRelation();
          this.accept("rparen");
        } else if (this.peek().type === "lbrace") {
          arg = this.braced(() => this.parseRelation());
        } else if (this.startsPrimary(this.peek())) {
          arg = this.parsePower();
        }
        this.builder.bind(fn, "arg", arg);
        if (!exponent) return fn;
        if (!arg) this.pendingFunctionArgs.push(fn);
        const power = this.builder.add({
          kind: "operator",
          token: "^",
          label: "Power",
          type: "Operator",
          variant: "power",
        });
        this.builder.bind(power, "base", fn);
        this.builder.bind(power, "exponent", exponent);
        return power;
      }
      if (command.startsWith("\\mathbb")) {
        const inner = command.slice(command.indexOf("{") + 1, command.lastIndexOf("}"));
        return this.builder.add({
          kind: "set",
          token: `\\mathbb{${inner || "R"}}`,
          label: `Set ${inner}`,
          type: "Set",
        });
      }
      if (command === "\\infty") {
        return this.builder.add({
          kind: "literal",
          token: "\\infty",
          label: "Infinity",
          type: "Scalar",
        });
      }
      if (command === "\\pi") {
        return this.builder.add({
          kind: "literal",
          token: "\\pi",
          label: "π",
          type: "Scalar",
        });
      }
      const entry = LIBRARY_BY_COMMAND.get(command);
      if (entry) return this.fromLibrary(entry.kind, entry.token, entry.label, entry.type, entry.variant, entry.variant ?? "");
      const greek = command.replace("\\", "");
      return this.builder.add({
        kind: "variable",
        token: command,
        label: GREEK[greek] ? greek : greek,
        type: "Variable",
      });
    }
    this.next();
    return null;
  }
}

function relationLabel(variant: string): string {
  switch (variant) {
    case "equal":
      return "Equality";
    case "approx":
      return "Approximation";
    case "mapsto":
      return "Mapping";
    case "in":
      return "Membership";
    case "subset":
      return "Subset";
    case "leq":
      return "Order";
    case "geq":
      return "Order";
    default:
      return "Relation";
  }
}

export interface ParseResult {
  graph: AuraGraph;
  rootId: string | null;
  normalized: string;
  nodeCount: number;
  edgeCount: number;
}

export function parseLatex(source: string): ParseResult {
  if (!source.trim()) throw new ParseError("Nothing to parse.");
  const tokens = tokenizeLatex(source);
  const parser = new Parser(tokens);
  const { graph, rootId } = parser.parse();
  if (graph.nodes.length === 0) throw new ParseError("No mathematical tokens were recognised.");
  const index = indexGraph(graph);
  const normalized = rootId ? toLatex(graph, rootId, index) : "";
  return {
    graph,
    rootId,
    normalized,
    nodeCount: graph.nodes.length,
    edgeCount: graph.edges.length,
  };
}
