import { and, asc, desc, eq, sql } from "drizzle-orm";

import { db } from "@/db";
import {
  discoveries as discoveriesTable,
  documents,
  edges as edgesTable,
  nodes as nodesTable,
  transactions,
} from "@/db/schema";
import type { AuraEdge, AuraGraph, AuraNode, MathType, NodeKind, PortId } from "./ontology";
import {
  type DocumentPayload,
  type DocumentSummary,
  type HistoryEntry,
  validateGraph,
} from "./engine";
import { EMPTY_DOCUMENT, SEED_DOCUMENTS } from "./seeds";

type Executor = typeof db;

async function loadGraph(documentId: string, exec: Executor = db): Promise<AuraGraph> {
  const [nodeRows, edgeRows] = await Promise.all([
    exec.select().from(nodesTable).where(eq(nodesTable.documentId, documentId)),
    exec.select().from(edgesTable).where(eq(edgesTable.documentId, documentId)),
  ]);
  const nodes: AuraNode[] = nodeRows.map((row) => ({
    id: row.id,
    kind: row.kind as NodeKind,
    type: row.type as MathType,
    token: row.token,
    label: row.label,
    variant: row.variant,
    x: row.x,
    y: row.y,
    collapsed: row.collapsed,
    meta: (row.meta as Record<string, unknown> | null) ?? null,
  }));
  const edges: AuraEdge[] = edgeRows.map((row) => ({
    id: row.id,
    source: row.sourceId,
    target: row.targetId,
    port: row.port as PortId,
    role: row.role,
  }));
  return { nodes, edges };
}

async function saveGraph(documentId: string, graph: AuraGraph, exec: Executor = db): Promise<void> {
  await exec.delete(edgesTable).where(eq(edgesTable.documentId, documentId));
  await exec.delete(nodesTable).where(eq(nodesTable.documentId, documentId));
  if (graph.nodes.length > 0) {
    await exec.insert(nodesTable).values(
      graph.nodes.map((node) => ({
        id: node.id,
        documentId,
        kind: node.kind,
        type: node.type,
        token: node.token,
        label: node.label,
        variant: node.variant,
        x: node.x,
        y: node.y,
        collapsed: node.collapsed,
        meta: node.meta,
      })),
    );
  }
  if (graph.edges.length > 0) {
    await exec.insert(edgesTable).values(
      graph.edges.map((edge) => ({
        id: edge.id,
        documentId,
        sourceId: edge.source,
        targetId: edge.target,
        port: edge.port,
        role: edge.role,
      })),
    );
  }
}

async function historyFor(documentId: string, exec: Executor = db): Promise<HistoryEntry[]> {
  const rows = await exec
    .select({
      id: transactions.id,
      seq: transactions.seq,
      action: transactions.action,
      summary: transactions.summary,
      undone: transactions.undone,
      createdAt: transactions.createdAt,
    })
    .from(transactions)
    .where(eq(transactions.documentId, documentId))
    .orderBy(desc(transactions.seq))
    .limit(60);
  return rows.map((row) => ({
    id: row.id,
    seq: row.seq,
    action: row.action,
    summary: row.summary,
    undone: row.undone,
    createdAt: row.createdAt.toISOString(),
  }));
}

async function buildPayload(documentId: string): Promise<DocumentPayload | null> {
  const [documentRow] = await db.select().from(documents).where(eq(documents.id, documentId)).limit(1);
  if (!documentRow) return null;
  const graph = await loadGraph(documentId);
  const history = await historyFor(documentId);
  return {
    document: {
      id: documentRow.id,
      title: documentRow.title,
      subtitle: documentRow.subtitle,
      updatedAt: documentRow.updatedAt.toISOString(),
    },
    graph,
    history,
    canUndo: history.some((entry) => !entry.undone),
    canRedo: history.some((entry) => entry.undone),
  };
}

export async function listDocuments(): Promise<DocumentSummary[]> {
  const rows = await db
    .select({
      id: documents.id,
      title: documents.title,
      subtitle: documents.subtitle,
      updatedAt: documents.updatedAt,
      nodeCount: sql<number>`(select count(*)::int from "nodes" where "nodes"."document_id" = "documents"."id")`,
      transactionCount: sql<number>`(select count(*)::int from "transactions" where "transactions"."document_id" = "documents"."id")`,
    })
    .from(documents)
    .orderBy(asc(documents.createdAt));
  return rows.map((row) => ({
    id: row.id,
    title: row.title,
    subtitle: row.subtitle,
    updatedAt: row.updatedAt.toISOString(),
    nodeCount: Number(row.nodeCount),
    transactionCount: Number(row.transactionCount),
  }));
}

export async function getDocument(documentId: string): Promise<DocumentPayload | null> {
  return buildPayload(documentId);
}

export async function ensureSeed(): Promise<void> {
  const [existing] = await db.select({ id: documents.id }).from(documents).limit(1);
  if (existing) return;
  for (const seed of SEED_DOCUMENTS) {
    const [row] = await db
      .insert(documents)
      .values({ title: seed.title, subtitle: seed.subtitle })
      .returning({ id: documents.id });
    if (row) await saveGraph(row.id, seed.graph);
  }
}

export async function createDocument(title?: string): Promise<DocumentPayload> {
  const seed = EMPTY_DOCUMENT(title?.trim() || "Untitled canvas");
  const [row] = await db
    .insert(documents)
    .values({ title: seed.title, subtitle: seed.subtitle })
    .returning({ id: documents.id });
  if (!row) throw new Error("Could not create the document");
  await saveGraph(row.id, seed.graph);
  const payload = await buildPayload(row.id);
  if (!payload) throw new Error("Could not create the document");
  return payload;
}

export async function deleteDocument(documentId: string): Promise<void> {
  await db.delete(documents).where(eq(documents.id, documentId));
}

async function nextSeq(documentId: string, exec: Executor): Promise<number> {
  const [row] = await exec
    .select({ maxSeq: sql<number>`coalesce(max(${transactions.seq}), 0)::int` })
    .from(transactions)
    .where(eq(transactions.documentId, documentId));
  return Number(row?.maxSeq ?? 0) + 1;
}

export interface DiscoveryRecord {
  id: string;
  scale: number;
  clusters: number;
  considered: number;
  proposed: number;
  holds: number;
  refuted: number;
  summary: string;
  createdAt: string;
}

export async function recordDiscovery(
  documentId: string,
  input: {
    scale: number;
    clusters: number;
    considered: number;
    proposed: number;
    holds: number;
    refuted: number;
    summary: string;
  },
): Promise<void> {
  await db.insert(discoveriesTable).values({
    documentId,
    scale: input.scale,
    clusters: input.clusters,
    considered: input.considered,
    proposed: input.proposed,
    holds: input.holds,
    refuted: input.refuted,
    summary: input.summary.slice(0, 240),
  });
}

export async function listDiscoveries(documentId: string, limit = 12): Promise<DiscoveryRecord[]> {
  const rows = await db
    .select()
    .from(discoveriesTable)
    .where(eq(discoveriesTable.documentId, documentId))
    .orderBy(desc(discoveriesTable.createdAt))
    .limit(limit);
  return rows.map((row) => ({
    id: row.id,
    scale: row.scale,
    clusters: row.clusters,
    considered: row.considered,
    proposed: row.proposed,
    holds: row.holds,
    refuted: row.refuted,
    summary: row.summary,
    createdAt: row.createdAt.toISOString(),
  }));
}

export interface MutationResult {
  payload: DocumentPayload;
  message: string;
  focusId: string | null;
}

export async function applyMutation(
  documentId: string,
  action: string,
  mutate: (graph: AuraGraph) => { graph: AuraGraph; summary: string; focusId?: string | null },
): Promise<MutationResult> {
  const result = await db.transaction(async (tx) => {
    const exec = tx as unknown as Executor;
    const before = await loadGraph(documentId, exec);
    const next = mutate(before);
    const problem = validateGraph(next.graph);
    if (problem) throw new Error(problem);
    const seq = await nextSeq(documentId, exec);
    await saveGraph(documentId, next.graph, exec);
    await exec.insert(transactions).values({
      documentId,
      seq,
      action,
      summary: next.summary,
      before,
      after: next.graph,
    });
    await exec.update(documents).set({ updatedAt: new Date() }).where(eq(documents.id, documentId));
    return { summary: next.summary, focusId: next.focusId ?? null };
  });
  const payload = await buildPayload(documentId);
  if (!payload) throw new Error("Document disappeared during the transaction");
  return { payload, message: result.summary, focusId: result.focusId };
}

export async function undoDocument(documentId: string): Promise<DocumentPayload | null> {
  await db.transaction(async (tx) => {
    const exec = tx as unknown as Executor;
    const [entry] = await exec
      .select()
      .from(transactions)
      .where(and(eq(transactions.documentId, documentId), eq(transactions.undone, false)))
      .orderBy(desc(transactions.seq))
      .limit(1);
    if (!entry) return;
    await saveGraph(documentId, entry.before, exec);
    await exec.update(transactions).set({ undone: true }).where(eq(transactions.id, entry.id));
    await exec.update(documents).set({ updatedAt: new Date() }).where(eq(documents.id, documentId));
  });
  return buildPayload(documentId);
}

export async function redoDocument(documentId: string): Promise<DocumentPayload | null> {
  await db.transaction(async (tx) => {
    const exec = tx as unknown as Executor;
    const [entry] = await exec
      .select()
      .from(transactions)
      .where(and(eq(transactions.documentId, documentId), eq(transactions.undone, true)))
      .orderBy(asc(transactions.seq))
      .limit(1);
    if (!entry) return;
    await saveGraph(documentId, entry.after, exec);
    await exec.update(transactions).set({ undone: false }).where(eq(transactions.id, entry.id));
    await exec.update(documents).set({ updatedAt: new Date() }).where(eq(documents.id, documentId));
  });
  return buildPayload(documentId);
}
