import {
  type AuraEdge,
  type AuraGraph,
  type AuraNode,
  type MathType,
  type NodeKind,
  type PortId,
  catalogNode,
  makeNode,
  newId,
} from "./ontology";
import {
  collapseSelection,
  commitCandidate,
  componentRoot,
  componentsOf,
  expandGroup,
  indexGraph,
  layoutComponent,
  reflowGraph,
} from "./engine";
import { parseLatex } from "./parse";
import { foldConstants } from "./evaluate";
import { LIBRARY_BY_ID } from "./library";
import { applyProposals, type ConnectionPatch } from "./discover";

export interface MutationBody {
  type: string;
  itemId?: string;
  node?: {
    kind?: NodeKind;
    token?: string;
    label?: string;
    type?: MathType;
    variant?: string | null;
  } | null;
  position?: { x: number; y: number } | null;
  positions?: { id: string; x: number; y: number }[];
  candidate?: {
    kind?: string;
    addedNodes: AuraNode[];
    addedEdges: AuraEdge[];
    removedEdgeIds: string[];
    draggedId: string;
    focusId: string;
  } | null;
  ids?: string[];
  id?: string;
  latex?: string;
  candidates?: ConnectionPatch[];
  scale?: number;
}

const KNOWN_KINDS: NodeKind[] = [
  "literal",
  "variable",
  "operator",
  "relation",
  "function",
  "container",
  "set",
  "group",
];

const KNOWN_TYPES: MathType[] = [
  "Scalar",
  "Variable",
  "Vector",
  "Matrix",
  "Set",
  "Expression",
  "Relation",
  "Function",
  "Operator",
  "Unknown",
];

const KNOWN_PORTS: PortId[] = [
  "left",
  "right",
  "base",
  "exponent",
  "subscript",
  "numerator",
  "denominator",
  "lower",
  "upper",
  "body",
  "arg",
];

export interface MutationOutcome {
  graph: AuraGraph;
  summary: string;
  focusId: string | null;
}

export function runMutation(graph: AuraGraph, body: MutationBody): MutationOutcome {
  const ids = new Set(graph.nodes.map((node) => node.id));

  switch (body.type) {
    case "addNode": {
      const position = sanitizePoint(body.position) ?? { x: 600, y: 320 };
      let node: AuraNode | null = body.itemId ? catalogNode(body.itemId, position) : null;
      if (!node && body.itemId) {
        const entry = LIBRARY_BY_ID.get(body.itemId);
        if (entry) {
          node = makeNode({
            kind: entry.kind,
            token: entry.token,
            label: entry.label,
            type: entry.type,
            variant: entry.variant,
            x: position.x,
            y: position.y,
          });
        }
      }
      if (!node && body.node) {
        const raw = body.node;
        if (!raw.kind || !KNOWN_KINDS.includes(raw.kind)) throw new Error("Unknown vertex kind");
        if (!raw.token) throw new Error("A vertex needs a token");
        node = makeNode({
          kind: raw.kind,
          token: String(raw.token).slice(0, 80),
          label: String(raw.label ?? raw.token).slice(0, 80),
          type: raw.type && KNOWN_TYPES.includes(raw.type) ? raw.type : "Expression",
          variant: raw.variant ?? null,
          x: position.x,
          y: position.y,
        });
      }
      if (!node) throw new Error("Unknown element in the palette");
      if (ids.has(node.id)) node = { ...node, id: newId() };
      return {
        graph: { nodes: [...graph.nodes, node], edges: graph.edges },
        summary: `Placed ${node.label}`,
        focusId: node.id,
      };
    }

    case "move": {
      const updates = new Map<string, { x: number; y: number }>();
      for (const entry of body.positions ?? []) {
        if (!ids.has(entry.id)) continue;
        const point = sanitizePoint(entry);
        if (point) updates.set(entry.id, point);
      }
      if (updates.size === 0) throw new Error("No vertices to move");
      return {
        graph: {
          nodes: graph.nodes.map((node) => {
            const point = updates.get(node.id);
            return point ? { ...node, x: point.x, y: point.y } : node;
          }),
          edges: graph.edges,
        },
        summary: `Repositioned ${updates.size} ${updates.size === 1 ? "vertex" : "vertices"}`,
        focusId: Array.from(updates.keys())[0] ?? null,
      };
    }

    case "connect": {
      const candidate = body.candidate;
      if (!candidate) throw new Error("Missing connection candidate");
      const addedNodes = (candidate.addedNodes ?? []).map((node) =>
        makeNode({
          ...node,
          x: Number.isFinite(node.x) ? node.x : 0,
          y: Number.isFinite(node.y) ? node.y : 0,
        }),
      );
      for (const node of addedNodes) {
        if (ids.has(node.id)) throw new Error("Connection candidate collides with an existing vertex");
      }
      const available = new Set([...ids, ...addedNodes.map((node) => node.id)]);
      const addedEdges = (candidate.addedEdges ?? [])
        .filter((edge) => knownPort(edge.port) && available.has(edge.source) && available.has(edge.target))
        .map((edge) => ({ ...edge, id: edge.id || newId() }));
      if (addedEdges.length === 0) throw new Error("Connection candidate has no valid bindings");
      const removed = (candidate.removedEdgeIds ?? []).filter((edgeId) =>
        graph.edges.some((edge) => edge.id === edgeId),
      );
      const merged = commitCandidate(graph, {
        addedNodes,
        addedEdges,
        removedEdgeIds: removed,
        draggedId: candidate.draggedId,
        focusId: candidate.focusId,
      });
      const index = indexGraph(merged);
      const root = componentRoot(index, candidate.focusId) ?? index.byId.get(candidate.focusId);
      return {
        graph: merged,
        summary: `Committed ${candidate.kind === "relation" ? "relation" : "binding"} — ${addedEdges.length} port${addedEdges.length === 1 ? "" : "s"} bound`,
        focusId: root?.id ?? candidate.focusId,
      };
    }

    case "delete": {
      const remove = new Set(body.ids ?? []);
      if (remove.size === 0) throw new Error("Nothing selected");
      const nodes = graph.nodes.filter((node) => !remove.has(node.id));
      const edges = graph.edges.filter((edge) => !remove.has(edge.source) && !remove.has(edge.target));
      if (nodes.length === graph.nodes.length) throw new Error("Nothing selected");
      return {
        graph: { nodes, edges },
        summary: `Deleted ${graph.nodes.length - nodes.length} ${graph.nodes.length - nodes.length === 1 ? "vertex" : "vertices"}`,
        focusId: null,
      };
    }

    case "collapse": {
      const result = collapseSelection(graph, body.ids ?? []);
      if (!result) throw new Error("Select vertices to collapse");
      return {
        graph: result.graph,
        summary: `Collapsed ${(body.ids ?? []).length} vertices into one expression vertex`,
        focusId: result.groupId,
      };
    }

    case "expand": {
      if (!body.id) throw new Error("Missing group id");
      const expanded = expandGroup(graph, body.id);
      if (!expanded) throw new Error("That vertex is not a collapsed expression");
      return { graph: expanded, summary: "Expanded collapsed expression", focusId: body.id };
    }

    case "reflow": {
      const next = reflowGraph(graph);
      return { graph: next, summary: "Auto-laid out connected components", focusId: body.ids?.[0] ?? null };
    }

    case "autoConnect": {
      const candidates = Array.isArray(body.candidates) ? body.candidates : [];
      if (candidates.length === 0) throw new Error("No discovered connections to plug in");
      const result = applyProposals(graph, candidates.slice(0, 40));
      if (result.applied === 0) throw new Error("Every proposal conflicted with the committed graph");
      return {
        graph: result.graph,
        summary: `Plugged in ${result.applied} discovered connection${result.applied === 1 ? "" : "s"}${
          result.skipped > 0 ? ` (${result.skipped} skipped as conflicting)` : ""
        }`,
        focusId: candidates[0]?.focusId ?? null,
      };
    }

    case "simplify": {
      const result = foldConstants(graph);
      if (result.folded === 0) throw new Error("No constant subexpressions to fold");
      const preview = result.summaries.slice(0, 2).join(", ");
      return {
        graph: result.graph,
        summary: `Folded ${result.folded} constant subexpression${result.folded === 1 ? "" : "s"}${
          preview ? ` — ${preview}` : ""
        }`,
        focusId: null,
      };
    }

    case "insertExpression": {
      const latex = (body.latex ?? "").trim();
      if (!latex) throw new Error("Nothing to insert");
      const parsed = parseLatex(latex);
      const position = sanitizePoint(body.position) ?? { x: 620, y: 320 };
      const index = indexGraph(parsed.graph);
      const components = componentsOf(parsed.graph);
      const positions = new Map<string, { x: number; y: number }>();
      components.forEach((component, offset) => {
        const anchor = { x: position.x, y: position.y + offset * 130 };
        const layout = layoutComponent(parsed.graph, component.rootId, anchor, index);
        for (const [id, point] of layout) positions.set(id, point);
      });
      const addedNodes = parsed.graph.nodes.map((node) => {
        const point = positions.get(node.id);
        return point ? { ...node, x: point.x, y: point.y } : node;
      });
      return {
        graph: {
          nodes: [...graph.nodes, ...addedNodes],
          edges: [...graph.edges, ...parsed.graph.edges],
        },
        summary: `Materialised ${parsed.nodeCount} vertices from recognition`,
        focusId: parsed.rootId,
      };
    }

    default:
      throw new Error(`Unknown mutation type ${body.type}`);
  }
}

function knownPort(port: string): port is PortId {
  return KNOWN_PORTS.includes(port as PortId);
}

function sanitizePoint(point: { x?: unknown; y?: unknown } | null | undefined): { x: number; y: number } | null {
  if (!point) return null;
  const x = Number(point.x);
  const y = Number(point.y);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
  return { x: Math.max(-40000, Math.min(40000, x)), y: Math.max(-40000, Math.min(40000, y)) };
}
