/**
 * Aura graph kernel.
 *
 * A document is a typed hypergraph H = (V, E, τ). Edges bind a port of a
 * binder vertex to a bound vertex. Everything here is pure: the same functions
 * run on the server (commit, persistence, export) and in the browser (drag
 * affordances, ghost paths, semantic zoom).
 */

import {
  ACCENT_VARIANTS,
  BIG_VARIANTS,
  ENCLOSURE_VARIANTS,
  MATRIX_VARIANTS,
  OPERAND_TYPES,
  POSTFIX_VARIANTS,
  PREFIX_VARIANTS,
  type AuraEdge,
  type AuraGraph,
  type AuraNode,
  type Diagnostic,
  type GhostPath,
  type MathType,
  type PortDef,
  type PortId,
  GHOST_COLORS,
  admits,
  estimateWidth,
  findPort,
  isOperandLike,
  isShareable,
  newId,
  portsFor,
  tileHeight,
} from "./ontology";

const GAP = 14;
const TIGHT = 8;

export interface GraphIndex {
  byId: Map<string, AuraNode>;
  children: Map<string, Map<PortId, AuraEdge>>;
  parent: Map<string, AuraEdge>;
  edgeById: Map<string, AuraEdge>;
}

export function indexGraph(graph: AuraGraph): GraphIndex {
  const byId = new Map(graph.nodes.map((node) => [node.id, node]));
  const children = new Map<string, Map<PortId, AuraEdge>>();
  const parent = new Map<string, AuraEdge>();
  const edgeById = new Map<string, AuraEdge>();
  for (const edge of graph.edges) {
    edgeById.set(edge.id, edge);
    if (!byId.has(edge.source) || !byId.has(edge.target)) continue;
    const slots = children.get(edge.source) ?? new Map<PortId, AuraEdge>();
    slots.set(edge.port, edge);
    children.set(edge.source, slots);
    parent.set(edge.target, edge);
  }
  return { byId, children, parent, edgeById };
}

export function childOf(index: GraphIndex, nodeId: string, port: PortId): AuraNode | undefined {
  const edge = index.children.get(nodeId)?.get(port);
  return edge ? index.byId.get(edge.target) : undefined;
}

export function childrenOf(index: GraphIndex, nodeId: string): Map<PortId, AuraNode> {
  const out = new Map<PortId, AuraNode>();
  const slots = index.children.get(nodeId);
  if (!slots) return out;
  for (const [port, edge] of slots) {
    const node = index.byId.get(edge.target);
    if (node) out.set(port, node);
  }
  return out;
}

export function openPorts(index: GraphIndex, node: AuraNode): PortDef[] {
  const occupied = index.children.get(node.id);
  return portsFor(node).filter((port) => !occupied?.has(port.id));
}

export function subtreeIds(index: GraphIndex, nodeId: string, visiting = new Set<string>()): Set<string> {
  const out = new Set<string>();
  if (visiting.has(nodeId)) return out;
  visiting.add(nodeId);
  out.add(nodeId);
  const slots = index.children.get(nodeId);
  if (slots) {
    for (const edge of slots.values()) {
      for (const id of subtreeIds(index, edge.target, visiting)) out.add(id);
    }
  }
  return out;
}

export function componentIds(graph: AuraGraph, startId: string): Set<string> {
  const seen = new Set<string>([startId]);
  const queue = [startId];
  while (queue.length) {
    const current = queue.shift() as string;
    for (const edge of graph.edges) {
      const other = edge.source === current ? edge.target : edge.target === current ? edge.source : null;
      if (other && !seen.has(other)) {
        seen.add(other);
        queue.push(other);
      }
    }
  }
  return seen;
}

export function componentRoot(index: GraphIndex, nodeId: string): AuraNode | undefined {
  let current = index.byId.get(nodeId);
  const guard = new Set<string>();
  while (current) {
    if (guard.has(current.id)) return current;
    guard.add(current.id);
    const incoming = index.parent.get(current.id);
    if (!incoming) return current;
    const next = index.byId.get(incoming.source);
    if (!next) return current;
    current = next;
  }
  return undefined;
}

export function rootsOf(graph: AuraGraph): AuraNode[] {
  const index = indexGraph(graph);
  return graph.nodes.filter((node) => !index.parent.has(node.id));
}

export function componentsOf(graph: AuraGraph): { rootId: string; nodeIds: string[] }[] {
  const seen = new Set<string>();
  const out: { rootId: string; nodeIds: string[] }[] = [];
  const index = indexGraph(graph);
  for (const node of graph.nodes) {
    if (seen.has(node.id)) continue;
    const ids = componentIds(graph, node.id);
    ids.forEach((id) => seen.add(id));
    const root = componentRoot(index, node.id) ?? node;
    out.push({ rootId: root.id, nodeIds: Array.from(ids) });
  }
  return out.sort((a, b) => {
    const na = index.byId.get(a.rootId);
    const nb = index.byId.get(b.rootId);
    return (na?.x ?? 0) - (nb?.x ?? 0);
  });
}

/* ------------------------------------------------------------------ */
/* Latex serialisation                                                 */
/* ------------------------------------------------------------------ */

function precedenceOf(node: AuraNode): number {
  if (node.kind === "relation") return 1;
  if (node.kind === "operator") {
    if (node.variant && (POSTFIX_VARIANTS.has(node.variant) || PREFIX_VARIANTS.has(node.variant))) return 6;
    if (node.variant === "binom") return 6;
    if (node.variant === "add" || node.variant === "sub") return 2;
    if (node.variant === "mul" || node.variant === "juxta") return 3;
    if (node.variant === "frac") return 6;
    if (node.variant === "power") return 5;
    return 3;
  }
  if (node.kind === "container" && (node.variant === "int" || node.variant === "sum")) return 2;
  return 6;
}

const OP_LATEX: Record<string, string> = {
  add: "+",
  sub: "-",
  mul: "\\times",
  juxta: "\\,",
};

export function toLatex(graph: AuraGraph, rootId: string, index = indexGraph(graph)): string {
  return renderLatex(rootId, index, new Set<string>(), 0);
}

function renderLatex(
  nodeId: string,
  index: GraphIndex,
  visiting: Set<string>,
  parentPrecedence: number,
): string {
  const node = index.byId.get(nodeId);
  if (!node) return "\\square";
  if (visiting.has(nodeId)) return "\\square";
  if (node.kind === "group") {
    const inner = typeof node.meta?.latex === "string" ? node.meta.latex : node.token;
    return `\\left(${inner}\\right)`;
  }
  const next = new Set(visiting).add(nodeId);
  const slot = (port: PortId, prec = 0, fallback = "\\square"): string => {
    const child = childOf(index, nodeId, port);
    return child ? renderLatex(child.id, index, next, prec) : fallback;
  };
  const suffix = (base: string): string => {
    const exp = childOf(index, nodeId, "exponent");
    const sub = childOf(index, nodeId, "subscript");
    let tex = base;
    if (sub) tex += `_{${renderLatex(sub.id, index, next, 0)}}`;
    if (exp) tex += `^{${renderLatex(exp.id, index, next, 0)}}`;
    return tex;
  };

  let prec = 6;
  let tex = "";

  switch (node.kind) {
    case "operator": {
      if (node.variant === "power") {
        prec = 5;
        tex = `{${slot("base", 6)}}^{${slot("exponent", 6)}}`;
      } else if (node.variant === "frac") {
        prec = 6;
        tex = `\\frac{${slot("numerator")}}{${slot("denominator")}}`;
      } else {
        prec = precedenceOf(node);
        const left = slot("left", prec);
        const right = slot("right", prec + 1);
        if (node.variant === "juxta") tex = `${left}\\,${right}`;
        else tex = `${left} ${OP_LATEX[node.variant ?? "add"] ?? node.token} ${right}`;
      }
      break;
    }
    case "relation": {
      prec = 1;
      const left = slot("left", 2);
      const right = slot("right", 2);
      tex = `${left} ${node.token} ${right}`;
      break;
    }
    case "function": {
      prec = 6;
      const arg = childOf(index, nodeId, "arg");
      const name = node.token;
      tex = arg
        ? `${name}\\left(${renderLatex(arg.id, index, next, 0)}\\right)`
        : `${name}\\left(\\square\\right)`;
      break;
    }
    case "container": {
      if (node.variant === "sqrt") {
        tex = `\\sqrt{${slot("body")}}`;
      } else if (node.variant === "int" || node.variant === "sum") {
        prec = 2;
        const lower = childOf(index, nodeId, "lower");
        const upper = childOf(index, nodeId, "upper");
        const limits = `${lower ? `_{${renderLatex(lower.id, index, next, 0)}}` : ""}${
          upper ? `^{${renderLatex(upper.id, index, next, 0)}}` : ""
        }`;
        const sign = node.variant === "int" ? "\\int" : "\\sum";
        tex = `${sign}${limits} ${slot("body", 2)}`;
      } else {
        tex = `\\left(${slot("body")}\\right)`;
      }
      break;
    }
    default: {
      tex = suffix(node.token || "\\square");
      break;
    }
  }

  // Symbol-library families render from their variant, not from the tile glyph.
  const variant = node.variant ?? "";
  if (node.kind === "operator" && POSTFIX_VARIANTS.has(variant)) {
    const arg = childOf(index, nodeId, "arg");
    const inner = arg ? renderLatex(arg.id, index, next, 6) : "\\square";
    const wrapped = arg && precedenceOf(arg) < 6 ? `\\left(${inner}\\right)` : inner;
    switch (variant) {
      case "transpose":
        tex = `{${wrapped}}^{\\top}`;
        break;
      case "inverse":
        tex = `{${wrapped}}^{-1}`;
        break;
      case "conj":
        tex = `\\overline{${wrapped}}`;
        break;
      case "prime":
        tex = `{${wrapped}}^{\\prime}`;
        break;
      case "doubleprime":
        tex = `{${wrapped}}^{\\prime\\prime}`;
        break;
      case "degree":
        tex = `{${wrapped}}^{\\circ}`;
        break;
      case "complement":
        tex = `{${wrapped}}^{c}`;
        break;
      default:
        tex = `${wrapped}!`;
        break;
    }
    prec = 6;
  } else if (node.kind === "operator" && PREFIX_VARIANTS.has(variant)) {
    const arg = childOf(index, nodeId, "arg");
    const inner = arg ? renderLatex(arg.id, index, next, 6) : "\\square";
    const marker: Record<string, string> = {
      neg: "\\neg",
      forall: "\\forall",
      exists: "\\exists",
      nabla: "\\nabla",
      partial: "\\partial",
    };
    tex = `${marker[variant] ?? node.token} ${inner}`;
    prec = 6;
  } else if (node.kind === "operator" && variant === "binom") {
    tex = `\\binom{${slot("numerator")}}{${slot("denominator")}}`;
    prec = 6;
  } else if (node.kind === "operator" && (variant === "floor" || variant === "ceil")) {
    const arg = childOf(index, nodeId, "arg");
    const inner = arg ? renderLatex(arg.id, index, next, 0) : "\\square";
    tex = variant === "floor" ? `\\lfloor ${inner} \\rfloor` : `\\lceil ${inner} \\rceil`;
    prec = 6;
  } else if (node.kind === "operator" && (variant === "abs" || variant === "norm")) {
    const arg = childOf(index, nodeId, "arg");
    const inner = arg ? renderLatex(arg.id, index, next, 0) : "\\square";
    tex = variant === "abs" ? `\\left|${inner}\\right|` : `\\left\\|${inner}\\right\\|`;
    prec = 6;
  } else if (node.kind === "operator" && (variant === "pm" || variant === "mp")) {
    tex = `${slot("left", 2)} ${node.token} ${slot("right", 3)}`;
    prec = 2;
  } else if (node.kind === "container" && ACCENT_VARIANTS.has(variant)) {
    tex = `\\${variant}{${slot("body")}}`;
    prec = 6;
  } else if (node.kind === "container" && MATRIX_VARIANTS.has(variant)) {
    tex = `\\begin{${variant}}{${slot("body")}}\\end{${variant}}`;
    prec = 6;
  } else if (node.kind === "container" && ENCLOSURE_VARIANTS.has(variant)) {
    const inner = slot("body");
    tex =
      variant === "abs"
        ? `\\left|${inner}\\right|`
        : variant === "norm"
          ? `\\left\\|${inner}\\right\\|`
          : variant === "floor"
            ? `\\lfloor ${inner} \\rfloor`
            : `\\lceil ${inner} \\rceil`;
    prec = 6;
  } else if (node.kind === "container" && variant === "root") {
    const indexNode = childOf(index, nodeId, "upper");
    tex = indexNode
      ? `\\sqrt[${renderLatex(indexNode.id, index, next, 0)}]{${slot("body")}}`
      : `\\sqrt{${slot("body")}}`;
    prec = 6;
  } else if (node.kind === "container" && BIG_VARIANTS.has(variant)) {
    const lower = childOf(index, nodeId, "lower");
    const upper = childOf(index, nodeId, "upper");
    const signMap: Record<string, string> = {
      sum: "\\sum",
      prod: "\\prod",
      coprod: "\\coprod",
      int: "\\int",
      iint: "\\iint",
      iiint: "\\iiint",
      oint: "\\oint",
      lim: "\\lim",
      limsup: "\\limsup",
      liminf: "\\liminf",
      sup: "\\sup",
      inf: "\\inf",
      max: "\\max",
      min: "\\min",
      bigcup: "\\bigcup",
      bigcap: "\\bigcap",
      bigoplus: "\\bigoplus",
      bigotimes: "\\bigotimes",
      det: "\\det",
      gcd: "\\gcd",
      argmin: "\\arg\\min",
      argmax: "\\arg\\max",
      span: "\\operatorname{span}",
    };
    const sign = signMap[variant] ?? node.token;
    const limits = (lower ? `_{${renderLatex(lower.id, index, next, 0)}}` : "") +
      (upper ? `^{${renderLatex(upper.id, index, next, 0)}}` : "");
    const body = childOf(index, nodeId, "body");
    tex = `${sign}${limits}${body ? ` ${renderLatex(body.id, index, next, 2)}` : ""}`;
    prec = 2;
  }

  if (prec < parentPrecedence) return `\\left(${tex}\\right)`;
  return tex;
}

export function documentLatex(graph: AuraGraph): { rootId: string; latex: string; nodeIds: string[] }[] {
  const index = indexGraph(graph);
  return componentsOf(graph).map((component) => ({
    rootId: component.rootId,
    latex: toLatex(graph, component.rootId, index),
    nodeIds: component.nodeIds,
  }));
}

/* ------------------------------------------------------------------ */
/* Type propagation & diagnostics                                     */
/* ------------------------------------------------------------------ */

export function effectiveType(index: GraphIndex, nodeId: string, cache = new Map<string, MathType>()): MathType {
  const cached = cache.get(nodeId);
  if (cached) return cached;
  const node = index.byId.get(nodeId);
  if (!node) return "Unknown";
  cache.set(nodeId, node.type);
  const type = computeType(index, node, cache);
  cache.set(nodeId, type);
  return type;
}

function childType(index: GraphIndex, nodeId: string, port: PortId, cache: Map<string, MathType>): MathType | null {
  const child = childOf(index, nodeId, port);
  return child ? effectiveType(index, child.id, cache) : null;
}

function computeType(index: GraphIndex, node: AuraNode, cache: Map<string, MathType>): MathType {
  switch (node.kind) {
    case "literal":
    case "variable":
    case "set":
      // Leaf vertices keep their declared type so Matrix/Vector/Set symbols
      // participate in type propagation rather than degrading to Variable.
      return node.type && node.type !== "Unknown" ? node.type : "Variable";
    case "group":
      return "Expression";
    case "relation":
      return "Relation";
    case "function": {
      const arg = childType(index, node.id, "arg", cache);
      return arg ? "Expression" : "Function";
    }
    case "container":
      return "Expression";
    case "operator": {
      if (node.variant === "power") {
        const base = childType(index, node.id, "base", cache);
        const exp = childType(index, node.id, "exponent", cache);
        if (!base || !exp) return "Expression";
        if (base === "Matrix" || exp === "Matrix") return "Matrix";
        if (base === "Set" || exp === "Set") return "Set";
        if (base === "Expression" || exp === "Expression" || base === "Vector") return "Expression";
        return "Scalar";
      }
      const parts = ["left", "right"].map((port) =>
        childType(index, node.id, port as PortId, cache),
      );
      if (node.variant === "frac") {
        const num = childType(index, node.id, "numerator", cache);
        const den = childType(index, node.id, "denominator", cache);
        if (num === "Matrix" || den === "Matrix") return "Expression";
        if (num === "Set" || den === "Set") return "Set";
        if (num && den && num !== "Expression" && den !== "Expression") return "Scalar";
        return "Expression";
      }
      if (parts.some((part) => part === "Matrix")) return "Matrix";
      if (parts.some((part) => part === "Vector")) return "Vector";
      if (parts.some((part) => part === "Set")) return "Set";
      if (parts.some((part) => part === "Relation")) return "Relation";
      if (parts.every((part) => part === "Scalar" || part === "Variable")) return "Scalar";
      return "Expression";
    }
    default:
      return node.type;
  }
}

export function diagnose(graph: AuraGraph): Diagnostic[] {
  const index = indexGraph(graph);
  const out: Diagnostic[] = [];
  const cache = new Map<string, MathType>();

  for (const node of graph.nodes) {
    const incoming = graph.edges.filter((edge) => edge.target === node.id);
    if (incoming.length > 1 && !isShareable(node)) {
      out.push({
        nodeId: node.id,
        edgeId: incoming[1]?.id ?? null,
        severity: "error",
        message: `${node.label} is bound in ${incoming.length} places — a vertex can only serve one port.`,
      });
    }
  }

  // Cycle detection
  const state = new Map<string, 0 | 1 | 2>();
  const visit = (id: string): boolean => {
    const status = state.get(id) ?? 0;
    if (status === 1) return true;
    if (status === 2) return false;
    state.set(id, 1);
    const slots = index.children.get(id);
    if (slots) {
      for (const edge of slots.values()) {
        if (visit(edge.target)) {
          state.set(id, 2);
          return true;
        }
      }
    }
    state.set(id, 2);
    return false;
  };
  for (const node of graph.nodes) {
    if (visit(node.id)) {
      out.push({
        nodeId: node.id,
        severity: "error",
        message: "Cyclic binding detected — the expression cannot be evaluated.",
      });
    }
  }

  for (const node of graph.nodes) {
    const portDefs = portsFor(node);
    const slots = index.children.get(node.id);
    for (const port of portDefs) {
      if (port.required && !slots?.has(port.id)) {
        out.push({
          nodeId: node.id,
          severity: "warning",
          message: `${node.label}: ${port.label.toLowerCase()} is still open.`,
        });
      }
    }

    for (const [portId, edge] of slots ?? []) {
      const def = findPort(node, portId);
      const child = index.byId.get(edge.target);
      if (!def || !child) continue;
      const childType = effectiveType(index, child.id, cache);
      if (!admits(def.accepts, childType).ok) {
        out.push({
          nodeId: node.id,
          edgeId: edge.id,
          severity: "error",
          message: `${child.label} has type ${childType}, but ${portId.replace(/-/g, " ")} accepts ${def.accepts.join(" | ")}.`,
        });
      }
      if (childType === "Relation") {
        out.push({
          nodeId: node.id,
          edgeId: edge.id,
          severity: "error",
          message: "A relation cannot be nested directly inside another expression — wrap it in a group.",
        });
      }
    }

    if (node.kind === "operator" && (node.variant === "add" || node.variant === "sub" || node.variant === "mul" || node.variant === "frac")) {
      const types = (node.variant === "frac"
        ? [childType(index, node.id, "numerator", cache), childType(index, node.id, "denominator", cache)]
        : [childType(index, node.id, "left", cache), childType(index, node.id, "right", cache)]
      ).filter(Boolean) as MathType[];
      if (types.some((type) => type === "Set")) {
        out.push({
          nodeId: node.id,
          severity: "error",
          message: "Set arithmetic is not defined for this operator. Use set operations instead.",
        });
      } else if (types.includes("Matrix") && types.some((type) => type === "Scalar" || type === "Variable")) {
        out.push({
          nodeId: node.id,
          severity: "error",
          message: "Scalar and Matrix cannot be combined element-wise here — the operation is ill-typed.",
        });
      }
    }

    if (node.kind === "operator" && node.variant === "power") {
      const exponent = childType(index, node.id, "exponent", cache);
      if (exponent === "Set" || exponent === "Relation") {
        out.push({
          nodeId: node.id,
          severity: "error",
          message: `Exponent expects a Scalar, received ${exponent}.`,
        });
      }
    }

    if (node.kind === "relation") {
      const left = childType(index, node.id, "left", cache);
      const right = childType(index, node.id, "right", cache);
      if (node.variant === "in" || node.variant === "subset") {
        if (right && right !== "Set" && right !== "Expression") {
          out.push({
            nodeId: node.id,
            severity: "error",
            message: `Membership needs a Set on the right, received ${right}.`,
          });
        }
      } else if ((left === "Set" && right && right !== "Set") || (right === "Set" && left && left !== "Set")) {
        out.push({
          nodeId: node.id,
          severity: "warning",
          message: "Comparing a Set with a scalar expression — check the intended relation.",
        });
      }
    }
  }

  return out;
}

export function diagnosticsByNode(diagnostics: Diagnostic[]): Record<string, Diagnostic[]> {
  const out: Record<string, Diagnostic[]> = {};
  for (const entry of diagnostics) {
    out[entry.nodeId] = [...(out[entry.nodeId] ?? []), entry];
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* Layout: expression tiles arranged from graph structure              */
/* ------------------------------------------------------------------ */

interface Metrics {
  width: number;
  ownX: number;
  positions: Map<string, { x: number; y: number }>;
}

const EMPTY: Metrics = { width: 0, ownX: 0, positions: new Map() };

interface LayoutCtx {
  index: GraphIndex;
  seen: Set<string>;
}

function measure(nodeId: string, ctx: LayoutCtx): Metrics {
  const node = ctx.index.byId.get(nodeId);
  if (!node) return EMPTY;
  if (ctx.seen.has(nodeId)) return EMPTY;
  const width = estimateWidth(node);
  const seen = new Set(ctx.seen).add(nodeId);
  const sub = (port: PortId): Metrics => {
    const edge = ctx.index.children.get(nodeId)?.get(port);
    return edge ? measure(edge.target, { index: ctx.index, seen }) : EMPTY;
  };
  const positions = new Map<string, { x: number; y: number }>();
  const put = (metrics: Metrics, dx: number, dy: number) => {
    for (const [id, point] of metrics.positions) {
      positions.set(id, { x: point.x + dx, y: point.y + dy });
    }
  };
  const own = (x: number, y = 0) => positions.set(nodeId, { x, y });

  const nodeVariant = node.variant ?? "";

  if (node.kind === "operator" && POSTFIX_VARIANTS.has(nodeVariant)) {
    const arg = sub("arg");
    own(arg.width + 10, 0);
    put(arg, 0, 0);
    return { width: arg.width + 18, ownX: arg.width + 10, positions };
  }
  if (node.kind === "operator" && PREFIX_VARIANTS.has(nodeVariant)) {
    const arg = sub("arg");
    own(6, 0);
    put(arg, 16, 0);
    return { width: 16 + arg.width, ownX: 6, positions };
  }
  if (node.kind === "operator" && nodeVariant === "binom") {
    const upper = sub("numerator");
    const lower = sub("denominator");
    const total = Math.max(upper.width, lower.width, 40);
    own(total / 2, 0);
    put(upper, (total - upper.width) / 2, -28);
    put(lower, (total - lower.width) / 2, 28);
    return { width: total, ownX: total / 2, positions };
  }
  if (node.kind === "container" && ACCENT_VARIANTS.has(nodeVariant)) {
    const body = sub("body");
    own(14, 0);
    put(body, 22, 0);
    return { width: body.width + 22, ownX: 14, positions };
  }
  if (node.kind === "container" && MATRIX_VARIANTS.has(nodeVariant)) {
    const body = sub("body");
    own(width / 2, 0);
    put(body, width + TIGHT, 0);
    return { width: width + TIGHT + body.width, ownX: width / 2, positions };
  }
  if (node.kind === "container" && ENCLOSURE_VARIANTS.has(nodeVariant)) {
    const body = sub("body");
    own(width / 2, 0);
    put(body, width + TIGHT, 0);
    return { width: width + TIGHT + body.width, ownX: width / 2, positions };
  }

  switch (node.kind) {
    case "operator": {
      if (node.variant === "frac") {
        const num = sub("numerator");
        const den = sub("denominator");
        const total = Math.max(num.width, den.width, 52);
        own(total / 2, 0);
        put(num, (total - num.width) / 2, -44);
        put(den, (total - den.width) / 2, 44);
        return { width: total, ownX: total / 2, positions };
      }
      if (node.variant === "power") {
        const base = sub("base");
        const exp = sub("exponent");
        const expScale = 0.78;
        const expWidth = Math.max(exp.width, 20) * expScale;
        own(base.width + 8, -12);
        put(base, 0, 0);
        put(exp, base.width + 12, -36);
        return { width: base.width + 12 + expWidth, ownX: base.width + 8, positions };
      }
      const left = sub("left");
      const right = sub("right");
      const total = left.width + GAP + width + GAP + right.width;
      own(left.width + GAP + width / 2, 0);
      put(left, 0, 0);
      put(right, left.width + GAP + width + GAP, 0);
      return { width: total, ownX: left.width + GAP + width / 2, positions };
    }
    case "relation": {
      const left = sub("left");
      const right = sub("right");
      const total = left.width + GAP + width + GAP + right.width;
      own(left.width + GAP + width / 2, 0);
      put(left, 0, 0);
      put(right, left.width + GAP + width + GAP, 0);
      return { width: total, ownX: left.width + GAP + width / 2, positions };
    }
    case "function": {
      const arg = sub("arg");
      own(width / 2, 0);
      put(arg, width + TIGHT, 0);
      return { width: width + TIGHT + arg.width, ownX: width / 2, positions };
    }
    case "container": {
      if (node.variant && BIG_VARIANTS.has(node.variant)) {
        const lower = sub("lower");
        const upper = sub("upper");
        const body = sub("body");
        const limits = Math.max(lower.width, upper.width, 22);
        own(width / 2, 0);
        put(upper, width + 2, -38);
        put(lower, width + 2, 34);
        put(body, width + limits - 12 + GAP, 0);
        return {
          width: Math.max(width + limits + GAP + body.width - 12, width + limits),
          ownX: width / 2,
          positions,
        };
      }
      const body = sub("body");
      own(width / 2, 0);
      put(body, width + TIGHT, 0);
      return { width: width + TIGHT + body.width, ownX: width / 2, positions };
    }
    default: {
      const exp = sub("exponent");
      const ssub = sub("subscript");
      const expWidth = exp.width ? exp.width * 0.78 : 0;
      const subWidth = ssub.width ? ssub.width * 0.7 : 0;
      own(width / 2, 0);
      if (exp.width) put(exp, width + 2, -34);
      if (ssub.width) put(ssub, width + 2, 30);
      return {
        width: width + Math.max(expWidth, subWidth, 0),
        ownX: width / 2,
        positions,
      };
    }
  }
}

export function layoutComponent(
  graph: AuraGraph,
  rootId: string,
  anchor: { x: number; y: number },
  index = indexGraph(graph),
): Map<string, { x: number; y: number }> {
  const metrics = measure(rootId, { index, seen: new Set<string>() });
  const dx = anchor.x - metrics.ownX;
  const dy = anchor.y;
  const out = new Map<string, { x: number; y: number }>();
  for (const [id, point] of metrics.positions) {
    out.set(id, { x: Math.round(point.x + dx), y: Math.round(point.y + dy) });
  }
  return out;
}

/** Re-flow every connected component around its current root anchor. */
export function reflowGraph(graph: AuraGraph, anchorFor?: (rootId: string) => { x: number; y: number }): AuraGraph {
  const index = indexGraph(graph);
  const positions = new Map<string, { x: number; y: number }>();
  for (const component of componentsOf(graph)) {
    const root = index.byId.get(component.rootId);
    if (!root) continue;
    const anchor = anchorFor?.(component.rootId) ?? { x: root.x, y: root.y };
    for (const [id, point] of layoutComponent(graph, component.rootId, anchor, index)) {
      positions.set(id, point);
    }
  }
  return {
    ...graph,
    nodes: graph.nodes.map((node) => {
      const point = positions.get(node.id);
      return point ? { ...node, x: point.x, y: point.y } : node;
    }),
  };
}

export function portAnchor(node: AuraNode, port: PortDef): { x: number; y: number } {
  const width = estimateWidth(node);
  const height = tileHeight();
  switch (port.side) {
    case "left":
      return { x: node.x - width / 2, y: node.y };
    case "right":
      return { x: node.x + width / 2, y: node.y };
    case "top":
      return { x: node.x, y: node.y - height / 2 };
    case "bottom":
      return { x: node.x, y: node.y + height / 2 };
    case "topright":
      return { x: node.x + width / 2 - 4, y: node.y - height / 2 + 6 };
    case "bottomright":
      return { x: node.x + width / 2 - 4, y: node.y + height / 2 - 6 };
    case "righttop":
      return { x: node.x + width / 2, y: node.y - 12 };
    case "rightbottom":
      return { x: node.x + width / 2, y: node.y + 12 };
    default:
      return { x: node.x, y: node.y };
  }
}

export function outAnchor(node: AuraNode): { x: number; y: number } {
  return { x: node.x + estimateWidth(node) / 2, y: node.y };
}

/* ------------------------------------------------------------------ */
/* Connection engine                                                  */
/* ------------------------------------------------------------------ */

function withChanges(
  graph: AuraGraph,
  addedNodes: AuraNode[],
  addedEdges: AuraEdge[],
  removedEdgeIds: string[],
): AuraGraph {
  const removed = new Set(removedEdgeIds);
  return {
    nodes: [...graph.nodes, ...addedNodes],
    edges: [...graph.edges.filter((edge) => !removed.has(edge.id)), ...addedEdges],
  };
}

const RELATION_TEMPLATES = [
  {
    variant: "equal",
    token: "=",
    label: "Equality",
    title: "Relate as equality",
    weight: 1,
    kind: "relation" as const,
  },
  {
    variant: "mapsto",
    token: "\\to",
    label: "Mapping",
    title: "Map one onto the other",
    weight: 0.84,
    kind: "relation" as const,
  },
  {
    variant: "juxta",
    token: "\\,",
    label: "Juxtaposition",
    title: "Bind as a product",
    weight: 0.72,
    kind: "operator" as const,
  },
];

export interface CandidateOptions {
  radius?: number;
  limit?: number;
}

/**
 * Homeomorphic connection candidates: only ports inside a local radius are
 * considered, type admissibility prunes first, then proximity / arity / type
 * exactness score the survivors. Never enumerates globally.
 */
export function findCandidates(
  graph: AuraGraph,
  draggedId: string,
  pointer: { x: number; y: number },
  options: CandidateOptions = {},
): GhostPath[] {
  const index = indexGraph(graph);
  const dragged = index.byId.get(draggedId);
  if (!dragged) return [];
  const radius = options.radius ?? 340;
  const limit = options.limit ?? 4;
  const subtree = subtreeIds(index, draggedId);
  const draggedType = effectiveType(index, draggedId);
  const draggedParent = index.parent.get(draggedId);

  const near = graph.nodes.filter((node) => {
    if (subtree.has(node.id)) return false;
    return Math.hypot(node.x - pointer.x, node.y - pointer.y) <= radius;
  });

  const candidates: Omit<GhostPath, "color">[] = [];

  const describe = (node: AuraNode) => node.label;

  // 1. Fill an open port of a nearby binder.
  for (const target of near) {
    const targetRoot = componentRoot(index, target.id);
    if (!targetRoot) continue;
    for (const portDef of portsFor(target)) {
      if (index.children.get(target.id)?.has(portDef.id)) continue;
      const admission = admits(portDef.accepts, draggedType);
      if (!admission.ok) continue;
      const edge: AuraEdge = {
        id: newId(),
        source: target.id,
        target: draggedId,
        port: portDef.id,
        role: portDef.id,
      };
      const removed = draggedParent ? [draggedParent.id] : [];
      const temp = withChanges(graph, [], [edge], removed);
      const tempIndex = indexGraph(temp);
      const root = componentRoot(tempIndex, target.id) ?? targetRoot;
      const anchor = portAnchor(target, portDef);
      const distance = Math.hypot(target.x - pointer.x, target.y - pointer.y);
      const proximity = Math.max(0, 1 - distance / radius);
      const score = Math.min(
        0.99,
        0.5 * proximity + 0.3 * (admission.exact ? 1 : 0.72) + 0.2 * (portDef.required ? 1 : 0.78),
      );
      candidates.push({
        kind: "port-fill",
        title: `Bind into ${portDef.label.toLowerCase()} of ${describe(target)}`,
        rationale: `${describe(target)} exposes a ${portDef.required ? "required" : "optional"} ${portDef.label.toLowerCase()} port accepting ${portDef.accepts.join(" | ")}; ${describe(dragged)} infers ${draggedType}.`,
        score,
        draggedId,
        targetId: target.id,
        targetPort: portDef.id,
        anchor,
        previewLatex: toLatex(temp, root.id, tempIndex),
        addedNodes: [],
        addedEdges: [edge],
        removedEdgeIds: removed,
        focusId: root.id,
      });
    }
  }

  // 2. New relational binder joining two expression roots.
  if (!draggedParent && isOperandLike(dragged, draggedType)) {
    const roots = new Map<string, AuraNode>();
    for (const target of near) {
      const root = componentRoot(index, target.id);
      if (root && root.id !== draggedId && !subtree.has(root.id)) roots.set(root.id, root);
    }
    for (const root of roots.values()) {
      const rootType = effectiveType(index, root.id);
      if (!isOperandLike(root, rootType)) continue;
      if (
        !admits(OPERAND_TYPES, draggedType).ok ||
        !admits(OPERAND_TYPES, rootType).ok ||
        draggedType === "Set" ||
        rootType === "Set"
      ) {
        continue;
      }
      for (const template of RELATION_TEMPLATES) {
        const binder = makeBinderNode(template, dragged, root);
        const edgeLeft: AuraEdge = {
          id: newId(),
          source: binder.id,
          target: draggedId,
          port: "left",
          role: "left",
        };
        const edgeRight: AuraEdge = {
          id: newId(),
          source: binder.id,
          target: root.id,
          port: "right",
          role: "right",
        };
        const temp = withChanges(graph, [binder], [edgeLeft, edgeRight], []);
        const distance = Math.hypot(root.x - pointer.x, root.y - pointer.y);
        const proximity = Math.max(0, 1 - distance / radius);
        const score = Math.min(0.98, 0.48 * proximity + 0.3 + 0.2 * template.weight);
        candidates.push({
          kind: template.variant === "juxta" ? "product" : "relation",
          title: `${template.title}: ${describe(dragged)} ${template.label.toLowerCase()} ${describe(root)}`,
          rationale: `Inserting a ${template.label.toLowerCase()} vertex is structure-preserving: both sides infer expression-compatible types (${draggedType}, ${rootType}).`,
          score,
          draggedId,
          targetId: root.id,
          targetPort: "left",
          anchor: { x: root.x, y: root.y - 44 },
          previewLatex: toLatex(temp, binder.id, indexGraph(temp)),
          addedNodes: [binder],
          addedEdges: [edgeLeft, edgeRight],
          removedEdgeIds: [],
          focusId: binder.id,
        });
      }
    }
  }

  // 3. The dragged vertex wraps a nearby root in its own open port.
  if (["function", "container", "relation", "operator"].includes(dragged.kind)) {
    const open = openPorts(index, dragged).find((portDef) => {
      if (!portDef.required) return false;
      return near.some((target) => {
        const root = componentRoot(index, target.id);
        if (!root || subtree.has(root.id)) return false;
        if (index.parent.has(root.id)) return false;
        return admits(portDef.accepts, effectiveType(index, root.id)).ok;
      });
    });
    if (open) {
      const targets = new Map<string, AuraNode>();
      for (const target of near) {
        const root = componentRoot(index, target.id);
        if (root && root.id !== draggedId && !subtree.has(root.id) && !index.parent.has(root.id)) {
          targets.set(root.id, root);
        }
      }
      for (const root of targets.values()) {
        if (!admits(open.accepts, effectiveType(index, root.id)).ok) continue;
        if (!isOperandLike(root, effectiveType(index, root.id))) continue;
        const edge: AuraEdge = {
          id: newId(),
          source: draggedId,
          target: root.id,
          port: open.id,
          role: open.id,
        };
        const temp = withChanges(graph, [], [edge], []);
        const tempIndex = indexGraph(temp);
        const distance = Math.hypot(root.x - pointer.x, root.y - pointer.y);
        const proximity = Math.max(0, 1 - distance / radius);
        // The ghost path should visibly land on the cluster that will be bound.
        const anchor = { x: root.x - estimateWidth(root) / 2, y: root.y };
        candidates.push({
          kind: "wrap",
          title: `Apply ${describe(dragged)} to ${describe(root)}`,
          rationale: `${describe(dragged)} has an open ${open.label.toLowerCase()} port accepting ${open.accepts.join(" | ")}.`,
          score: Math.min(0.97, 0.5 * proximity + 0.32 + 0.18),
          draggedId,
          targetId: root.id,
          targetPort: "left",
          anchor,
          previewLatex: toLatex(temp, componentRoot(tempIndex, draggedId)?.id ?? draggedId, tempIndex),
          addedNodes: [],
          addedEdges: [edge],
          removedEdgeIds: [],
          focusId: droppedRootId(index, draggedId),
        });
      }
    }
  }

  const deduped = new Map<string, Omit<GhostPath, "color">>();
  for (const candidate of candidates) {
    const key = `${candidate.targetId}:${candidate.targetPort}:${candidate.addedNodes.map((node) => node.variant).join(",")}`;
    const existing = deduped.get(key);
    if (!existing || existing.score < candidate.score) deduped.set(key, candidate);
  }

  return Array.from(deduped.values())
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((candidate, index2) => ({ ...candidate, color: GHOST_COLORS[index2 % GHOST_COLORS.length] }));
}

function droppedRootId(index: GraphIndex, draggedId: string): string {
  return componentRoot(index, draggedId)?.id ?? draggedId;
}

function makeBinderNode(
  template: (typeof RELATION_TEMPLATES)[number],
  dragged: AuraNode,
  root: AuraNode,
): AuraNode {
  return {
    id: newId(),
    kind: template.kind,
    type: template.kind === "relation" ? "Relation" : "Operator",
    token: template.token,
    label: template.label,
    variant: template.variant,
    x: (dragged.x + root.x) / 2,
    y: (dragged.y + root.y) / 2,
    collapsed: false,
    meta: { insertedByEngine: true },
  };
}

/** Apply a committed candidate and re-flow the merged expression. */
export function commitCandidate(
  graph: AuraGraph,
  candidate: {
    addedNodes: AuraNode[];
    addedEdges: AuraEdge[];
    removedEdgeIds: string[];
    draggedId: string;
    focusId: string;
  },
): AuraGraph {
  const merged = withChanges(graph, candidate.addedNodes, candidate.addedEdges, candidate.removedEdgeIds);
  const index = indexGraph(merged);
  const root = componentRoot(index, candidate.focusId) ?? index.byId.get(candidate.focusId);
  if (!root) return merged;
  const anchor = { x: root.x, y: root.y };
  const positions = layoutComponent(merged, root.id, anchor, index);
  return {
    ...merged,
    nodes: merged.nodes.map((node) => {
      const point = positions.get(node.id);
      return point ? { ...node, x: point.x, y: point.y } : node;
    }),
  };
}

/* ------------------------------------------------------------------ */
/* Collapse / expand                                                   */
/* ------------------------------------------------------------------ */

export interface CollapsedPayload {
  nodes: AuraNode[];
  edges: AuraEdge[];
}

export function collapseSelection(graph: AuraGraph, ids: string[]): { graph: AuraGraph; groupId: string } | null {
  const selected = new Set(ids);
  const nodes = graph.nodes.filter((node) => selected.has(node.id));
  if (nodes.length === 0) return null;
  const index = indexGraph(graph);
  const rootId = nodes
    .map((node) => componentRoot(index, node.id)?.id)
    .find((id): id is string => Boolean(id && selected.has(id))) ?? nodes[0].id;
  const latex = toLatex(graph, rootId, index);
  const innerEdges = graph.edges.filter((edge) => selected.has(edge.source) && selected.has(edge.target));
  const boundaryEdges = graph.edges.filter(
    (edge) => selected.has(edge.source) !== selected.has(edge.target),
  );
  const centerX = nodes.reduce((sum, node) => sum + node.x, 0) / nodes.length;
  const centerY = nodes.reduce((sum, node) => sum + node.y, 0) / nodes.length;
  const group: AuraNode = {
    id: newId(),
    kind: "group",
    type: "Expression",
    token: latex,
    label: `⟨${nodes.length} vertices⟩`,
    variant: null,
    x: centerX,
    y: centerY,
    collapsed: true,
    meta: { latex, payload: { nodes, edges: innerEdges } satisfies CollapsedPayload },
  };
  const remainingNodes = graph.nodes.filter((node) => !selected.has(node.id));
  const edges = boundaryEdges.map((edge) => ({
    ...edge,
    source: selected.has(edge.source) ? group.id : edge.source,
    target: selected.has(edge.target) ? group.id : edge.target,
  }));
  return { graph: { nodes: [...remainingNodes, group], edges }, groupId: group.id };
}

export function expandGroup(graph: AuraGraph, groupId: string): AuraGraph | null {
  const group = graph.nodes.find((node) => node.id === groupId);
  if (!group || !group.collapsed) return null;
  const payload = group.meta?.payload as CollapsedPayload | undefined;
  if (!payload) return null;
  const incoming = graph.edges.filter((edge) => edge.source === groupId || edge.target === groupId);
  const others = graph.edges.filter((edge) => edge.source !== groupId && edge.target !== groupId);
  const restored = payload.nodes.map((node) => ({ ...node }));
  const rootId = payload.nodes.find((node) => !payload.edges.some((edge) => edge.target === node.id))?.id;
  const anchor = rootId ? payload.nodes.find((node) => node.id === rootId) : undefined;
  const shift = anchor ? { x: group.x - anchor.x, y: group.y - anchor.y } : { x: 0, y: 0 };
  const shifted = restored.map((node) => ({ ...node, x: node.x + shift.x, y: node.y + shift.y }));
  const rebound = incoming.map((edge) => ({
    ...edge,
    source: edge.source === groupId ? (rootId ?? edge.source) : edge.source,
    target: edge.target === groupId ? (rootId ?? edge.target) : edge.target,
  }));
  return {
    graph: {
      nodes: [...graph.nodes.filter((node) => node.id !== groupId), ...shifted],
      edges: [...others, ...payload.edges, ...rebound],
    },
  }.graph;
}

/* ------------------------------------------------------------------ */
/* Import / export                                                     */
/* ------------------------------------------------------------------ */

export function graphBounds(graph: AuraGraph): { minX: number; minY: number; maxX: number; maxY: number } {
  if (graph.nodes.length === 0) return { minX: 0, minY: 0, maxX: 800, maxY: 600 };
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const node of graph.nodes) {
    const width = estimateWidth(node);
    minX = Math.min(minX, node.x - width / 2);
    maxX = Math.max(maxX, node.x + width / 2);
    minY = Math.min(minY, node.y - tileHeight() / 2);
    maxY = Math.max(maxY, node.y + tileHeight() / 2);
  }
  return { minX, minY, maxX, maxY };
}

export function validateGraph(graph: AuraGraph): string | null {
  const ids = new Set<string>();
  for (const node of graph.nodes) {
    if (ids.has(node.id)) return `Duplicate vertex id ${node.id}`;
    ids.add(node.id);
    if (!Number.isFinite(node.x) || !Number.isFinite(node.y)) return `Vertex ${node.id} has an invalid position`;
  }
  const edgeIds = new Set<string>();
  const bindings = new Map<string, number>();
  for (const edge of graph.edges) {
    if (edgeIds.has(edge.id)) return `Duplicate edge id ${edge.id}`;
    edgeIds.add(edge.id);
    if (!ids.has(edge.source) || !ids.has(edge.target)) return `Edge ${edge.id} references a missing vertex`;
    bindings.set(edge.target, (bindings.get(edge.target) ?? 0) + 1);
  }
  // Composite vertices are tree nodes: exactly one consumer. Leaves are references.
  const byId = new Map(graph.nodes.map((node) => [node.id, node]));
  for (const [target, count] of bindings) {
    const node = byId.get(target);
    if (node && count > 1 && !isShareable(node)) {
      return `${node.label} is bound to ${count} ports; composite vertices may have one parent`;
    }
  }
  return null;
}

export interface DocumentPayload {
  document: {
    id: string;
    title: string;
    subtitle: string;
    updatedAt: string;
  };
  graph: AuraGraph;
  history: HistoryEntry[];
  canUndo: boolean;
  canRedo: boolean;
}

export interface HistoryEntry {
  id: string;
  seq: number;
  action: string;
  summary: string;
  undone: boolean;
  createdAt: string;
}

export interface DocumentSummary {
  id: string;
  title: string;
  subtitle: string;
  updatedAt: string;
  nodeCount: number;
  transactionCount: number;
}
