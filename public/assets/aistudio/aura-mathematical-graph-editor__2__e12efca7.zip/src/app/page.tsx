import { AuraWorkspace } from "@/components/aura/AuraWorkspace";
import { ensureSeed, getDocument, listDocuments } from "@/lib/aura/data";
import { Icon } from "@/components/aura/icons";

export const dynamic = "force-dynamic";

function ShellMessage({ title, body, hint }: { title: string; body: string; hint?: string }) {
  return (
    <main className="grid min-h-[100dvh] place-items-center px-5 py-12">
      <section className="panel max-w-xl p-7">
        <div className="flex items-center gap-2 text-amber-200">
          <Icon name="spark" className="h-4 w-4" />
          <span className="eyebrow text-amber-200/80">Aura · graph kernel</span>
        </div>
        <h1 className="display mt-3 text-[30px] leading-tight text-slate-50">{title}</h1>
        <p className="mt-3 text-[13.5px] leading-relaxed text-slate-400">{body}</p>
        {hint && (
          <pre className="mono mt-4 overflow-x-auto rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-[11.5px] text-amber-200/90">
            {hint}
          </pre>
        )}
      </section>
    </main>
  );
}

export default async function Page() {
  try {
    await ensureSeed();
    const documents = await listDocuments();
    const active = documents[0];
    if (!active) {
      return (
        <ShellMessage
          title="No canvas yet"
          body="PostgreSQL is reachable but there are no documents. Reload the page to re-seed the workspace."
        />
      );
    }
    const payload = await getDocument(active.id);
    if (!payload) {
      return (
        <ShellMessage
          title="Canvas unavailable"
          body="The document metadata loaded but its typed hypergraph could not be read."
        />
      );
    }
    return <AuraWorkspace documents={documents} initial={payload} />;
  } catch (error) {
    return (
      <ShellMessage
        title="The graph store is not reachable"
        body={
          error instanceof Error
            ? error.message
            : "Aura persists every canvas as a typed hypergraph in PostgreSQL via Drizzle."
        }
        hint="npx drizzle-kit push"
      />
    );
  }
}
