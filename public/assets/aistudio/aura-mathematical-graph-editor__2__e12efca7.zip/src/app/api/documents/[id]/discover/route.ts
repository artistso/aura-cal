import { getDocument, listDiscoveries, recordDiscovery } from "@/lib/aura/data";
import { type Family, discover } from "@/lib/aura/discover";

export const dynamic = "force-dynamic";

const KNOWN_FAMILIES: Family[] = [
  "relation",
  "arithmetic",
  "comparison",
  "set",
  "speculative",
  "transform",
];

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const payload = await getDocument(id);
  if (!payload) return Response.json({ error: "Document not found" }, { status: 404 });

  let body: { scale?: number; families?: string[]; limit?: number; record?: boolean; focusIds?: string[] } = {};
  try {
    body = (await request.json().catch(() => ({}))) as typeof body;
  } catch {
    body = {};
  }

  const scale = typeof body.scale === "number" ? body.scale : 0.5;
  const families = Array.isArray(body.families)
    ? (body.families.filter((entry) => KNOWN_FAMILIES.includes(entry as Family)) as Family[])
    : undefined;
  const limit = typeof body.limit === "number" ? Math.max(3, Math.min(40, body.limit)) : undefined;

  try {
    const focusIds = Array.isArray(body.focusIds) ? body.focusIds.filter((id) => typeof id === "string") : undefined;
    const result = discover(payload.graph, { scale, families, limit, focusIds });
    if (body.record !== false) {
      const holdNames = result.proposals
        .filter((proposal) => proposal.verdict === "holds")
        .slice(0, 2)
        .map((proposal) => proposal.previewLatex);
      await recordDiscovery(id, {
        scale: result.scale,
        clusters: result.clusters,
        considered: result.considered,
        proposed: result.proposals.length,
        holds: result.holds,
        refuted: result.refuted,
        summary: holdNames.length
          ? `holds: ${holdNames.join(" ; ")}`
          : `${result.proposals.length} candidates explored`,
      });
    }
    return Response.json({ ...result, log: await listDiscoveries(id) });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Discovery failed" },
      { status: 400 },
    );
  }
}

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  return Response.json({ log: await listDiscoveries(id) });
}
