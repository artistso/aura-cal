import { applyMutation } from "@/lib/aura/data";
import { documentLatex, diagnose } from "@/lib/aura/engine";
import { type MutationBody, runMutation } from "@/lib/aura/mutations";

export const dynamic = "force-dynamic";

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  let body: MutationBody;
  try {
    body = (await request.json()) as MutationBody;
  } catch {
    return Response.json({ error: "Invalid JSON body" }, { status: 400 });
  }
  if (!body || typeof body.type !== "string") {
    return Response.json({ error: "A mutation type is required" }, { status: 400 });
  }

  try {
    const result = await applyMutation(id, body.type, (graph) => runMutation(graph, body));
    return Response.json({
      ...result.payload,
      expressions: documentLatex(result.payload.graph),
      diagnostics: diagnose(result.payload.graph),
      message: result.message,
      focusId: result.focusId,
    });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Mutation failed" },
      { status: 400 },
    );
  }
}
