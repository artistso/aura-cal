import { getDocument } from "@/lib/aura/data";
import { analyzeGraph, plotSamples } from "@/lib/aura/evaluate";

export const dynamic = "force-dynamic";

/** Numeric view of a canvas: constant values, variable scope and plot samples. */
export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const payload = await getDocument(id);
  if (!payload) return Response.json({ error: "Document not found" }, { status: 404 });

  const url = new URL(request.url);
  const min = Number(url.searchParams.get("min") ?? "-6");
  const max = Number(url.searchParams.get("max") ?? "6");
  const domain = Number.isFinite(min) && Number.isFinite(max) && max > min ? { min, max } : { min: -6, max: 6 };

  const clusters = analyzeGraph(payload.graph).map((entry) => ({
    rootId: entry.rootId,
    latex: entry.latex,
    variables: entry.variables,
    value: entry.value,
    plottable: entry.plottable,
    isRelation: entry.isRelation,
    samples: entry.plottable
      ? plotSamples(
            payload.graph,
            entry.plottable.yRootId,
            domain.min,
            domain.max,
            60,
            entry.plottable.variable,
          )
      : null,
  }));

  return Response.json({ documentId: id, domain, clusters });
}
