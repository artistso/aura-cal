import { createDocument, ensureSeed, listDocuments } from "@/lib/aura/data";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeed();
    const documents = await listDocuments();
    return Response.json({ documents });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Could not list documents" },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json().catch(() => ({}))) as { title?: string };
    const payload = await createDocument(body.title);
    return Response.json(payload, { status: 201 });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Could not create the document" },
      { status: 500 },
    );
  }
}
