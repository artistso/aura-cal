import { redoDocument, undoDocument } from "@/lib/aura/data";
import { documentLatex, diagnose } from "@/lib/aura/engine";

export const dynamic = "force-dynamic";

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  let direction = "undo";
  try {
    const body = (await request.json().catch(() => ({}))) as { direction?: string };
    if (body.direction === "redo") direction = "redo";
  } catch {
    direction = "undo";
  }

  try {
    const payload = direction === "redo" ? await redoDocument(id) : await undoDocument(id);
    if (!payload) return Response.json({ error: "Document not found" }, { status: 404 });
    return Response.json({
      ...payload,
      expressions: documentLatex(payload.graph),
      diagnostics: diagnose(payload.graph),
      message: direction === "redo" ? "Redid the last graph transaction" : "Undid the last graph transaction",
      focusId: null,
    });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "History operation failed" },
      { status: 400 },
    );
  }
}
