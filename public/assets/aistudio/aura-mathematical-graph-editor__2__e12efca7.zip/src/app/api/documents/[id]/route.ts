import { deleteDocument, getDocument } from "@/lib/aura/data";
import { documentLatex, diagnose } from "@/lib/aura/engine";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  try {
    const payload = await getDocument(id);
    if (!payload) return Response.json({ error: "Document not found" }, { status: 404 });
    return Response.json({
      ...payload,
      expressions: documentLatex(payload.graph),
      diagnostics: diagnose(payload.graph),
    });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Could not load the document" },
      { status: 500 },
    );
  }
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  try {
    await deleteDocument(id);
    return Response.json({ ok: true });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Could not delete the document" },
      { status: 500 },
    );
  }
}
