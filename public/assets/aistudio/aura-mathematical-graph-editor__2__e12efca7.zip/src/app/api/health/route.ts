import { sql } from "drizzle-orm";

import { db } from "@/db";
import { runKernelSuite } from "@/lib/aura/kernel-tests";

export const dynamic = "force-dynamic";

/**
 * Readiness probe: database round-trip, schema presence and the kernel
 * verification suite. Returns 503 when any dependency is unhealthy.
 */
export async function GET() {
  const started = Date.now();
  try {
    const probe = await db.execute(sql`
      select
        (select count(*)::int from documents) as documents,
        (select count(*)::int from nodes) as nodes,
        (select count(*)::int from edges) as edges,
        (select count(*)::int from transactions) as transactions
    `);
    const row = (probe.rows[0] ?? {}) as Record<string, number>;
    const dbLatencyMs = Date.now() - started;
    const suite = runKernelSuite();
    const healthy = suite.failed === 0;

    return Response.json(
      {
        ok: healthy,
        db: { ok: true, latencyMs: dbLatencyMs, ...row },
        kernel: {
          ok: healthy,
          passed: suite.passed,
          failed: suite.failed,
          total: suite.total,
          durationMs: suite.durationMs,
          librarySymbols: suite.librarySymbols,
        },
        version: 2,
        timestamp: new Date().toISOString(),
      },
      { status: healthy ? 200 : 503 },
    );
  } catch (error) {
    return Response.json(
      { ok: false, db: { ok: false }, error: error instanceof Error ? error.message : "unhealthy" },
      { status: 503 },
    );
  }
}
