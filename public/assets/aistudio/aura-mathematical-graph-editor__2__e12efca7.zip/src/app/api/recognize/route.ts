import { classifyInk, type Stroke } from "@/lib/aura/recognize";
import { parseLatex } from "@/lib/aura/parse";

export const dynamic = "force-dynamic";

const CONFIDENCE_FLOOR = 0.55;

export async function POST(request: Request) {
  let body: { mode?: string; strokes?: Stroke[]; latex?: string };
  try {
    body = (await request.json()) as { mode?: string; strokes?: Stroke[]; latex?: string };
  } catch {
    return Response.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  if (body.mode === "latex") {
    try {
      const result = parseLatex(String(body.latex ?? ""));
      return Response.json({
        tier: "cloud",
        tierLabel: "Tier 2 · structural recovery",
        source: body.latex,
        latex: result.normalized,
        graph: result.graph,
        rootId: result.rootId,
        nodeCount: result.nodeCount,
        edgeCount: result.edgeCount,
        confidence: 0.96,
      });
    } catch (error) {
      return Response.json(
        { error: error instanceof Error ? error.message : "Could not parse that expression" },
        { status: 422 },
      );
    }
  }

  const strokes = Array.isArray(body.strokes) ? body.strokes : [];
  const predictions = classifyInk(strokes);
  const best = predictions[0];
  return Response.json({
    tier: "device",
    tierLabel: "Tier 1 · on-device classifier",
    strokeCount: strokes.length,
    predictions,
    best: best ?? null,
    needsFallback: !best || best.confidence < CONFIDENCE_FLOOR,
    confidenceFloor: CONFIDENCE_FLOOR,
  });
}
