import {
  LIBRARY_COUNT,
  LIBRARY_DOMAINS,
  SYMBOL_LIBRARY,
  filterLibrary,
} from "@/lib/aura/library";

export const dynamic = "force-dynamic";

/** The full typed symbol inventory, searchable and grouped by domain. */
export async function GET(request: Request) {
  const url = new URL(request.url);
  const query = url.searchParams.get("q") ?? "";
  const domain = url.searchParams.get("domain") ?? "All";
  const format = url.searchParams.get("format");

  const entries = filterLibrary({ query, domain });
  if (format === "tokens") {
    return Response.json({ count: entries.length, tokens: entries.map((entry) => entry.token) });
  }

  return Response.json({
    count: LIBRARY_COUNT,
    returned: entries.length,
    domains: LIBRARY_DOMAINS,
    symbols: entries.slice(0, 500).map((entry) => ({
      id: entry.id,
      token: entry.token,
      label: entry.label,
      kind: entry.kind,
      type: entry.type,
      variant: entry.variant,
      domain: entry.domain,
      subdomain: entry.subdomain,
    })),
    total: SYMBOL_LIBRARY.length,
  });
}
