import { runKernelSuite } from "@/lib/aura/kernel-tests";

export const dynamic = "force-dynamic";

/**
 * Executable specification endpoint. Returns the full kernel verification
 * report; `?format=summary` yields the machine-checkable CI shape.
 */
export async function GET(request: Request) {
  const report = runKernelSuite();
  const url = new URL(request.url);
  const summaryOnly = url.searchParams.get("format") === "summary";
  const status = report.failed === 0 ? 200 : 500;

  if (summaryOnly) {
    return Response.json(
      {
        ok: report.failed === 0,
        total: report.total,
        passed: report.passed,
        failed: report.failed,
        durationMs: report.durationMs,
        librarySymbols: report.librarySymbols,
        failures: report.outcomes.filter((outcome) => !outcome.ok),
      },
      { status },
    );
  }

  return Response.json({ ok: report.failed === 0, report }, { status });
}
