import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "katex/dist/katex.min.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "Aura — A Connection-First Mathematical Canvas",
  description:
    "Aura is a tablet-native mathematical workspace: every symbol is a typed vertex on an infinite canvas, and dragging reveals homeomorphic connection candidates.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#060910",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <a className="skip-link" href="#workspace">
          Skip to workspace
        </a>
        {children}
      </body>
    </html>
  );
}
